const cors = require('cors');
const { CORS_ORIGIN } = require('../config/constants');

const origin =
  !CORS_ORIGIN || CORS_ORIGIN === '*'
    ? true
    : CORS_ORIGIN.split(',').map((s) => s.trim()).filter(Boolean);

module.exports = cors({
  origin,
  methods: ['GET', 'HEAD', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Accept', 'Authorization'],
  maxAge: 86400,
});
