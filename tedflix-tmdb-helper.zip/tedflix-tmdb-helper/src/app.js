const express = require('express');
const {
  PORT,
  TMDB_API_KEY,
} = require('./config/constants');
const corsMiddleware = require('./middleware/cors');
const tmdbRoutes = require('./routes/tmdb');
const cache = require('./services/cache');

const app = express();

app.use(corsMiddleware);
app.use(express.json());

app.get('/', (_req, res) => {
  res.json({
    nome: 'Tedflix TMDB Helper',
    versao: '1.0.0',
    status: 'online',
    tmdb_key_configurada: Boolean(TMDB_API_KEY),
    cache: cache.stats(),
    endpoints: {
      lookup: 'GET /tmdb/lookup?titulo=...&ano=2026&tipo=serie|filme',
      byId: 'GET /tmdb/id/:id?tipo=serie|filme',
      health: 'GET /health',
    },
  });
});

app.get('/health', (_req, res) => {
  res.json({
    ok: true,
    tmdb_key: Boolean(TMDB_API_KEY),
    cache: cache.stats(),
    uptime_s: Math.round(process.uptime()),
  });
});

app.use('/tmdb', tmdbRoutes);

app.use((req, res) => {
  res.status(404).json({ ok: false, error: 'rota não encontrada', path: req.path });
});

app.use((err, _req, res, _next) => {
  console.error('[app]', err?.message || err);
  res.status(500).json({ ok: false, error: 'erro interno' });
});

app.listen(PORT, () => {
  console.log('======================================');
  console.log('🎬 Tedflix TMDB Helper');
  console.log(`🌐 Porta: ${PORT}`);
  console.log(`🔑 TMDB key: ${TMDB_API_KEY ? 'OK' : 'AUSENTE — configure .env'}`);
  console.log('======================================');
  console.log('  GET /tmdb/lookup?titulo=...&tipo=serie');
  console.log('  GET /tmdb/id/:id?tipo=filme');
  console.log('  GET /health');
  console.log('======================================');
});

module.exports = app;
