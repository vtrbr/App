const axios = require('axios');
const {
  TMDB_API_KEY,
  TMDB_BASE,
  TMDB_IMG,
  TMDB_LANGUAGE,
  TMDB_REGION,
  CACHE_TTL_MS,
} = require('../config/constants');
const cache = require('./cache');

function normalizeTitle(t) {
  return String(t || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function scoreMatch(query, candidate, year) {
  const q = normalizeTitle(query);
  const c = normalizeTitle(candidate);
  if (!q || !c) return 0;
  if (q === c) return 100;
  if (c.includes(q) || q.includes(c)) return 80;
  const qw = new Set(q.split(' ').filter(Boolean));
  const cw = new Set(c.split(' ').filter(Boolean));
  let inter = 0;
  for (const w of qw) if (cw.has(w)) inter += 1;
  const base = (inter / Math.max(qw.size, 1)) * 60;
  let bonus = 0;
  if (year) {
    const y = String(year).slice(0, 4);
    if (y && String(candidate).includes(y)) bonus = 10;
  }
  return base + bonus;
}

function img(path, size) {
  if (!path) return null;
  if (String(path).startsWith('http')) return path;
  return `${TMDB_IMG}/${size}${path}`;
}

function client() {
  if (!TMDB_API_KEY) {
    const err = new Error('TMDB_API_KEY não configurada no .env');
    err.status = 500;
    throw err;
  }
  return axios.create({
    baseURL: TMDB_BASE,
    timeout: 15000,
    params: {
      api_key: TMDB_API_KEY,
      language: TMDB_LANGUAGE,
    },
  });
}

/**
 * Busca filme ou série no TMDB e devolve capa/banner/sinopse.
 * @param {{ titulo: string, ano?: string|number, tipo?: 'filme'|'serie' }} opts
 */
async function lookup({ titulo, ano, tipo = 'filme' }) {
  const title = String(titulo || '').trim();
  if (!title || title.length < 2) {
    const err = new Error('titulo obrigatório (mín. 2 caracteres)');
    err.status = 400;
    throw err;
  }

  const kind = String(tipo || 'filme').toLowerCase().startsWith('ser') ? 'serie' : 'filme';
  const year = ano ? String(ano).slice(0, 4) : '';
  const cacheKey = `lookup:${kind}:${normalizeTitle(title)}:${year}`;

  const cached = cache.get(cacheKey);
  if (cached) {
    return { ...cached, cache: true };
  }

  const http = client();
  const endpoint = kind === 'serie' ? '/search/tv' : '/search/movie';
  const params = {
    query: title,
    include_adult: false,
    page: 1,
  };
  if (year) {
    if (kind === 'serie') params.first_air_date_year = year;
    else params.year = year;
    params.primary_release_year = year;
  }
  if (TMDB_REGION) params.region = TMDB_REGION;

  const { data } = await http.get(endpoint, { params });
  const results = Array.isArray(data?.results) ? data.results : [];

  if (!results.length) {
    const empty = {
      ok: false,
      found: false,
      titulo: title,
      tipo: kind,
      capa: null,
      banner: null,
      sinopse: null,
      nota: null,
      ano: year || null,
      tmdb_id: null,
    };
    cache.set(cacheKey, empty, Math.min(CACHE_TTL_MS, 6 * 60 * 60 * 1000)); // 6h miss
    return { ...empty, cache: false };
  }

  // Escolhe melhor match por título (+ ano se houver)
  let best = results[0];
  let bestScore = -1;
  for (const r of results.slice(0, 10)) {
    const name = kind === 'serie' ? r.name || r.original_name : r.title || r.original_title;
    const y =
      kind === 'serie'
        ? (r.first_air_date || '').slice(0, 4)
        : (r.release_date || '').slice(0, 4);
    let s = scoreMatch(title, name, year);
    if (year && y && year === y) s += 25;
    if (s > bestScore) {
      bestScore = s;
      best = r;
    }
  }

  // Score muito baixo → não inventa capa errada
  if (bestScore < 25) {
    const empty = {
      ok: false,
      found: false,
      titulo: title,
      tipo: kind,
      capa: null,
      banner: null,
      sinopse: null,
      nota: null,
      ano: year || null,
      tmdb_id: null,
      motivo: 'nenhum match confiável',
    };
    cache.set(cacheKey, empty, Math.min(CACHE_TTL_MS, 6 * 60 * 60 * 1000));
    return { ...empty, cache: false };
  }

  const name =
    kind === 'serie' ? best.name || best.original_name : best.title || best.original_title;
  const date =
    kind === 'serie' ? best.first_air_date || '' : best.release_date || '';
  const payload = {
    ok: true,
    found: true,
    titulo: name || title,
    tipo: kind,
    tmdb_id: best.id,
    capa: img(best.poster_path, 'w500'),
    capa_sm: img(best.poster_path, 'w185'),
    banner: img(best.backdrop_path, 'w1280'),
    banner_sm: img(best.backdrop_path, 'w780'),
    sinopse: best.overview || null,
    nota: typeof best.vote_average === 'number' ? Number(best.vote_average.toFixed(1)) : null,
    ano: (date || year || '').slice(0, 4) || null,
    score: Math.round(bestScore),
  };

  cache.set(cacheKey, payload, CACHE_TTL_MS);
  return { ...payload, cache: false };
}

/**
 * Detalhe por ID TMDB (quando o app já souber o id).
 */
async function byId({ id, tipo = 'filme' }) {
  const tmdbId = Number(id);
  if (!tmdbId) {
    const err = new Error('id TMDB inválido');
    err.status = 400;
    throw err;
  }
  const kind = String(tipo || 'filme').toLowerCase().startsWith('ser') ? 'serie' : 'filme';
  const cacheKey = `id:${kind}:${tmdbId}`;
  const cached = cache.get(cacheKey);
  if (cached) return { ...cached, cache: true };

  const http = client();
  const endpoint = kind === 'serie' ? `/tv/${tmdbId}` : `/movie/${tmdbId}`;
  const { data } = await http.get(endpoint);

  const name = kind === 'serie' ? data.name || data.original_name : data.title || data.original_title;
  const date =
    kind === 'serie' ? data.first_air_date || '' : data.release_date || '';

  const payload = {
    ok: true,
    found: true,
    titulo: name,
    tipo: kind,
    tmdb_id: data.id,
    capa: img(data.poster_path, 'w500'),
    capa_sm: img(data.poster_path, 'w185'),
    banner: img(data.backdrop_path, 'w1280'),
    banner_sm: img(data.backdrop_path, 'w780'),
    sinopse: data.overview || null,
    nota: typeof data.vote_average === 'number' ? Number(data.vote_average.toFixed(1)) : null,
    ano: date.slice(0, 4) || null,
  };
  cache.set(cacheKey, payload, CACHE_TTL_MS);
  return { ...payload, cache: false };
}

module.exports = { lookup, byId };
