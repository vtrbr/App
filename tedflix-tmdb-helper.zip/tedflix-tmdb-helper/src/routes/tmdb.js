const express = require('express');
const { lookup, byId } = require('../services/tmdb');

const router = express.Router();

/**
 * GET /tmdb/lookup?titulo=...&ano=2026&tipo=serie|filme
 */
router.get('/lookup', async (req, res) => {
  try {
    const titulo = req.query.titulo || req.query.q || req.query.title || '';
    const ano = req.query.ano || req.query.year || '';
    const tipo = req.query.tipo || req.query.type || 'filme';
    const result = await lookup({ titulo, ano, tipo });
    res.json(result);
  } catch (err) {
    const status = err.status || 500;
    res.status(status).json({
      ok: false,
      error: err.message || 'erro no lookup TMDB',
    });
  }
});

/**
 * GET /tmdb/id/:id?tipo=serie|filme
 */
router.get('/id/:id', async (req, res) => {
  try {
    const result = await byId({
      id: req.params.id,
      tipo: req.query.tipo || req.query.type || 'filme',
    });
    res.json(result);
  } catch (err) {
    const status = err.status || 500;
    res.status(status).json({
      ok: false,
      error: err.message || 'erro no detalhe TMDB',
    });
  }
});

module.exports = router;
