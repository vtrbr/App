module.exports = {
  PORT: Number(process.env.PORT) || 7400,
  TMDB_API_KEY: process.env.TMDB_API_KEY || '',
  TMDB_LANGUAGE: process.env.TMDB_LANGUAGE || 'pt-BR',
  TMDB_REGION: process.env.TMDB_REGION || 'BR',
  TMDB_BASE: 'https://api.themoviedb.org/3',
  TMDB_IMG: 'https://image.tmdb.org/t/p',
  CACHE_TTL_MS: Number(process.env.CACHE_TTL_MS) || 7 * 24 * 60 * 60 * 1000,
  CORS_ORIGIN: process.env.CORS_ORIGIN || '*',
};
