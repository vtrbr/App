# Tedflix TMDB Helper

API Node que busca **capa, banner, sinopse e nota** no TMDB quando o catálogo Tedflix/NoFlix vem sem arte.

A chave TMDB fica **somente no servidor** (`.env`).

---

## 1. Configurar

```bash
cp .env.example .env
# edite .env e coloque sua TMDB_API_KEY
```

Chave: [https://www.themoviedb.org/settings/api](https://www.themoviedb.org/settings/api)

```env
PORT=7400
TMDB_API_KEY=sua_chave
TMDB_LANGUAGE=pt-BR
TMDB_REGION=BR
CACHE_TTL_MS=604800000
CORS_ORIGIN=*
```

## 2. Rodar local

```bash
npm install
npm start
```

## 3. Deploy (Render / Railway / etc.)

1. Suba este repositório.
2. Defina `TMDB_API_KEY` nas variáveis de ambiente.
3. Start command: `npm start`
4. Anote a URL pública, ex.: `https://tedflix-tmdb-helper.onrender.com`

---

## Endpoints

### `GET /tmdb/lookup`

| Query | Obrigatório | Exemplo |
|-------|-------------|---------|
| `titulo` | sim | `Donos do Oeste` |
| `ano` | não | `2026` |
| `tipo` | não | `serie` ou `filme` (padrão `filme`) |

```bash
curl "http://localhost:7400/tmdb/lookup?titulo=Donos%20do%20Oeste&ano=2026&tipo=serie"
```

**Sucesso**

```json
{
  "ok": true,
  "found": true,
  "titulo": "Donos do Oeste",
  "tipo": "serie",
  "tmdb_id": 123,
  "capa": "https://image.tmdb.org/t/p/w500/....jpg",
  "capa_sm": "https://image.tmdb.org/t/p/w185/....jpg",
  "banner": "https://image.tmdb.org/t/p/w1280/....jpg",
  "banner_sm": "https://image.tmdb.org/t/p/w780/....jpg",
  "sinopse": "...",
  "nota": 7.2,
  "ano": "2026",
  "score": 100,
  "cache": false
}
```

**Não encontrado**

```json
{ "ok": false, "found": false, "capa": null, "banner": null }
```

### `GET /tmdb/id/:id?tipo=serie|filme`

Quando o app já conhece o `idtmdb`.

### `GET /health`

Healthcheck + se a key está configurada.

---

## Como o app Tedflix usa

Só chama quando **não há capa**:

```
GET {TMDB_HELPER_URL}/tmdb/lookup?titulo=...&ano=...&tipo=serie
```

Preenche `imagem` / `capa` / `banner` e cacheia no client.

---

## Observações

- Cache em memória (7 dias hit / 6h miss).
- Match por título + ano; score baixo → não devolve capa errada.
- Idioma padrão `pt-BR`.
