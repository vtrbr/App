import { el, svgIcone, debounce } from "../dom.js";
import {
  getCanais,
  getCanalCategorias,
  getEventosAoVivo,
  getEventos,
  getCanal,
  buscarCanais,
  limparCacheCatalogo,
} from "../api.js";

function imagem(src, alt) {
  const img = el("img", { alt: alt || "", loading: "lazy", decoding: "async" });
  if (src) {
    img.src = src;
    img.addEventListener("load", () => img.classList.add("on"), { once: true });
    img.addEventListener("error", () => {
      img.style.opacity = "0.08";
    }, { once: true });
  }
  return img;
}

function programaAtual(item) {
  return item?.epg?.current?.title || item?.descricao || "Transmissão ao vivo";
}

function abrirAoVivo(item) {
  const embeds = Array.isArray(item.embeds) ? item.embeds : [];
  if (!embeds.length) return false;

  const payload = JSON.stringify(embeds);
  if (window.AndroidPlayer?.openLivePlayer) {
    window.AndroidPlayer.openLivePlayer(
      item.id,
      item.titulo,
      item.logo,
      payload,
      programaAtual(item),
      item.categoria || "",
    );
    return true;
  }
  return false;
}

function badgeTexto(item) {
  if (item.tipo === "evento") {
    if (item.status === "live") return "AO VIVO";
    if (item.status === "upcoming") return "EM BREVE";
    return (item.status || "EVENTO").toUpperCase();
  }
  return "AO VIVO";
}

function cardCanal(item) {
  const isEvento = item.tipo === "evento";
  const href = isEvento
    ? `#/evento/${encodeURIComponent(item.id)}`
    : `#/canal/${encodeURIComponent(item.id)}`;

  const card = el("a", {
    class: `live-card${isEvento ? " live-card-event" : ""}`,
    href,
    "aria-label": `Assistir ${item.titulo}`,
  });

  const thumb = el("div", { class: "live-thumb" }, [
    imagem(item.logo, item.titulo),
    el("span", {
      class: `live-badge${item.status === "upcoming" ? " live-badge-soon" : ""}`,
      html: `${svgIcone("play")} ${badgeTexto(item)}`,
    }),
  ]);

  const body = el("div", { class: "live-card-body" }, [
    el("strong", {}, item.titulo),
    el("span", { class: "live-meta" }, programaAtual(item)),
  ]);

  if (isEvento && item.categoria) {
    body.append(el("span", { class: "live-category" }, item.categoria));
  }

  card.append(thumb, body);

  card.addEventListener("click", (event) => {
    if (abrirAoVivo(item)) event.preventDefault();
  });

  return card;
}

function destaque(item) {
  const href = item.tipo === "evento"
    ? `#/evento/${encodeURIComponent(item.id)}`
    : `#/canal/${encodeURIComponent(item.id)}`;

  const card = el("a", {
    class: "live-feature",
    href,
    "aria-label": `Assistir ${item.titulo}`,
  });

  card.append(
    el("div", { class: "live-feature-art" }, [
      imagem(item.logo, item.titulo),
      el("div", { class: "live-feature-veil" }),
      el("div", { class: "live-feature-copy" }, [
        el("span", {
          class: "live-badge live-badge-large",
          html: `${svgIcone("play")} ${badgeTexto(item)}`,
        }),
        el("h2", {}, item.titulo),
        el("p", {}, programaAtual(item)),
        item.categoria
          ? el("span", { class: "live-feature-category" }, item.categoria)
          : null,
      ]),
    ]),
  );

  card.addEventListener("click", (event) => {
    if (abrirAoVivo(item)) event.preventDefault();
  });

  return card;
}

function sectionTitle(title, icon = "") {
  return el("div", { class: "live-section-head" }, [
    el("div", { class: "live-section-title" }, [
      icon ? el("span", { class: "live-section-icon", html: icon }) : null,
      el("h2", {}, title),
    ]),
  ]);
}

function estado(texto, erro = false) {
  return el("div", { class: `center live-state${erro ? " is-error" : ""}` }, [
    !erro && el("div", { class: "spinner" }),
    el("p", {}, texto),
  ]);
}

export default async function paginaCanais(raiz) {
  const page = el("div", { class: "page live-page" });

  const intro = el("div", { class: "live-intro" }, [
    el("h1", { class: "page-title" }, "Canais ao vivo"),
    el("p", { class: "live-sub" }, "Assista agora aos seus canais e eventos favoritos."),
  ]);

  const busca = el("div", { class: "live-search-wrap" }, [
    el("span", { class: "live-search-icon", html: svgIcone("search") }),
    el("input", {
      class: "input live-search",
      type: "search",
      placeholder: "Buscar canal, categoria ou programa...",
      "aria-label": "Buscar canal, categoria ou programa",
    }),
  ]);

  const chips = el("div", {
    class: "chips live-chips",
    role: "tablist",
    "aria-label": "Categorias de canais",
  });

  const area = el("div", { class: "live-area" });
  area.append(estado("Carregando canais…"));
  page.append(intro, busca, chips, area);
  raiz.append(page);

  let categorias = [];
  let categoriaAtual = "";
  let listaBase = [];

  function renderLista(itens) {
    area.replaceChildren();

    if (!itens.length) {
      area.append(estado("Nenhum canal encontrado.", true));
      return;
    }

    const eventos = itens.filter((item) => item.tipo === "evento");
    const canais = itens.filter((item) => item.tipo !== "evento");

    const aoVivo = eventos.filter((item) => item.status === "live");
    const destaqueItem = aoVivo[0] || eventos[0] || canais.find((item) => (item.embeds || []).length) || canais[0];

    if (destaqueItem) {
      area.append(
        el("section", { class: "live-feature-section" }, [
          sectionTitle("Em destaque"),
          destaque(destaqueItem),
        ]),
      );
    }

    if (eventos.length) {
      const eventoGrid = el("div", { class: "live-grid" });
      const eventoItems = destaqueItem && eventos.length > 1
        ? eventos.filter((item) => item.id !== destaqueItem.id)
        : eventos;

      eventoItems.forEach((item) => eventoGrid.append(cardCanal(item)));

      if (eventoItems.length) {
        area.append(
          el("section", { class: "live-section" }, [
            sectionTitle("Eventos ao vivo", svgIcone("play")),
            eventoGrid,
          ]),
        );
      }
    }

    if (canais.length) {
      const canalGrid = el("div", { class: "live-grid" });
      canais.forEach((item) => canalGrid.append(cardCanal(item)));

      area.append(
        el("section", { class: "live-section" }, [
          sectionTitle("Canais", svgIcone("tv")),
          canalGrid,
        ]),
      );
    }
  }

  async function carregar(cat = "") {
    categoriaAtual = cat;
    area.replaceChildren(estado("Carregando canais…"));

    try {
      const [canais, eventos] = await Promise.all([
        getCanais(cat || ""),
        cat ? Promise.resolve([]) : getEventosAoVivo().catch(() => []),
      ]);

      listaBase = [...(eventos || []), ...(canais || [])];
      renderLista(listaBase);
    } catch (error) {
      area.replaceChildren(
        estado(error?.message || "Não foi possível carregar os canais.", true),
        el(
          "button",
          {
            class: "btn primary",
            type: "button",
            style: "margin:12px auto;display:block",
            onclick: () => {
              try {
                limparCacheCatalogo();
              } catch (_) {}
              carregar(categoriaAtual);
            },
          },
          "Tentar novamente",
        ),
      );
    }
  }

  try {
    categorias = await getCanalCategorias();
  } catch (_) {
    categorias = [];
  }

  const setActive = (button) => {
    [...chips.children].forEach((b) => {
      b.classList.remove("on");
      b.setAttribute("aria-selected", "false");
    });
    button.classList.add("on");
    button.setAttribute("aria-selected", "true");
  };

  const allBtn = el(
    "button",
    {
      class: "chip on",
      type: "button",
      "data-cat": "",
      role: "tab",
      "aria-selected": "true",
    },
    "Todos",
  );

  allBtn.addEventListener("click", () => {
    setActive(allBtn);
    carregar("");
  });
  chips.append(allBtn);

  categorias.forEach((c) => {
    const btn = el(
      "button",
      {
        class: "chip",
        type: "button",
        "data-cat": c.nome,
        role: "tab",
        "aria-selected": "false",
      },
      c.nome,
    );

    btn.addEventListener("click", () => {
      setActive(btn);
      carregar(c.nome);
    });

    chips.append(btn);
  });

  const onBusca = debounce(async (termo) => {
    const q = String(termo || "").trim();

    if (!q) {
      renderLista(listaBase);
      return;
    }

    area.replaceChildren(estado("Buscando…"));

    try {
      const resultado = await buscarCanais(q);
      renderLista(resultado || []);
    } catch (_) {
      area.replaceChildren(estado("Não foi possível realizar a busca.", true));
    }
  }, 350);

  busca.querySelector("input").addEventListener("input", (event) => {
    onBusca(event.target.value);
  });

  await carregar("");
  return page;
}

export async function paginaCanal(raiz, { id }) {
  const page = el("div", { class: "page live-page" });
  raiz.append(page);
  page.append(estado("Carregando canal…"));

  try {
    const item = await getCanal(id);
    if (!item?.id) throw new Error("Canal não encontrado.");

    page.innerHTML = "";
    page.append(
      el("a", {
        class: "back",
        href: "#/canais",
        "aria-label": "Voltar",
        html: svgIcone("back"),
      }),
      el("div", { class: "live-detail-art" }, [
        imagem(item.logo, item.titulo),
        el("div", { class: "live-detail-veil" }),
      ]),
      el("div", { class: "live-detail-body" }, [
        el("span", { class: "live-badge", html: `${svgIcone("play")} AO VIVO` }),
        el("h1", {}, item.titulo),
        el("p", { class: "sub" }, programaAtual(item)),
        el("p", { class: "desc" }, item.descricao || ""),
        el(
          "button",
          {
            class: "btn primary live-start",
            html: `${svgIcone("play")} Abrir transmissão`,
          },
        ),
      ]),
    );

    page.querySelector(".live-start").addEventListener("click", () => {
      if (!abrirAoVivo(item)) {
        page.append(estado("Este canal não possui servidor disponível no momento.", true));
      }
    });
  } catch (error) {
    page.replaceChildren(
      estado(error.message || "Não foi possível abrir o canal.", true),
      el("a", { class: "btn ghost", href: "#/canais" }, "Voltar aos canais"),
    );
  }

  return page;
}

export async function paginaEvento(raiz, { id }) {
  const page = el("div", { class: "page live-page" });
  raiz.append(page);
  page.append(estado("Carregando evento…"));

  try {
    let item = null;

    try {
      const todos = await getEventos("");
      item = (todos || []).find((e) => e.id === id) || null;
    } catch (_) {}

    if (!item) {
      const live = await getEventosAoVivo();
      item = (live || []).find((e) => e.id === id) || null;
    }

    if (!item) throw new Error("Evento não encontrado neste momento.");

    page.innerHTML = "";
    page.append(
      el("a", {
        class: "back",
        href: "#/canais",
        "aria-label": "Voltar",
        html: svgIcone("back"),
      }),
      el("div", { class: "live-detail-art" }, [
        imagem(item.logo, item.titulo),
        el("div", { class: "live-detail-veil" }),
      ]),
      el("div", { class: "live-detail-body" }, [
        el("span", {
          class: "live-badge",
          html: `${svgIcone("play")} ${badgeTexto(item)}`,
        }),
        el("h1", {}, item.titulo),
        el("p", { class: "sub" }, item.categoria || "Evento ao vivo"),
        el("p", { class: "desc" }, item.descricao || ""),
        el(
          "button",
          {
            class: "btn primary live-start",
            html: `${svgIcone("play")} Abrir transmissão`,
          },
        ),
      ]),
    );

    page.querySelector(".live-start").addEventListener("click", () => {
      if (!abrirAoVivo(item)) {
        page.append(estado("Abra este evento no app para iniciar a transmissão.", true));
      }
    });
  } catch (error) {
    page.replaceChildren(
      estado(error.message || "Não foi possível abrir o evento.", true),
      el("a", { class: "btn ghost", href: "#/canais" }, "Voltar aos canais"),
    );
  }

  return page;
}
