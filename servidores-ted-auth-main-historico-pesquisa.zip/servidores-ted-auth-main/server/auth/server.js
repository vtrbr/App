// ============================================================
// TEDFLIX - AUTH SERVER v4.0
// Tokens + Status + Sessão + Presença + Painel
// ============================================================

const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');

const app = express();
const PORT = process.env.PORT || 3001;

// ============================================================
// FIREBASE
// ============================================================
const serviceAccount = {
  type: "service_account",
  project_id: "postagem-e3677",
  private_key_id: "3d07995fcc7d3776b81ceb11d1b4b3c72f2861c3",
  private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCjfxQq66ZPXeJc\n0PCaZhpBVrkP725BxyHBMi9Eq0LTExB7V93wragw6V4hZIgb3DDL+rEglIhM7ekx\nkcjy6YIV6sCFycWlGBethBMxupASsWixvPaSyUwxCT1cij+bKM1O/72cU4/fJeOH\nQ3EFepaSFQ2HT9A/AfZwaUoWpg3py4Hz5HpkdK1iY1CDS6tP2Njiknh4NiVc+lFW\nb5BsDAmbWQ4aSJL9kPfqBZ4QrdAVq1etbrqr39q8lT2ej4f1D741JJWRjjE4m1+r\nl5DHMPbdxSQhBZB1LcQwJSLskjFoaArJ4HVBjLtqAUArl65FxpaIWl9iKJ3XE3/f\nidO1l025AgMBAAECggEADdK/vMVBwXIZomlT/mnljGKtsOg4dT1F4FTC5FZqhvgU\nq6kJLcEw+Dmy6LXcQCbExWpDsZJ9V6vBzJwb1lXh1sKLVoRxvnyj+9qv2MOCTOJN\nDMICQvTcCUVTt9BEgnTXrvc2a9Iw1tgYPaZ5FtJ/iohXJXqdC8a5tFVimzmc8YhN\npmX/ygzG+Rt4pgXNVyYQzw9VguodC1sAtOMGRfZlpEzRa+4A+V2zJzqTCWT7EMDj\nouJ9mPZnGautRqqejt3f5t497OUSm69GphcFgBXpUfEoNqa13/88GyGygnzePdUB\n/t6Knf3u6EQKxAnIKVzNbXLnN4Gqab7Bxfj9BrD4NQKBgQDX3kK7RMI8khsiz0fI\ngWg6f0ytc3UwGpQ4e2TTmCUNAyJ1X4X41nLfkxI+NO9G4DUjol3kxt5Ora5JLQFZ\n+YPbs73L6a2pQBJT4nYQuPjbzGegHL27VlFpxqE2TIZi98xiJOXNpX3Va1YfxWwm\nkNUGHmIb7PTGyQP0A0smCCZukwKBgQDB5E4pA6xLfQ2nMGntY4MODMcVWDXNaZM7\njsbEuo2bH9aaiwPL2Rlby+Xq7MqqZLo9SzuwFMclZWacXlcwo8pnzrBxFQEIjz+d\n/r1DS9UUAX8M61XmRk+2YauU1asHGKE1+qhBewuTm/BtOkzJHu4zffWlPxtDyw+1\nCbe5qIs2AwKBgGIvnSiyqKqGRkN6BouDmNXqqwTF3Eqp/DsInR7FOC0H/PdoIHbD\ni/J3Ybfbue4B8wmnQ4/YiKs+wmRUTSYQoNIgmjaSrkOqeeufuNX4XHEVMxkXmZEJ\nPPSgvRkGi6WeUl9dqwzzth2Jud2vnXaZL9udnEBZciisq9ikWt0MnfZzAoGBAKbG\nLOCkcye/WeYMA6EYLlsAbKGUbTrRa74X0irXWAQtP5dQqaRGicRmvs3yfWRRHcyp\nEJ8lUCJ/dOJdV1vUFr5xj1zFN01Ygdzxh3QCHzaFDvZa2lkm81up6T8tBl4lNk1K\n3DzujIeb4xLgyblY7ITH/Gn1vQrz9/+9axW7vnpnAoGBAIPilavsY0PF/25NTHDq\ngCpcHdKyCjyHXj40yjlZ/OcO6cIxKVxVJYYv5pJj3MQsI3xXWVHLlTNBok6L610X\n8iId7KmFS8gBOG7SMix9QqsWYwn2TX1qkExx2zXdnPcMUPQao/stAa2qQ16m28u3\nQlhEmQGCOZCgWJeIagS5hL81\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-fbsvc@postagem-e3677.iam.gserviceaccount.com",
  client_id: "104250812427310327843",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40postagem-e3677.iam.gserviceaccount.com",
  universe_domain: "googleapis.com"
};

admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const db = admin.firestore();

// ============================================================
// MIDDLEWARES
// ============================================================
app.use(cors());
app.use(express.json());

const ADMIN_PASSWORD = 'Vitor@2026v1';

// Heartbeat: considera online se ping < 2 min
const ONLINE_WINDOW_MS = 2 * 60 * 1000;
// Considera nova sessão se ficou > 5 min sem ping
const NEW_SESSION_GAP_MS = 5 * 60 * 1000;

// ============================================================
// HELPERS
// ============================================================
function calcularValidade(validade) {
  if (!validade || validade === 'nunca') {
    return { tipo: 'nunca', expira_em: null, dias_restantes: null, expirado: false };
  }
  const expira = new Date(validade);
  const agora = new Date();
  const diffMs = expira - agora;
  const dias = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  return {
    tipo: 'data',
    expira_em: expira.toISOString(),
    dias_restantes: dias,
    expirado: diffMs < 0
  };
}

function gerarTokenUnico() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const grupos = [];
  for (let g = 0; g < 5; g++) {
    let parte = '';
    for (let i = 0; i < 5; i++) parte += chars.charAt(Math.floor(Math.random() * chars.length));
    grupos.push(parte);
  }
  return grupos.join('-');
}

function pegarIP(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim()
    || req.socket?.remoteAddress
    || req.ip
    || 'unknown';
}

function pegarPlataforma(req) {
  const ua = (req.headers['user-agent'] || '').toLowerCase();
  if (ua.includes('android')) return 'android';
  if (ua.includes('iphone') || ua.includes('ipad') || ua.includes('ios')) return 'ios';
  return 'web';
}

function pegarUserAgent(req) {
  return req.headers['user-agent'] || 'unknown';
}

function hoje() {
  return new Date().toISOString().slice(0, 10);
}

function hhmm(iso) {
  return iso.slice(11, 16);
}

// ============================================================
// MIDDLEWARE DE TOKEN
// ============================================================
async function tokenMiddleware(req, res, next) {
  try {
    const token = req.headers['x-access-token'];
    if (!token) return res.status(401).json({ success: false, error: 'Token não fornecido' });

    const tokenDoc = await db.collection('tokens').doc(token).get();
    if (!tokenDoc.exists) return res.status(401).json({ success: false, error: 'Token inválido' });

    const d = tokenDoc.data();
    if (d.status !== 'active') return res.status(403).json({ success: false, error: 'Token bloqueado' });

    const validade = calcularValidade(d.validade);
    if (validade.expirado) return res.status(403).json({ success: false, error: 'Token expirado' });

    req.token = token;
    req.tokenData = d;
    next();
  } catch (err) {
    console.error('❌ tokenMiddleware:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
}

// ============================================================
// RAIZ
// ============================================================
app.get('/', (req, res) => {
  res.json({
    name: 'Tedflix Auth Server',
    version: '4.0.0',
    status: 'online',
    endpoints: {
      publico: ['GET /status/:token', 'POST /sessao/ping', 'POST /sessao/offline'],
      validacao: ['GET /validar/:token'],
      admin: [
        'POST   /admin/login',
        'POST   /admin/tokens',
        'GET    /admin/tokens',
        'PATCH  /admin/tokens/:token/validade',
        'PATCH  /admin/tokens/:token/renovar',
        'PATCH  /admin/tokens/:token/block',
        'PATCH  /admin/tokens/:token/unblock',
        'DELETE /admin/tokens/:token',
        'GET    /admin/sistema',
        'POST   /admin/sistema',
        'GET    /admin/online',
        'GET    /admin/dashboard',
        'GET    /admin/usuario/:token'
      ],
      favoritos: ['POST /api/favorites/toggle', 'GET /api/favorites/list'],
      historico: ['POST /api/history/save-progress', 'GET /api/history/continue-watching']
    }
  });
});

// ============================================================
// 🔑 ADMIN — LOGIN
// ============================================================
app.post('/admin/login', (req, res) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ success: false, error: 'Senha não fornecida' });
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });
  res.json({ success: true, message: 'Login realizado com sucesso' });
});

// ============================================================
// 🔑 ADMIN — CRIAR TOKEN
// ============================================================
app.post('/admin/tokens', async (req, res) => {
  try {
    const { password, nome, validade } = req.body;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });

    let token = gerarTokenUnico();
    while ((await db.collection('tokens').doc(token).get()).exists) token = gerarTokenUnico();

    let valorValidade = 'nunca';
    if (validade && validade !== 'nunca') {
      const d = new Date(validade);
      if (isNaN(d)) return res.status(400).json({ success: false, error: 'Data inválida' });
      valorValidade = d.toISOString();
    }

    await db.collection('tokens').doc(token).set({
      token,
      nome: nome || 'Usuário',
      status: 'active',
      validade: valorValidade,
      criadoEm: new Date().toISOString(),
      primeiroAcesso: null,
      ultimoAcesso: null,
      ultimoAcessoIP: null,
      ultimoAcessoPlataforma: null,
      ultimoAcessoVersao: null,
      totalAcessos: 0,
      acessos7d: 0,
      acessos30d: 0,
      ultimoVideo: null
    });

    res.json({ success: true, token, nome: nome || 'Usuário', validade: valorValidade });
  } catch (err) {
    console.error('❌ criar token:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// 🔑 ADMIN — LISTAR TOKENS (com presença + stats)
// ============================================================
app.get('/admin/tokens', async (req, res) => {
  try {
    const { password } = req.query;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });

    const snap = await db.collection('tokens').orderBy('criadoEm', 'desc').get();
    const tokens = [];

    for (const doc of snap.docs) {
      const d = doc.data();
      const sessaoDoc = await db.collection('sessoes').doc(doc.id).get();
      const sessao = sessaoDoc.exists ? sessaoDoc.data() : null;

      const online = sessao
        ? (Date.now() - new Date(sessao.ultimoPing).getTime()) < ONLINE_WINDOW_MS && sessao.online !== false
        : false;

      tokens.push({
        id: doc.id,
        ...d,
        _validade: calcularValidade(d.validade),
        _sessao: sessao,
        _online: online
      });
    }

    res.json({ success: true, total: tokens.length, tokens });
  } catch (err) {
    console.error('❌ listar tokens:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// 🔑 ADMIN — DETALHE DE UM USUÁRIO
// ============================================================
app.get('/admin/usuario/:token', async (req, res) => {
  try {
    const { password } = req.query;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });

    const { token } = req.params;
    const tokenDoc = await db.collection('tokens').doc(token).get();
    if (!tokenDoc.exists) return res.status(404).json({ success: false, error: 'Token não encontrado' });

    const d = tokenDoc.data();
    const sessaoDoc = await db.collection('sessoes').doc(token).get();
    const sessao = sessaoDoc.exists ? sessaoDoc.data() : null;

    const online = sessao
      ? (Date.now() - new Date(sessao.ultimoPing).getTime()) < ONLINE_WINDOW_MS && sessao.online !== false
      : false;

    // Últimos 14 dias de acesso
    const acessosSnap = await db.collection('acessos')
      .where('token', '==', token)
      .orderBy('data', 'desc')
      .limit(14)
      .get();

    const acessos = acessosSnap.docs.map(x => x.data()).reverse();

    // Favoritos
    const favSnap = await db.collection('favoritos').where('token', '==', token).get();
    // Histórico recente
    const histSnap = await db.collection('historico')
      .where('token', '==', token)
      .orderBy('ultimoAcesso', 'desc')
      .limit(10)
      .get();

    res.json({
      success: true,
      usuario: {
        ...d,
        _validade: calcularValidade(d.validade),
        _sessao: sessao,
        _online: online
      },
      acessos_14d: acessos,
      favoritos: favSnap.docs.map(x => x.data()),
      historico_recente: histSnap.docs.map(x => x.data()),
      total_favoritos: favSnap.size,
      total_historico: histSnap.size
    });
  } catch (err) {
    console.error('❌ admin/usuario:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// 🔑 ADMIN — VALIDADE / RENOVAR / BLOCK / UNBLOCK / DELETE
// ============================================================
app.patch('/admin/tokens/:token/validade', async (req, res) => {
  try {
    const { token } = req.params;
    const { password, validade } = req.body;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });

    const doc = await db.collection('tokens').doc(token).get();
    if (!doc.exists) return res.status(404).json({ success: false, error: 'Token não encontrado' });

    let valorFinal;
    if (!validade || validade === 'nunca') valorFinal = 'nunca';
    else {
      const d = new Date(validade);
      if (isNaN(d)) return res.status(400).json({ success: false, error: 'Data inválida' });
      valorFinal = d.toISOString();
    }

    await doc.ref.update({ validade: valorFinal });
    res.json({ success: true, validade: valorFinal, _validade: calcularValidade(valorFinal) });
  } catch (err) {
    console.error('❌ validade:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

app.patch('/admin/tokens/:token/renovar', async (req, res) => {
  try {
    const { token } = req.params;
    const { password, dias } = req.body;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });
    if (!dias || dias <= 0) return res.status(400).json({ success: false, error: 'Dias inválidos' });

    const doc = await db.collection('tokens').doc(token).get();
    if (!doc.exists) return res.status(404).json({ success: false, error: 'Token não encontrado' });

    const nova = new Date();
    nova.setDate(nova.getDate() + parseInt(dias));

    await doc.ref.update({ validade: nova.toISOString() });
    res.json({ success: true, validade: nova.toISOString(), _validade: calcularValidade(nova.toISOString()) });
  } catch (err) {
    console.error('❌ renovar:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

app.patch('/admin/tokens/:token/block', async (req, res) => {
  try {
    const { token } = req.params;
    const { password } = req.body;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });

    const doc = await db.collection('tokens').doc(token).get();
    if (!doc.exists) return res.status(404).json({ success: false, error: 'Token não encontrado' });

    await doc.ref.update({ status: 'blocked', bloqueadoEm: new Date().toISOString() });
    res.json({ success: true, message: 'Token bloqueado' });
  } catch (err) {
    console.error('❌ block:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

app.patch('/admin/tokens/:token/unblock', async (req, res) => {
  try {
    const { token } = req.params;
    const { password } = req.body;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });

    const doc = await db.collection('tokens').doc(token).get();
    if (!doc.exists) return res.status(404).json({ success: false, error: 'Token não encontrado' });

    await doc.ref.update({ status: 'active', bloqueadoEm: null });
    res.json({ success: true, message: 'Token desbloqueado' });
  } catch (err) {
    console.error('❌ unblock:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

app.delete('/admin/tokens/:token', async (req, res) => {
  try {
    const { token } = req.params;
    const { password } = req.body;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });

    const doc = await db.collection('tokens').doc(token).get();
    if (!doc.exists) return res.status(404).json({ success: false, error: 'Token não encontrado' });

    await doc.ref.delete();
    // Limpa sessão
    await db.collection('sessoes').doc(token).delete().catch(() => {});

    res.json({ success: true, message: 'Token deletado' });
  } catch (err) {
    console.error('❌ delete:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// 🔑 ADMIN — SISTEMA GLOBAL
// ============================================================
app.get('/admin/sistema', async (req, res) => {
  try {
    const { password } = req.query;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });

    const doc = await db.collection('config').doc('sistema').get();
    const status = doc.exists ? (doc.data().status || 'active') : 'active';
    res.json({ success: true, sistema: status });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

app.post('/admin/sistema', async (req, res) => {
  try {
    const { password, status } = req.body;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });
    if (!['active', 'off'].includes(status)) return res.status(400).json({ success: false, error: 'Status inválido' });

    await db.collection('config').doc('sistema').set({
      status,
      atualizadoEm: new Date().toISOString()
    }, { merge: true });

    res.json({ success: true, sistema: status });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// 🔑 ADMIN — QUEM ESTÁ ONLINE AGORA
// ============================================================
app.get('/admin/online', async (req, res) => {
  try {
    const { password } = req.query;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });

    const limite = new Date(Date.now() - ONLINE_WINDOW_MS).toISOString();
    const snap = await db.collection('sessoes').where('ultimoPing', '>', limite).get();

    const online = [];
    const porVideo = {};

    for (const doc of snap.docs) {
      const s = doc.data();
      if (s.online === false) continue;

      // Pega nome do token
      const tDoc = await db.collection('tokens').doc(doc.id).get();
      const nome = tDoc.exists ? (tDoc.data().nome || 'Usuário') : 'Desconhecido';

      const item = {
        token: doc.id,
        nome,
        ultimoPing: s.ultimoPing,
        segundosDesdeUltimoPing: Math.floor((Date.now() - new Date(s.ultimoPing).getTime()) / 1000),
        telaAtual: s.telaAtual,
        videoAtual: s.videoAtual,
        iniciouSessao: s.iniciouSessao,
        duracaoSessao: s.duracaoSessao,
        plataforma: s.plataforma,
        ip: s.ip
      };

      online.push(item);

      if (s.videoAtual) porVideo[s.videoAtual] = (porVideo[s.videoAtual] || 0) + 1;
    }

    // Ranking de vídeos
    const topVideos = Object.entries(porVideo)
      .map(([slug, count]) => ({ slug, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    res.json({
      success: true,
      total_online: online.length,
      por_video: porVideo,
      top_videos: topVideos,
      usuarios: online
    });
  } catch (err) {
    console.error('❌ admin/online:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// 🔑 ADMIN — DASHBOARD GERAL
// ============================================================
app.get('/admin/dashboard', async (req, res) => {
  try {
    const { password } = req.query;
    if (password !== ADMIN_PASSWORD) return res.status(401).json({ success: false, error: 'Senha incorreta' });

    const agora = Date.now();
    const limiteOnline = new Date(agora - ONLINE_WINDOW_MS).toISOString();
    const hoje = new Date().toISOString().slice(0, 10);
    const seteDiasAtras = new Date(agora - 7 * 24 * 60 * 60 * 1000).toISOString();
    const trintaDiasAtras = new Date(agora - 30 * 24 * 60 * 60 * 1000).toISOString();

    // Total de tokens
    const tokensSnap = await db.collection('tokens').get();
    const totalTokens = tokensSnap.size;

    let ativos = 0, bloqueados = 0, expirados = 0;
    tokensSnap.forEach(doc => {
      const d = doc.data();
      if (d.status !== 'active') bloqueados++;
      else if (calcularValidade(d.validade).expirado) expirados++;
      else ativos++;
    });

    // Online agora
    const sessoesSnap = await db.collection('sessoes').where('ultimoPing', '>', limiteOnline).get();
    let onlineAgora = 0;
    const porVideo = {};
    sessoesSnap.forEach(doc => {
      const s = doc.data();
      if (s.online === false) return;
      onlineAgora++;
      if (s.videoAtual) porVideo[s.videoAtual] = (porVideo[s.videoAtual] || 0) + 1;
    });

    // Acessos hoje / 7d / 30d (agrega da coleção acessos)
    const acessosHoje = await db.collection('acessos').where('data', '==', hoje).get();
    let acessosHojeTotal = 0;
    const usersHoje = new Set();
    acessosHoje.forEach(doc => {
      const a = doc.data();
      acessosHojeTotal += a.acessos || 0;
      usersHoje.add(a.token);
    });

    const acessos7dSnap = await db.collection('acessos').where('data', '>=', seteDiasAtras.slice(0, 10)).get();
    const users7d = new Set();
    let acessos7dTotal = 0;
    acessos7dSnap.forEach(doc => {
      const a = doc.data();
      users7d.add(a.token);
      acessos7dTotal += a.acessos || 0;
    });

    const acessos30dSnap = await db.collection('acessos').where('data', '>=', trintaDiasAtras.slice(0, 10)).get();
    const users30d = new Set();
    let acessos30dTotal = 0;
    acessos30dSnap.forEach(doc => {
      const a = doc.data();
      users30d.add(a.token);
      acessos30dTotal += a.acessos || 0;
    });

    // Tempo médio de sessão (usa duracaoSessao das sessões)
    const sessoesTodas = await db.collection('sessoes').get();
    let somaDuracao = 0, contSessoes = 0;
    sessoesTodas.forEach(doc => {
      const s = doc.data();
      if (s.duracaoSessao && s.duracaoSessao > 0) {
        somaDuracao += s.duracaoSessao;
        contSessoes++;
      }
    });
    const tempoMedioSessao = contSessoes > 0 ? Math.floor(somaDuracao / contSessoes) : 0;

    // Top vídeos agora
    const topVideosAgora = Object.entries(porVideo)
      .map(([slug, count]) => ({ slug, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      tokens: {
        total: totalTokens,
        ativos,
        bloqueados,
        expirados
      },
      presenca: {
        online_agora: onlineAgora,
        top_videos_agora: topVideosAgora
      },
      acessos: {
        hoje: { total: acessosHojeTotal, usuarios_unicos: usersHoje.size },
        ultimos_7d: { total: acessos7dTotal, usuarios_unicos: users7d.size },
        ultimos_30d: { total: acessos30dTotal, usuarios_unicos: users30d.size }
      },
      engajamento: {
        tempo_medio_sessao_segundos: tempoMedioSessao,
        tempo_medio_sessao_formatado: formatarDuracao(tempoMedioSessao)
      }
    });
  } catch (err) {
    console.error('❌ admin/dashboard:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

function formatarDuracao(seg) {
  if (!seg || seg <= 0) return '0min';
  const h = Math.floor(seg / 3600);
  const m = Math.floor((seg % 3600) / 60);
  const s = seg % 60;
  if (h > 0) return `${h}h ${m}min`;
  if (m > 0) return `${m}min ${s}s`;
  return `${s}s`;
}

// ============================================================
// 🌐 PÚBLICO — STATUS DO TOKEN (o app chama isso sempre)
// ============================================================
app.get('/status/:token', async (req, res) => {
  const { token } = req.params;

  try {
    // Sistema global
    const sysDoc = await db.collection('config').doc('sistema').get();
    const sistemaStatus = sysDoc.exists ? (sysDoc.data().status || 'active') : 'active';
    const sistemaObj = { status: sistemaStatus, desligado: sistemaStatus === 'off' };

    const tokenDoc = await db.collection('tokens').doc(token).get();

    if (!tokenDoc.exists) {
      return res.json({
        success: false,
        token,
        validade: null,
        conta: null,
        sistema: sistemaObj,
        acesso: { permitido: false, motivo: 'token_invalido' }
      });
    }

    const d = tokenDoc.data();
    const validade = calcularValidade(d.validade);
    const contaStatus = d.status || 'active';

    let motivo = null;
    if (sistemaObj.desligado) motivo = 'sistema_desligado';
    else if (contaStatus !== 'active') motivo = 'conta_bloqueada';
    else if (validade.expirado) motivo = 'conta_expirada';

    // Registra acesso (assíncrono, não bloqueia resposta)
    registrarAcesso(token, req).catch(e => console.error('registrarAcesso:', e));

    return res.json({
      success: true,
      token,
      nome: d.nome || 'Usuário',
      validade,
      conta: { status: contaStatus, bloqueada: contaStatus !== 'active' },
      sistema: sistemaObj,
      acesso: { permitido: motivo === null, motivo }
    });
  } catch (err) {
    console.error('❌ /status:', err);
    res.status(500).json({
      success: false,
      acesso: { permitido: false, motivo: 'erro_interno' }
    });
  }
});

// ============================================================
// 📊 REGISTRA ACESSO (chamado por /status)
// ============================================================
async function registrarAcesso(token, req) {
  const agora = new Date().toISOString();
  const hojeStr = agora.slice(0, 10);
  const ip = pegarIP(req);
  const plataforma = pegarPlataforma(req);
  const userAgent = pegarUserAgent(req);

  // Atualiza token
  const tokenRef = db.collection('tokens').doc(token);
  const tokenDoc = await tokenRef.get();
  if (!tokenDoc.exists) return;
  const d = tokenDoc.data();

  await tokenRef.update({
    primeiroAcesso: d.primeiroAcesso || agora,
    ultimoAcesso: agora,
    ultimoAcessoIP: ip,
    ultimoAcessoPlataforma: plataforma,
    ultimoAcessoUserAgent: userAgent,
    totalAcessos: (d.totalAcessos || 0) + 1
  });

  // Upsert acesso do dia
  const acessoId = `${token}_${hojeStr}`;
  const acessoRef = db.collection('acessos').doc(acessoId);
  const acessoDoc = await acessoRef.get();

  if (acessoDoc.exists) {
    const a = acessoDoc.data();
    await acessoRef.update({
      acessos: (a.acessos || 0) + 1,
      ultimaVez: hhmm(agora),
      ip,
      plataforma
    });
  } else {
    await acessoRef.set({
      token,
      data: hojeStr,
      acessos: 1,
      primeiraVez: hhmm(agora),
      ultimaVez: hhmm(agora),
      ip,
      plataforma
    });
  }
}

// ============================================================
// 💓 SESSÃO — PING (heartbeat do app)
// ============================================================
app.post('/sessao/ping', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const { tela, videoId, versao } = req.body || {};
    const agora = new Date().toISOString();
    const ip = pegarIP(req);
    const plataforma = pegarPlataforma(req);

    const sessaoRef = db.collection('sessoes').doc(token);
    const sessaoDoc = await sessaoRef.get();

    let iniciouSessao = agora;
    let duracaoSessao = 0;

    if (sessaoDoc.exists) {
      const s = sessaoDoc.data();
      const ultimoPing = new Date(s.ultimoPing).getTime();
      const gap = Date.now() - ultimoPing;

      if (gap < NEW_SESSION_GAP_MS) {
        // Mesma sessão, continua
        iniciouSessao = s.iniciouSessao || agora;
        duracaoSessao = Math.floor((Date.now() - new Date(iniciouSessao).getTime()) / 1000);
      } else {
        // Nova sessão (ficou muito tempo parado)
        iniciouSessao = agora;
        duracaoSessao = 0;
      }
    }

    await sessaoRef.set({
      token,
      online: true,
      ultimoPing: agora,
      telaAtual: tela || 'home',
      videoAtual: videoId || null,
      iniciouSessao,
      duracaoSessao,
      plataforma,
      ip,
      versao: versao || null
    }, { merge: true });

    // Atualiza token com último vídeo assistido
    const updateToken = {
      ultimoAcesso: agora,
      ultimoAcessoIP: ip,
      ultimoAcessoPlataforma: plataforma
    };
    if (videoId) updateToken.ultimoVideo = videoId;
    if (versao) updateToken.ultimoAcessoVersao = versao;

    await db.collection('tokens').doc(token).update(updateToken).catch(() => {});

    res.json({
      success: true,
      online: true,
      sessao: {
        iniciouSessao,
        duracaoSessao,
        duracaoFormatada: formatarDuracao(duracaoSessao),
        telaAtual: tela || 'home',
        videoAtual: videoId || null
      }
    });
  } catch (err) {
    console.error('❌ /sessao/ping:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// 💓 SESSÃO — OFFLINE (app fechando/minimizando)
// ============================================================
app.post('/sessao/offline', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const agora = new Date().toISOString();

    const sessaoRef = db.collection('sessoes').doc(token);
    const sessaoDoc = await sessaoRef.get();

    let duracaoSessao = 0;
    if (sessaoDoc.exists) {
      const s = sessaoDoc.data();
      if (s.iniciouSessao) {
        duracaoSessao = Math.floor((Date.now() - new Date(s.iniciouSessao).getTime()) / 1000);
      }
    }

    await sessaoRef.set({
      online: false,
      ultimoPing: agora,
      duracaoSessao
    }, { merge: true });

    res.json({ success: true, online: false, duracaoSessao });
  } catch (err) {
    console.error('❌ /sessao/offline:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// 🔐 VALIDAR TOKEN (compatibilidade)
// ============================================================
app.get('/validar/:token', async (req, res) => {
  try {
    const { token } = req.params;
    const tokenDoc = await db.collection('tokens').doc(token).get();
    if (!tokenDoc.exists) return res.status(401).json({ success: false, error: 'Token inválido' });

    const d = tokenDoc.data();
    if (d.status !== 'active') return res.status(403).json({ success: false, error: 'Token bloqueado' });
    if (calcularValidade(d.validade).expirado) return res.status(403).json({ success: false, error: 'Token expirado' });

    res.json({ success: true, token, nome: d.nome || 'Usuário' });
  } catch (err) {
    console.error('❌ /validar:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// ❤️ FAVORITOS
// ============================================================
app.post('/api/favorites/toggle', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const { filmeId, titulo, thumb } = req.body;
    if (!filmeId) return res.status(400).json({ success: false, error: 'filmeId é obrigatório' });

    const favoritoId = `${token}_${filmeId}`;
    const ref = db.collection('favoritos').doc(favoritoId);
    const doc = await ref.get();

    if (doc.exists) {
      await ref.delete();
      return res.json({ success: true, favorited: false, message: 'Removido dos favoritos' });
    } else {
      await ref.set({
        token, filmeId,
        titulo: titulo || '',
        thumb: thumb || '',
        adicionadoEm: new Date().toISOString()
      });
      return res.json({ success: true, favorited: true, message: 'Adicionado aos favoritos' });
    }
  } catch (err) {
    console.error('❌ toggle favorito:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

app.get('/api/favorites/list', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const snap = await db.collection('favoritos')
      .where('token', '==', token)
      .orderBy('adicionadoEm', 'desc')
      .get();

    const favoritos = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json({ success: true, total: favoritos.length, favoritos });
  } catch (err) {
    console.error('❌ list favoritos:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// 📺 HISTÓRICO
// ============================================================
app.post('/api/history/save-progress', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const { filmeId, titulo, tempo, thumb } = req.body;
    if (!filmeId) return res.status(400).json({ success: false, error: 'filmeId é obrigatório' });

    const historicoId = `${token}_${filmeId}`;
    await db.collection('historico').doc(historicoId).set({
      token, filmeId,
      titulo: titulo || '',
      tempo: tempo || '00:00:00',
      thumb: thumb || '',
      ultimoAcesso: new Date().toISOString()
    }, { merge: true });

    res.json({ success: true, message: 'Progresso salvo' });
  } catch (err) {
    console.error('❌ save-progress:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

app.get('/api/history/continue-watching', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const snap = await db.collection('historico')
      .where('token', '==', token)
      .orderBy('ultimoAcesso', 'desc')
      .limit(20)
      .get();

    const historico = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json({ success: true, total: historico.length, historico });
  } catch (err) {
    console.error('❌ continue-watching:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});


// ============================================================
// 🔎 HISTÓRICO DE PESQUISAS
// ============================================================
app.post('/api/search/history', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const query = String(req.body?.query || req.body?.pesquisa || '').trim();
    if (!query) return res.status(400).json({ success: false, error: 'query é obrigatória' });

    const refCollection = db.collection('historico_pesquisas');
    const snap = await refCollection.where('token', '==', token).get();
    const existente = snap.docs.find(d => String(d.data().query || '').toLowerCase() === query.toLowerCase());
    const agora = new Date().toISOString();

    if (existente) {
      await existente.ref.set({ query, atualizadoEm: agora }, { merge: true });
      return res.json({ success: true, message: 'Pesquisa atualizada no histórico', id: existente.id });
    }

    const ref = await refCollection.add({ token, query, criadoEm: agora, atualizadoEm: agora });
    res.status(201).json({ success: true, message: 'Pesquisa salva no histórico', id: ref.id });
  } catch (err) {
    console.error('❌ search history POST:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

app.get('/api/search/history', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const snap = await db.collection('historico_pesquisas')
      .where('token', '==', token)
      .limit(50)
      .get();

    const pesquisas = snap.docs
      .map(d => ({ id: d.id, ...d.data() }))
      .sort((a, b) => String(b.atualizadoEm || b.criadoEm || '').localeCompare(String(a.atualizadoEm || a.criadoEm || '')));

    res.json({ success: true, total: pesquisas.length, pesquisas });
  } catch (err) {
    console.error('❌ search history GET:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

app.delete('/api/search/history/:id', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const ref = db.collection('historico_pesquisas').doc(req.params.id);
    const doc = await ref.get();

    if (!doc.exists || doc.data().token !== token) {
      return res.status(404).json({ success: false, error: 'Pesquisa não encontrada' });
    }

    await ref.delete();
    res.json({ success: true, message: 'Pesquisa removida do histórico' });
  } catch (err) {
    console.error('❌ search history DELETE item:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

app.delete('/api/search/history', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const snap = await db.collection('historico_pesquisas').where('token', '==', token).get();

    if (snap.empty) {
      return res.json({ success: true, removidas: 0, message: 'Histórico de pesquisas já está vazio' });
    }

    let batch = db.batch();
    let count = 0;
    for (const doc of snap.docs) {
      batch.delete(doc.ref);
      count++;
      if (count === 500) {
        await batch.commit();
        batch = db.batch();
        count = 0;
      }
    }
    if (count > 0) await batch.commit();

    res.json({ success: true, removidas: snap.size, message: 'Histórico de pesquisas apagado com sucesso' });
  } catch (err) {
    console.error('❌ search history DELETE all:', err);
    res.status(500).json({ success: false, error: 'Erro interno' });
  }
});

// ============================================================
// 🚀 START
// ============================================================
app.listen(PORT, () => {
  console.log('========================================');
  console.log('🎬 TEDFLIX - AUTH SERVER v4.0');
  console.log('========================================');
  console.log(`🚀 Porta ${PORT}`);
  console.log(`📍 http://localhost:${PORT}`);
  console.log('========================================');
  console.log('📋 Endpoints:');
  console.log('  🌐 Público:');
  console.log('    GET    /status/:token');
  console.log('    POST   /sessao/ping');
  console.log('    POST   /sessao/offline');
  console.log('    GET    /validar/:token');
  console.log('  🔑 Admin:');
  console.log('    POST   /admin/login');
  console.log('    POST   /admin/tokens');
  console.log('    GET    /admin/tokens');
  console.log('    GET    /admin/usuario/:token');
  console.log('    PATCH  /admin/tokens/:token/validade');
  console.log('    PATCH  /admin/tokens/:token/renovar');
  console.log('    PATCH  /admin/tokens/:token/block');
  console.log('    PATCH  /admin/tokens/:token/unblock');
  console.log('    DELETE /admin/tokens/:token');
  console.log('    GET    /admin/sistema');
  console.log('    POST   /admin/sistema');
  console.log('    GET    /admin/online');
  console.log('    GET    /admin/dashboard');
  console.log('  ❤️ Favoritos:');
  console.log('    POST   /api/favorites/toggle');
  console.log('    GET    /api/favorites/list');
  console.log('  📺 Histórico:');
  console.log('    POST   /api/history/save-progress');
  console.log('    GET    /api/history/continue-watching');
  console.log('========================================');
});

process.on('unhandledRejection', e => console.error('❌ unhandledRejection:', e));
process.on('uncaughtException', e => console.error('❌ uncaughtException:', e));

module.exports = app;
