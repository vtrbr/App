const router = require('express').Router();
const { getCache, setCache } = require('../services/cache');
const { getFilme } = require('../services/scraper');
const { CACHE_TTL } = require('../config/constants');

router.get('/:slug', async (req, res) => {
  const { slug } = req.params;
  const cacheKey = `filme_${slug}`;
  const cached = getCache(cacheKey);
  if (cached) return res.json(cached);

  const filme = await getFilme(slug);
  setCache(cacheKey, filme, CACHE_TTL.FILME);
  res.json(filme);
});

module.exports = router;
