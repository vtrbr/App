const router = require('express').Router();
const { getCache, setCache } = require('../services/cache');
const { getAlfabeto } = require('../services/scraper');
const { CACHE_TTL } = require('../config/constants');

router.get('/:letra', async (req, res) => {
  const { letra } = req.params;
  const pagina = parseInt(req.query.pagina) || 1;
  if (!/^[A-Za-z0-9]$/.test(letra)) {
    return res.status(400).json({ erro: 'Letra inválida' });
  }
  const cacheKey = `alfabeto_${letra}_pagina_${pagina}`;
  const cached = getCache(cacheKey);
  if (cached) return res.json(cached);

  const filmes = await getAlfabeto(letra, pagina);
  const response = { letra, pagina, total: filmes.length, filmes };
  setCache(cacheKey, response, CACHE_TTL.ALFABETO);
  res.json(response);
});

module.exports = router;
