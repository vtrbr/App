const router = require('express').Router();
const { getCache, setCache } = require('../services/cache');
const { getBilheteria } = require('../services/scraper');
const { CACHE_TTL } = require('../config/constants');

router.get('/', async (req, res) => {
  const cacheKey = 'bilheteria';
  const cached = getCache(cacheKey);
  if (cached) return res.json(cached);

  const destaques = await getBilheteria();
  const response = { total: destaques.length, destaques };
  setCache(cacheKey, response, CACHE_TTL.BILHETERIA);
  res.json(response);
});

module.exports = router;
