const router = require('express').Router();
const { getCache, setCache } = require('../services/cache');
const { getSessao } = require('../services/scraper');
const { CACHE_TTL } = require('../config/constants');

router.get('/ano/:ano', async (req, res) => {
  const { ano } = req.params;
  const pagina = parseInt(req.query.pagina) || 1;
  const cacheKey = `sessao_${ano}_pagina_${pagina}`;
  const cached = getCache(cacheKey);
  if (cached) return res.json(cached);

  const filmes = await getSessao(ano, pagina);
  const response = { ano, pagina, total: filmes.length, filmes };
  setCache(cacheKey, response, CACHE_TTL.SESSAO);
  res.json(response);
});

module.exports = router;
