const router = require('express').Router();
const { getCache, setCache } = require('../services/cache');
const { getTelao } = require('../services/scraper');
const { CACHE_TTL } = require('../config/constants');

router.get('/', async (req, res) => {
  const pagina = parseInt(req.query.pagina) || 1;
  const cacheKey = `telao_pagina_${pagina}`;
  const cached = getCache(cacheKey);
  if (cached) return res.json(cached);

  const filmes = await getTelao(pagina);
  const response = { pagina, total: filmes.length, filmes };
  setCache(cacheKey, response, CACHE_TTL.TELAO);
  res.json(response);
});

module.exports = router;
