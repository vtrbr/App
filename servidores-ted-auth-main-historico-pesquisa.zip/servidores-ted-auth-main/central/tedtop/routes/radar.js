const router = require('express').Router();
const { getCache, setCache } = require('../services/cache');
const { getRadarLive } = require('../services/scraper');
const { CACHE_TTL } = require('../config/constants');

// /radar/live/termo (autosearch)
router.get('/live/:termo', async (req, res) => {
  const { termo } = req.params;
  const cacheKey = `radar_live_${termo}`;
  const cached = getCache(cacheKey);
  if (cached) return res.json(cached);

  const resultados = await getRadarLive(termo);
  const response = { termo, resultados };
  setCache(cacheKey, response, CACHE_TTL.RADAR);
  res.json(response);
});

// /radar?q=termo (busca normal, se houver)
router.get('/', async (req, res) => {
  const { q } = req.query;
  if (!q || q.length < 2) {
    return res.json({ mensagem: 'Digite pelo menos 2 caracteres', resultados: [] });
  }
  const cacheKey = `radar_busca_${q}`;
  const cached = getCache(cacheKey);
  if (cached) return res.json(cached);

  // No TopFilmes, a busca normal também pode usar o autosearch? Vamos usar o mesmo.
  const resultados = await getRadarLive(q);
  const response = { termo: q, resultados };
  setCache(cacheKey, response, CACHE_TTL.RADAR);
  res.json(response);
});

module.exports = router;
