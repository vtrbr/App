const router = require('express').Router();
const { getCache, setCache } = require('../services/cache');
const { getGenero } = require('../services/scraper');
const { CACHE_TTL, GENEROS } = require('../config/constants');

router.get('/:genero', async (req, res) => {
  const { genero } = req.params;
  if (!GENEROS.includes(genero)) {
    return res.status(400).json({ erro: 'Gênero inválido', disponiveis: GENEROS });
  }
  const pagina = parseInt(req.query.pagina) || 1;
  const cacheKey = `genero_${genero}_pagina_${pagina}`;
  const cached = getCache(cacheKey);
  if (cached) return res.json(cached);

  const filmes = await getGenero(genero, pagina);
  const response = { genero, pagina, total: filmes.length, filmes };
  setCache(cacheKey, response, CACHE_TTL.GENEROS);
  res.json(response);
});

module.exports = router;
