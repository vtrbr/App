const router = require('express').Router();
const { getCache, setCache } = require('../services/cache');
const { getIngresso } = require('../services/scraper');
const { CACHE_TTL } = require('../config/constants');

router.get('/:slug', async (req, res) => {
  const { slug } = req.params;
  const cacheKey = `ingresso_${slug}`;
  const cached = getCache(cacheKey);
  if (cached) return res.json(cached);

  try {
    const player = await getIngresso(slug);
    setCache(cacheKey, player, CACHE_TTL.INGRESSO);
    res.json(player);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

module.exports = router;
