// services/cache.js
const cache = new Map();

function getCache(key) {
  if (cache.has(key)) {
    const item = cache.get(key);
    if (Date.now() < item.expiry) {
      return item.data;
    } else {
      cache.delete(key);
      return null;
    }
  }
  return null;
}

function setCache(key, data, ttl = 86400000) {
  cache.set(key, {
    data: data,
    expiry: Date.now() + ttl
  });
}

function clearCache() {
  cache.clear();
}

setInterval(clearCache, 24 * 60 * 60 * 1000);

module.exports = { getCache, setCache, clearCache };
