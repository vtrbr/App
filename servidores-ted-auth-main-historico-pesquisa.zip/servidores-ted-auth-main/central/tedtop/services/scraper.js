const axios = require('axios');
const cheerio = require('cheerio');
const { URL_BASE } = require('../config/constants');

// ================================================================
// FUNÇÃO GENÉRICA PARA EXTRAIR FILMES (lista)
// ================================================================
function extrairFilmes(html) {
  const $ = cheerio.load(html);
  const filmes = [];

  // Na página inicial, os filmes estão em div.filme
  $('.filme').each((i, el) => {
    const item = $(el);
    const linkEl = item.find('a');
    const href = linkEl.attr('href') || '';
    const slug = href.replace('/assistir/', '').replace('/', '');
    const titulo = item.find('.title').text().trim();
    const ano = item.find('.year').text().trim();
    const imagem = item.find('img').attr('data-src') || item.find('img').attr('src') || '';
    let nota = 0;
    const notaEl = item.find('.tt-imdb');
    if (notaEl.length) {
      nota = parseFloat(notaEl.text().trim()) || 0;
    }
    const generos = [];
    const genEl = item.find('.tt-gen');
    if (genEl.length) {
      generos.push(genEl.text().trim());
    }
    if (titulo && slug) {
      filmes.push({
        titulo,
        slug,
        ano,
        imagem,
        nota,
        generos,
        link_assistir: href.startsWith('http') ? href : `${URL_BASE}${href}`
      });
    }
  });

  return filmes;
}

// ================================================================
// TELÃO – LISTA TODOS OS FILMES (PÁGINA INICIAL)
// ================================================================
async function getTelao(pagina = 1) {
  const url = pagina === 1 ? `${URL_BASE}/` : `${URL_BASE}/home?p=${pagina}`;
  const { data: html } = await axios.get(url, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  return extrairFilmes(html);
}

// ================================================================
// SESSÃO – FILMES POR ANO
// ================================================================
async function getSessao(ano, pagina = 1) {
  const url = pagina === 1 ? `${URL_BASE}/ano/${ano}` : `${URL_BASE}/ano/${ano}?p=${pagina}`;
  const { data: html } = await axios.get(url, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  return extrairFilmes(html);
}

// ================================================================
// ALFABETO – FILMES POR LETRA
// ================================================================
async function getAlfabeto(letra, pagina = 1) {
  const url = pagina === 1 ? `${URL_BASE}/letra/${letra}` : `${URL_BASE}/letra/${letra}?p=${pagina}`;
  const { data: html } = await axios.get(url, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  return extrairFilmes(html);
}

// ================================================================
// GÊNEROS – FILMES POR GÊNERO
// ================================================================
async function getGenero(genero, pagina = 1) {
  const url = pagina === 1 ? `${URL_BASE}/genero/${genero}` : `${URL_BASE}/genero/${genero}?p=${pagina}`;
  const { data: html } = await axios.get(url, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  return extrairFilmes(html);
}

// ================================================================
// BILHETERIA – DESTAQUES (CARROSSEL DA HOME)
// ================================================================
async function getBilheteria() {
  const { data: html } = await axios.get(`${URL_BASE}/`, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  const $ = cheerio.load(html);
  const destaques = [];
  $('.scrolling-wrapper .card').each((i, el) => {
    const card = $(el);
    const link = card.find('a').attr('href') || '';
    const slug = link.replace('/assistir/', '').replace('/', '');
    const img = card.find('img').attr('data-src') || card.find('img').attr('src') || '';
    const titulo = card.find('a').attr('title') || '';
    if (slug && titulo) {
      destaques.push({ titulo, slug, imagem: img, link_assistir: link });
    }
  });
  return destaques;
}

// ================================================================
// RADAR – BUSCA AO VIVO (AUTOSEARCH)
// ================================================================
async function getRadarLive(termo) {
  const { data } = await axios.get(`${URL_BASE}/autosearch/${termo}`, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  return data; // já é um array JSON
}

// ================================================================
// FILME – DETALHES + RECOMENDADOS
// ================================================================
async function getFilme(slug) {
  const url = `${URL_BASE}/assistir/${slug}`;
  const { data: html } = await axios.get(url, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  const $ = cheerio.load(html);

  const titulo = $('.infos h2').text().trim() || '';
  const ano = $('.infos .info').first().text().trim() || '';
  const duracao = $('.infos .info').eq(1).text().trim() || '';
  const genero = $('.infos .info').eq(2).text().trim() || '';
  const sinopse = $('.infos .sinopse').text().trim() || '';
  const imagem = $('.poster img').attr('src') || '';
  let nota = 0;
  const notaEl = $('.imdb span');
  if (notaEl.length) {
    nota = parseFloat(notaEl.text().trim()) || 0;
  }
  const trailer = $('.trailer').attr('href') || '';

  // Recomendados (scrolling-wrapper)
  const recomendados = [];
  $('.scrolling-wrapper .card').each((i, el) => {
    const card = $(el);
    const link = card.find('a').attr('href') || '';
    const slugRec = link.replace('/assistir/', '').replace('/', '');
    const img = card.find('img').attr('data-src') || card.find('img').attr('src') || '';
    const tituloRec = card.find('a').attr('title') || '';
    if (slugRec && tituloRec) {
      recomendados.push({ titulo: tituloRec, slug: slugRec, imagem: img, link_assistir: link });
    }
  });

  return {
    titulo,
    slug,
    ano,
    duracao,
    genero,
    sinopse,
    imagem,
    nota,
    trailer,
    recomendados
  };
}

// ================================================================
// INGRESSO – PLAYER (EXTRAI O LINK DIRETO DO MP4)
// ================================================================
async function getIngresso(slug) {
  // 1. Acessa a página do filme para pegar o link do player
  const paginaFilme = await axios.get(`${URL_BASE}/assistir/${slug}`, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  const $ = cheerio.load(paginaFilme.data);
  const playerLink = $('.links_dub a').attr('href'); // ex: /player/super-mario-galaxy-o-filme?player=1
  if (!playerLink) {
    throw new Error('Player não encontrado');
  }

  // 2. Faz requisição para o player (HTML com vídeo)
  const playerUrl = `${URL_BASE}${playerLink}`;
  const { data: playerHtml } = await axios.get(playerUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0',
      'Referer': `${URL_BASE}/assistir/${slug}`
    }
  });

  // 3. Extrai o source src do vídeo (ex: //topfilmes.biz/direct/...)
  const $player = cheerio.load(playerHtml);
  const sourceSrc = $player('video source').attr('src');
  if (!sourceSrc) {
    throw new Error('Source do vídeo não encontrado');
  }
  const directUrl = sourceSrc.startsWith('//') ? `https:${sourceSrc}` : sourceSrc;

  // 4. Segue o redirecionamento 302 para obter o link final (MediaFire)
  // Usamos axios com maxRedirects: 0 para capturar o Location
  try {
    const response = await axios.get(directUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Referer': playerUrl
      },
      maxRedirects: 0,
      validateStatus: status => status === 302
    });
    const finalUrl = response.headers.location;
    if (!finalUrl) {
      throw new Error('Redirecionamento não contém Location');
    }
    return { direct_url: finalUrl, player_url: directUrl };
  } catch (error) {
    // Se não houver redirecionamento (já é o link final), retorna o próprio
    return { direct_url: directUrl, player_url: directUrl };
  }
}

module.exports = {
  getTelao,
  getSessao,
  getAlfabeto,
  getGenero,
  getBilheteria,
  getRadarLive,
  getFilme,
  getIngresso
};
