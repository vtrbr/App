module.exports = {
  PORT: process.env.PORT || 7200,
  URL_BASE: 'https://topfilmes.biz',

  CACHE_TTL: {
    TELAO: 86400000,
    SESSAO: 86400000,
    ALFABETO: 86400000,
    GENEROS: 86400000,
    BILHETERIA: 3600000,
    RADAR: 3600000,
    FILME: 86400000,
    INGRESSO: 86400000
  },

  GENEROS: [
    'acao', 'animacao', 'comedia', 'drama', 'documentario',
    'fantasia', 'faroeste', 'ficcao-cientifica', 'misterio',
    'nacionais', 'policial', 'romance', 'suspense', 'terror'
  ],

  ANOS: Array.from({ length: 87 }, (_, i) => String(1940 + i)),
  TOTAL_PAGINAS: 146
};
