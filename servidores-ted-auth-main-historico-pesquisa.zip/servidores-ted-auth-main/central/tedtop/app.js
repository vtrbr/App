const express = require('express');
const cors = require('./middleware/cors');
const { PORT } = require('./config/constants');

const telao = require('./routes/telao');
const sessao = require('./routes/sessao');
const alfabeto = require('./routes/alfabeto');
const generos = require('./routes/generos');
const bilheteria = require('./routes/bilheteria');
const radar = require('./routes/radar');
const filme = require('./routes/filme');
const ingresso = require('./routes/ingresso');

const app = express();
app.use(cors);
app.use(express.json());

app.use('/telao', telao);
app.use('/sessao', sessao);
app.use('/alfabeto', alfabeto);
app.use('/generos', generos);
app.use('/bilheteria', bilheteria);
app.use('/radar', radar);
app.use('/filme', filme);
app.use('/ingresso', ingresso);

app.listen(PORT, () => {
  console.log(`🎬 Servidor TOPFILMES rodando na porta ${PORT}`);
  console.log(`📽️  Rotas: /telao, /sessao, /alfabeto, /generos, /bilheteria, /radar, /filme, /ingresso`);
});

module.exports = app;
