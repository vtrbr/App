## 📚 **DOCUMENTAÇÃO COMPLETA DAS APIs**

Esta documentação cobre todos os endpoints disponíveis nos dois servidores:

- **Servidor NovelasFlix** – conteúdo principal (filmes, séries, animações, agenda, favoritos/histórico com autenticação)
- **Servidor TopFilmes** – catálogo de filmes com filtros especiais (ano, letra, gênero) e player funcional

---

# 1. SERVIDOR NOVELASFLIX

**Base URL:** `https://api-novelasflix.com` ou `http://localhost:7100` (desenvolvimento)

**Autenticação:**  
Apenas os endpoints de favoritos e histórico exigem um token JWT (ou similar) enviado no cabeçalho `x-access-token`. Os demais endpoints são públicos.

---

## 1.1 ENDPOINTS DE HOME

### 1.1.1 Carousel (destaques fixos)

- **Endpoint:** `GET /api/home/carousel`
- **Descrição:** Retorna os destaques em destaque (carrossel) – conteúdo fixo (não atualiza).
- **Resposta:**
  ```json
  {
    "fonte": "fixo",
    "total": 5,
    "itens": [
      {
        "titulo": "A Casa do Dragão – House of the Dragon",
        "imagem": "https://image.tmdb.org/t/p/original/...",
        "logo": "https://image.tmdb.org/t/p/w500/...",
        "nota": 8.3,
        "ano": "2022",
        "tipo": "Série",
        "descricao": "...",
        "generos": ["Action & Adventure", "Drama", "Sci-Fi & Fantasy"],
        "link_assistir": "https://novelasflix.video/drama/...",
        ...
      }
    ]
  }
  ```

### 1.1.2 Agenda de lançamentos (MegaCine)

- **Endpoint:** `GET /api/home/agenda`
- **Descrição:** Retorna os próximos episódios/séries agendados (scraping do MegaCine). Cache de 2 horas.
- **Resposta:**
  ```json
  {
    "fonte": "scraping",
    "total_dias": 3,
    "total_episodios": 12,
    "dias": [
      {
        "nome": "Hoje",
        "data": "2026-09-09",
        "data_formatada": "09/09/2026",
        "tipo": "hoje",
        "total_episodios": 4,
        "episodios": [
          {
            "titulo": "Episódio 5",
            "serie": "A Casa do Dragão",
            "episodio": "T2 E5",
            "temporada": 2,
            "numero": 5,
            "horario": "21:00",
            "link": "https://megacine.quest/..."
          }
        ]
      }
    ]
  }
  ```

### 1.1.3 Lançamentos (Novos online)

- **Endpoint:** `GET /api/home/lancamentos`
- **Descrição:** Retorna os conteúdos recentemente adicionados (scraping da home). Cache 1 hora.
- **Resposta:**
  ```json
  {
    "fonte": "scraping",
    "total": 20,
    "titulo_secao": "Assistir Novos Online",
    "link_ver_tudo": "/new.html",
    "resultados": [
      {
        "titulo": "Matrix 4",
        "imagem": "https://...",
        "nota": 7.5,
        "ano": "2026",
        "generos": ["Ação", "Ficção"],
        "tipo": "Filme",
        "link_assistir": "https://novelasflix.video/..."
      }
    ]
  }
  ```

### 1.1.4 Últimos filmes adicionados

- **Endpoint:** `GET /api/ultimos-filmes`
- **Descrição:** Retorna os últimos filmes adicionados (baseado no HTML da home). Cache 1 hora.
- **Resposta:**
  ```json
  {
    "fonte": "scraping",
    "total": 10,
    "filmes": [
      {
        "titulo": "Matrix 4",
        "imagem": "https://...",
        "nota": 7.5,
        "ano": "2026",
        "generos": ["Ação", "Ficção"],
        "link_assistir": "https://novelasflix.video/..."
      }
    ]
  }
  ```

---

## 1.2 ENDPOINTS DE FILMES

### 1.2.1 Stream completo de filmes

- **Endpoint:** `GET /api/filmes/stream`
- **Descrição:** Retorna todos os filmes do catálogo. Primeiro busca no Firestore (cache persistente), se não houver, faz scraping de todas as 435 páginas (streaming chunked). O resultado é salvo no Firestore para futuras consultas.
- **Resposta (se Firestore):**
  ```json
  {
    "fonte": "firestore",
    "total": 15000,
    "atualizado_em": "2026-09-09T...",
    "filmes": [ ... ] // array com objetos contendo titulo, imagem, nota, ano, generos, link_assistir, pagina
  }
  ```
- **Resposta (durante scraping):** resposta chunked (streaming) com estrutura similar.

### 1.2.2 Detalhes de um filme

- **Endpoint:** `GET /api/filme/:categoria/:slug`
- **Parâmetros:**
  - `categoria` – categoria da URL (ex: drama, comedia)
  - `slug` – slug do filme (ex: `6068-a-casa-do-dragao-noads`)
- **Resposta:**
  ```json
  {
    "titulo": "A Casa do Dragão",
    "imagem": "https://...",
    "nota": 8.3,
    "ano": "2022",
    "duracao": 55,
    "descricao": "...",
    "diretores": ["Miguel Sapochnik"],
    "atores": ["Emma D'Arcy", "Matt Smith"],
    "generos": ["Action & Adventure", "Drama"],
    "tipo": "Filme",
    "categoria": "drama",
    "slug": "6068-a-casa-do-dragao-noads",
    "recomendados": [ ... ] // lista de objetos com titulo, imagem, nota, ano, link_assistir
  }
  ```

### 1.2.3 Player (M3U8)

- **Endpoint:** `GET /api/filme-player/:categoria/:slug`
- **Descrição:** Retorna o conteúdo M3U8 para o player (usado para streaming HLS).
- **Resposta:** arquivo `.m3u8` (texto).

### 1.2.4 Informações do filme (inclui itemId e URL do M3U8)

- **Endpoint:** `GET /api/filme-info/:categoria/:slug`
- **Resposta:**
  ```json
  {
    "titulo": "A Casa do Dragão",
    "imagem": "https://...",
    "nota": 8.3,
    "ano": "2022",
    "duracao": 55,
    "descricao": "...",
    "categoria": "drama",
    "slug": "6068-a-casa-do-dragao-noads",
    "item_id": "12345",
    "m3u8_url": "https://novelasflix.video/.../playlist.m3u8",
    "player_url": "https://novelasflix.video/drama/6068-a-casa-do-dragao-noads"
  }
  ```

---

## 1.3 ENDPOINTS DE SÉRIES

### 1.3.1 Stream completo de séries

- **Endpoint:** `GET /api/series/stream`
- **Descrição:** Similar ao `/api/filmes/stream`, mas para séries (41 páginas). Cache no Firestore.
- **Resposta:** análogo à resposta de filmes, com `series` no lugar de `filmes`.

### 1.3.2 Listar temporadas de uma série

- **Endpoint:** `GET /api/serie/:categoria/:slug/temporadas`
- **Resposta:**
  ```json
  {
    "serie": "A Casa do Dragão",
    "categoria": "drama",
    "slug": "6068-a-casa-do-dragao-noads",
    "total_temporadas": 2,
    "temporadas": [
      {
        "numero": 1,
        "titulo": "Temporada 1",
        "imagem": "https://...",
        "link": "https://novelasflix.video/drama/6068-a-casa-do-dragao-noads--s1"
      },
      ...
    ]
  }
  ```

### 1.3.3 Listar episódios de uma temporada

- **Endpoint:** `GET /api/serie/:categoria/:slug/temporada/:num/episodios`
- **Resposta:**
  ```json
  {
    "serie": "A Casa do Dragão",
    "categoria": "drama",
    "slug": "6068-a-casa-do-dragao-noads",
    "temporada": 1,
    "total_episodios": 10,
    "episodios": [
      {
        "numero": 1,
        "nome": "Episode 1",
        "titulo": "The Heirs of the Dragon",
        "imagem": "https://...",
        "link": "https://novelasflix.video/drama/6068-a-casa-do-dragao-noads--s1e1",
        "ativo": true
      },
      ...
    ]
  }
  ```

---

## 1.4 ENDPOINTS DE ANIMAÇÕES

### 1.4.1 Stream completo de animações

- **Endpoint:** `GET /api/animacoes/stream`
- **Descrição:** Similar ao `/api/filmes/stream`, para animações (31 páginas). Cache no Firestore.
- **Resposta:** análogo, com `animacoes` no lugar de `filmes`.

---

## 1.5 ENDPOINTS DE GÊNEROS

### 1.5.1 Stream de um gênero específico

- **Endpoint:** `GET /api/genero/:slug/stream` (onde `:slug` pode ser `drama`, `suspense`, `aventura`, `acao`, `ficcao`, `comedia`, `terror`, `romance`, `ficcao-cientifica`)
- **Descrição:** Retorna todos os itens daquele gênero (com cache no Firestore). Faz streaming de todas as páginas do gênero.
- **Resposta:** similar ao `/api/filmes/stream`, com `resultados` e metadados do gênero.

### 1.5.2 Listar uma página de um gênero

- **Endpoint:** `GET /api/genero/:slug/page/:num`
- **Resposta:**
  ```json
  {
    "genero": "acao",
    "total": 20,
    "total_paginas": 149,
    "pagina_atual": 1,
    "resultados": [ ... ] // lista de filmes/séries/outros daquele gênero
  }
  ```

---

## 1.6 ENDPOINTS DE BUSCA

### 1.6.1 Busca (POST)

- **Endpoint:** `POST /api/buscar`
- **Body (JSON):**
  ```json
  { "query": "matrix", "pagina": 1 }
  ```
- **Resposta:**
  ```json
  {
    "query": "matrix",
    "total": 10,
    "total_paginas": 1,
    "pagina_atual": 1,
    "has_next": false,
    "resultados": [ ... ] // itens encontrados (com titulo, imagem, nota, ano, generos, tipo, link_assistir)
  }
  ```

### 1.6.2 Busca (GET)

- **Endpoint:** `GET /api/buscar/:query?pagina=1`
- **Resposta:** igual ao POST.

---

## 1.7 ENDPOINTS DE USUÁRIO (PROTEGIDOS POR TOKEN)

> **Cabeçalho necessário:** `x-access-token: <seu_token>`

### 1.7.1 Adicionar/remover favorito

- **Endpoint:** `POST /api/favorites/toggle`
- **Body (JSON):**
  ```json
  {
    "filmeId": "123",
    "titulo": "Matrix",
    "thumb": "https://..."
  }
  ```
- **Resposta:**
  ```json
  {
    "success": true,
    "message": "Adicionado aos favoritos",
    "favorited": true
  }
  ```
  ou
  ```json
  {
    "success": true,
    "message": "Removido dos favoritos",
    "favorited": false
  }
  ```

### 1.7.2 Listar favoritos

- **Endpoint:** `GET /api/favorites/list`
- **Resposta:**
  ```json
  {
    "success": true,
    "favoritos": [
      {
        "filmeId": "123",
        "titulo": "Matrix",
        "thumb": "https://...",
        "adicionadoEm": "2026-09-09T..."
      }
    ]
  }
  ```

### 1.7.3 Salvar progresso no histórico

- **Endpoint:** `POST /api/history/save-progress`
- **Body (JSON):**
  ```json
  {
    "filmeId": "123",
    "titulo": "Matrix",
    "tempo": "01:30:00",
    "thumb": "https://..."
  }
  ```
- **Resposta:**
  ```json
  {
    "success": true,
    "message": "Progresso salvo com sucesso"
  }
  ```

### 1.7.4 Obter histórico (continuar assistindo)

- **Endpoint:** `GET /api/history/continue-watching`
- **Resposta:**
  ```json
  {
    "success": true,
    "continuarAssistindo": [
      {
        "filmeId": "123",
        "titulo": "Matrix",
        "tempo": "01:30:00",
        "thumb": "https://...",
        "ultimoAcesso": "2026-09-09T..."
      }
    ]
  }
  ```

---

# 2. SERVIDOR TOPFILMES

**Base URL:** `https://api-topfilmes.com` ou `http://localhost:7200` (desenvolvimento)

**Autenticação:** nenhuma (público).

---

## 2.1 ENDPOINT: TELÃO (listagem geral)

- **Endpoint:** `GET /telao?pagina=1`
- **Descrição:** Retorna a lista de filmes da página inicial (146 páginas no total).
- **Parâmetros:** `pagina` (opcional, padrão 1)
- **Resposta:**
  ```json
  {
    "pagina": 1,
    "total": 20,
    "filmes": [
      {
        "titulo": "Isto Não é um Teste",
        "slug": "isto-nao-e-um-teste",
        "ano": "2026",
        "imagem": "https://image.tmdb.org/t/p/w342/...",
        "nota": 5.6,
        "generos": ["Terror"],
        "link_assistir": "https://topfilmes.biz/assistir/isto-nao-e-um-teste"
      }
    ]
  }
  ```

---

## 2.2 ENDPOINT: SESSÃO (por ano)

- **Endpoint:** `GET /sessao/ano/:ano?pagina=1`
- **Descrição:** Retorna os filmes de um ano específico. Anos disponíveis: 1940 a 2026.
- **Parâmetros:** `ano` (obrigatório na URL), `pagina` (opcional)
- **Resposta:** similar ao `/telao`, mas com campo `ano`.

---

## 2.3 ENDPOINT: ALFABETO (por letra)

- **Endpoint:** `GET /alfabeto/:letra?pagina=1`
- **Descrição:** Retorna os filmes cujo título começa com a letra especificada (A-Z, 0-9).
- **Parâmetros:** `letra` (obrigatório), `pagina` (opcional)
- **Resposta:** similar ao `/telao`, com campo `letra`.

---

## 2.4 ENDPOINT: GÊNEROS (por gênero)

- **Endpoint:** `GET /generos/:genero?pagina=1`
- **Descrição:** Retorna os filmes de um gênero específico. Gêneros disponíveis: `acao`, `animacao`, `comedia`, `drama`, `documentario`, `fantasia`, `faroeste`, `ficcao-cientifica`, `misterio`, `nacionais`, `policial`, `romance`, `suspense`, `terror`.
- **Parâmetros:** `genero` (obrigatório), `pagina` (opcional)
- **Resposta:** similar ao `/telao`, com campo `genero`.

---

## 2.5 ENDPOINT: BILHETERIA (destaques)

- **Endpoint:** `GET /bilheteria`
- **Descrição:** Retorna os filmes em destaque (carrossel da página inicial).
- **Resposta:**
  ```json
  {
    "total": 15,
    "destaques": [
      {
        "titulo": "Toy Story 5",
        "slug": "toy-story-5",
        "imagem": "https://image.tmdb.org/t/p/w342/...",
        "link_assistir": "https://topfilmes.biz/assistir/toy-story-5"
      }
    ]
  }
  ```

---

## 2.6 ENDPOINT: RADAR (busca)

### 2.6.1 Busca ao vivo (autosearch)

- **Endpoint:** `GET /radar/live/:termo`
- **Descrição:** Busca em tempo real enquanto o usuário digita. Retorna um array de sugestões (JSON diretamente do autosearch do site).
- **Resposta:** ex:
  ```json
  [
    { "nome": "Matrix", "slug": "matrix-2024", "ano": "2026", "tipo": "filme" }
  ]
  ```

### 2.6.2 Busca normal

- **Endpoint:** `GET /radar?q=termo`
- **Descrição:** Busca completa. Atualmente usa o mesmo mecanismo do autosearch (retorna array de sugestões, mas pode ser adaptado para buscar mais resultados).
- **Resposta:** similar ao live, com campo `termo`.

---

## 2.7 ENDPOINT: FILME (detalhes + recomendações)

- **Endpoint:** `GET /filme/:slug`
- **Descrição:** Retorna informações detalhadas do filme, incluindo sinopse, trailer, nota e lista de filmes recomendados.
- **Resposta:**
  ```json
  {
    "titulo": "Super Mario Galaxy: O Filme",
    "slug": "super-mario-galaxy-o-filme",
    "ano": "2026",
    "duracao": "95 min",
    "genero": "Animação",
    "sinopse": "Depois de salvar o Reino dos Cogumelos...",
    "imagem": "https://image.tmdb.org/t/p/w342/...",
    "nota": 8.2,
    "trailer": "https://www.youtube.com/watch?v=...",
    "recomendados": [
      {
        "titulo": "Toy Story 5",
        "slug": "toy-story-5",
        "imagem": "https://...",
        "link_assistir": "https://topfilmes.biz/assistir/toy-story-5"
      }
    ]
  }
  ```

---

## 2.8 ENDPOINT: INGRESSO (player)

- **Endpoint:** `GET /ingresso/:slug`
- **Descrição:** Retorna o link direto para o arquivo de vídeo (MP4). O servidor faz o scraping do player, extrai o source e segue os redirecionamentos para obter a URL final (geralmente MediaFire).
- **Resposta:**
  ```json
  {
    "direct_url": "https://download2392.mediafire.com/.../The.Super.Mario.Galaxy.Movie.2026.mp4",
    "player_url": "https://topfilmes.biz/direct/mf/.../hd?expires=..."
  }
  ```
- **Uso:** O frontend pode usar `direct_url` diretamente como `src` de um elemento `<video>` ou player HTML5.

---

# 3. CONSIDERAÇÕES GERAIS

- **Cache:** Ambos os servidores utilizam cache em memória com TTLs variados. Os endpoints de stream (completos) podem demorar na primeira requisição, mas depois ficam em cache (Firestore para NovelasFlix, memória para TopFilmes).
- **Erros:** Em caso de falha, os servidores retornam JSON com `erro` e mensagem descritiva.
- **CORS:** Ambos os servidores estão configurados para permitir requisições de origens específicas (incluindo `localhost` e domínios de produção).
- **Headers:** Para endpoints protegidos, lembre-se de enviar o token no cabeçalho `x-access-token`.

---

**Fim da documentação.** Qualquer dúvida, consulte a implementação ou entre em contato.
