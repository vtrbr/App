// ================================================================
// TOKEN MIDDLEWARE (APENAS PARA FAVORITOS/HISTÓRICO)
// ================================================================

const { dbAuth } = require('../config/firebase');

module.exports = async (req, res, next) => {
  try {
    const token = req.headers['x-access-token'];
    
    if (!token) {
      return res.status(401).json({ 
        success: false, 
        error: 'Token não fornecido' 
      });
    }
    
    const tokenDoc = await dbAuth.collection('tokens').doc(token).get();
    
    if (!tokenDoc.exists) {
      return res.status(401).json({ 
        success: false, 
        error: 'Token inválido' 
      });
    }
    
    const tokenData = tokenDoc.data();
    
    if (tokenData.status !== 'active') {
      return res.status(403).json({ 
        success: false, 
        error: 'Token bloqueado' 
      });
    }
    
    req.token = token;
    req.tokenData = tokenData;
    next();
    
  } catch (error) {
    console.error('❌ Erro no middleware:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Erro interno' 
    });
  }
};
