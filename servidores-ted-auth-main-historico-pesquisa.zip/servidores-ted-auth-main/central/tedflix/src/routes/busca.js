// ================================================================
// ROTAS: BUSCA
// ================================================================

const router = require('express').Router();
const axios = require('axios');
const cheerio = require('cheerio');
const { URL_BASE } = require('../config/constants');
const { getCookie } = require('../services/scraper');

// ================================================================
// POST /api/buscar
// ================================================================
router.post('/buscar', async (req, res) => {
  try {
    const { query, pagina } = req.body;
    const searchQuery = query || req.query.q || req.query.query || '';
    const page = parseInt(pagina) || 1;

    if (!searchQuery || searchQuery.trim().length < 2) {
      return res.json({
        query: searchQuery,
        total: 0,
        resultados: [],
        mensagem: 'Digite pelo menos 2 caracteres'
      });
    }

    console.log(`🔍 Buscando: "${searchQuery}" - Página ${page}`);

    const response = await axios.post(
      `${URL_BASE}/`,
      `do=search&subaction=search&story=${encodeURIComponent(searchQuery.trim())}`,
      {
        headers: {
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
          'accept-encoding': 'gzip, deflate, br, zstd',
          'accept-language': 'pt-BR,pt;q=0.9',
          'cache-control': 'no-cache',
          'content-type': 'application/x-www-form-urlencoded',
          'cookie': getCookie() || 'PHPSESSID=1gje0s9sb6nhova0o3c37toc57',
          'origin': URL_BASE,
          'pragma': 'no-cache',
          'priority': 'u=0, i',
          'referer': `${URL_BASE}/`,
          'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-platform': '"Windows"',
          'sec-fetch-dest': 'document',
          'sec-fetch-mode': 'navigate',
          'sec-fetch-site': 'same-origin',
          'sec-fetch-user': '?1',
          'sec-gpc': '1',
          'upgrade-insecure-requests': '1',
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'
        },
        timeout: 15000,
        maxRedirects: 5
      }
    );

    const html = response.data;
    const $ = cheerio.load(html);
    const resultados = [];

    $('#dle-content .default.poster.grid-item').each((i, el) => {
      const item = $(el);
      const linkElement = item.find('.poster__title a');
      const link = linkElement.attr('href') || '';
      const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
      const imgElement = item.find('.poster__img img');
      const imagem = imgElement.attr('src') || '';
      const ano = item.find('.bslide__meta span').first().text().trim() || '';
      let nota = 0;
      const notaElement = item.find('.bslide__meta .rating');
      if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
      const generos = [];
      item.find('.onslide-cats a').each((j, catEl) => {
        const genero = $(catEl).text().trim();
        if (genero && genero !== 'Filmes' && genero !== 'Séries') generos.push(genero);
      });
      let tipo = 'Filme';
      const ultimoGenero = item.find('.onslide-cats a').last().text().trim();
      if (ultimoGenero === 'Séries' || link.includes('/series/')) tipo = 'Série';
      else if (ultimoGenero === 'Animação' || link.includes('/genero/animacao/')) tipo = 'Animação';
      if (titulo && link) {
        resultados.push({ titulo, imagem, nota, ano, generos, tipo, link_assistir: link });
      }
    });

    let totalPaginas = 1;
    const paginationLinks = $('.pagination .pagination__pages a');
    if (paginationLinks.length > 0) {
      const ultimoLink = paginationLinks.last();
      const ultimoNumero = parseInt(ultimoLink.text().trim());
      if (!isNaN(ultimoNumero) && ultimoNumero > totalPaginas) totalPaginas = ultimoNumero;
    }
    const hasNext = $('.pagination .pagination__pages-btn a[onclick*="list_submit"]').length > 0;
    res.json({ query: searchQuery, total: resultados.length, total_paginas: totalPaginas, pagina_atual: page, has_next: hasNext, resultados });
  } catch (error) {
    console.error('❌ Erro na busca:', error.message);
    res.status(500).json({ erro: 'Erro ao realizar busca', detalhe: error.message });
  }
});

// ================================================================
// GET /api/buscar/:query
// ================================================================
router.get('/buscar/:query', async (req, res) => {
  try {
    const query = req.params.query.trim();
    const pagina = parseInt(req.query.pagina) || 1;
    if (!query || query.length < 2) {
      return res.json({ query: query, total: 0, resultados: [], mensagem: 'Digite pelo menos 2 caracteres' });
    }
    console.log(`🔍 Buscando GET: "${query}" - Página ${pagina}`);
    const url = pagina === 1 
      ? `${URL_BASE}/index.php?do=search&subaction=search&story=${encodeURIComponent(query)}`
      : `${URL_BASE}/index.php?do=search&subaction=search&story=${encodeURIComponent(query)}&page=${pagina}`;
    const { data: html } = await axios.get(url, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(getCookie() && { 'cookie': getCookie() })
      },
      timeout: 15000
    });
    const $ = cheerio.load(html);
    const resultados = [];
    $('#dle-content .default.poster.grid-item').each((i, el) => {
      const item = $(el);
      const linkElement = item.find('.poster__title a');
      const link = linkElement.attr('href') || '';
      const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
      const imgElement = item.find('.poster__img img');
      const imagem = imgElement.attr('src') || '';
      const ano = item.find('.bslide__meta span').first().text().trim() || '';
      let nota = 0;
      const notaElement = item.find('.bslide__meta .rating');
      if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
      const generos = [];
      item.find('.onslide-cats a').each((j, catEl) => {
        const genero = $(catEl).text().trim();
        if (genero && genero !== 'Filmes' && genero !== 'Séries') generos.push(genero);
      });
      let tipo = 'Filme';
      const ultimoGenero = item.find('.onslide-cats a').last().text().trim();
      if (ultimoGenero === 'Séries' || link.includes('/series/')) tipo = 'Série';
      else if (ultimoGenero === 'Animação' || link.includes('/genero/animacao/')) tipo = 'Animação';
      if (titulo && link) {
        resultados.push({ titulo, imagem, nota, ano, generos, tipo, link_assistir: link });
      }
    });
    let totalPaginas = 1;
    const paginationLinks = $('.pagination .pagination__pages a');
    if (paginationLinks.length > 0) {
      const ultimoLink = paginationLinks.last();
      const ultimoNumero = parseInt(ultimoLink.text().trim());
      if (!isNaN(ultimoNumero) && ultimoNumero > totalPaginas) totalPaginas = ultimoNumero;
    }
    res.json({ query: query, total: resultados.length, total_paginas: totalPaginas, pagina_atual: pagina, resultados });
  } catch (error) {
    console.error('❌ Erro na busca GET:', error.message);
    res.status(500).json({ erro: 'Erro ao realizar busca', detalhe: error.message });
  }
});

module.exports = router;
