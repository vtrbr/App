// ================================================================
// ROTAS: GÊNEROS
// ================================================================

const router = require('express').Router();
const axios = require('axios');
const cheerio = require('cheerio');
const { getCache, setCache } = require('../services/cache');
const { salvarEmBlocos, buscarTodosBlocos } = require('../services/firestore');
const { URL_BASE } = require('../config/constants');
const { getCookie } = require('../services/scraper');

// ================================================================
// FUNÇÃO GENÉRICA PARA STREAM DE GÊNEROS
// ================================================================
async function streamGeneroComFirestore(req, res, genero, totalPaginas) {
  try {
    const nomeGenero = genero.charAt(0).toUpperCase() + genero.slice(1);
    const colecaoNome = `genero_${genero}`;

    try {
      const firestoreData = await buscarTodosBlocos(colecaoNome);
      if (firestoreData && firestoreData.itens.length > 0) {
        console.log(`✅ Gênero ${nomeGenero} do Firestore: ${firestoreData.total} itens`);
        return res.json({
          fonte: 'firestore',
          genero: nomeGenero,
          slug: genero,
          total: firestoreData.total,
          atualizado_em: firestoreData.atualizado_em,
          resultados: firestoreData.itens
        });
      }
    } catch (error) {
      console.warn(`⚠️ Erro ao buscar gênero ${genero} do Firestore:`, error.message);
    }

    console.log(`🎭 Gênero ${nomeGenero} não encontrado no Firestore, fazendo streaming...`);
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    res.write(`{\n  "fonte": "scraping",\n  "genero": "${nomeGenero}",\n`);
    res.write(`  "slug": "${genero}",\n`);
    res.write(`  "status": "carregando",\n`);
    res.write(`  "total_paginas": ${totalPaginas},\n`);
    res.write(`  "resultados": [\n`);

    let primeiro = true;
    let totalItens = 0;
    const itensParaSalvar = [];

    console.log(`🎭 Iniciando streaming de ${nomeGenero} (${totalPaginas} páginas)`);

    for (let pagina = 1; pagina <= totalPaginas; pagina++) {
      const url = pagina === 1 ? `${URL_BASE}/genero/${genero}/` : `${URL_BASE}/genero/${genero}/page/${pagina}/`;
      console.log(`🎭 Buscando ${nomeGenero} página ${pagina}/${totalPaginas}`);

      try {
        const { data: html } = await axios.get(url, {
          headers: {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'pt-BR,pt;q=0.9',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'priority': 'u=0, i',
            'referer': `${URL_BASE}/`,
            'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
            ...(getCookie() && { 'cookie': getCookie() })
          },
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: status => status < 500
        });

        const $ = cheerio.load(html);
        const itens = $('.default.poster.grid-item');

        if (itens.length === 0) {
          console.log(`⚠️ Nenhum item encontrado na página ${pagina} de ${nomeGenero}`);
          continue;
        }

        itens.each((i, el) => {
          const item = $(el);
          const linkElement = item.find('.poster__title a');
          const link = linkElement.attr('href') || '';
          const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
          const imgElement = item.find('.poster__img img');
          const imagem = imgElement.attr('src') || '';
          const ano = item.find('.bslide__meta span').first().text().trim() || '';
          let nota = 0;
          const notaElement = item.find('.bslide__meta .rating');
          if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
          const generos = [];
          item.find('.onslide-cats a').each((j, catEl) => {
            const generoCat = $(catEl).text().trim();
            if (generoCat && generoCat !== 'Filmes' && generoCat !== 'Séries' && generoCat !== nomeGenero) {
              generos.push(generoCat);
            }
          });
          let tipo = 'Filme';
          const ultimoGenero = item.find('.onslide-cats a').last().text().trim();
          if (ultimoGenero === 'Séries' || link.includes('/series/')) tipo = 'Série';
          else if (ultimoGenero === 'Animação' || link.includes('/genero/animacao/')) tipo = 'Animação';
          const resultado = { titulo, imagem, nota, ano, generos, tipo, link_assistir: link, pagina };
          itensParaSalvar.push(resultado);
          if (!primeiro) res.write(',\n');
          primeiro = false;
          res.write(JSON.stringify(resultado, null, 2));
          totalItens++;
        });

        res.write(`\n  // ✅ Página ${pagina}/${totalPaginas} carregada (${itens.length} itens)`);
        await new Promise(resolve => setTimeout(resolve, 150));
      } catch (err) {
        console.log(`❌ Erro página ${pagina} de ${nomeGenero}:`, err.message);
        res.write(`\n  // ⚠️ Erro na página ${pagina}: ${err.message}`);
        continue;
      }
    }

    if (itensParaSalvar.length > 0) {
      await salvarEmBlocos(colecaoNome, itensParaSalvar, 100);
    }

    res.write('\n  ],\n');
    res.write(`  "total_itens": ${totalItens},\n`);
    res.write(`  "paginas_processadas": ${totalPaginas},\n`);
    res.write(`  "status": "completo"\n`);
    res.write('}');
    res.end();

    console.log(`✅ Stream finalizado: ${totalItens} itens de ${nomeGenero} em ${totalPaginas} páginas`);
  } catch (error) {
    console.error(`❌ Erro no stream do gênero:`, error.message);
    if (!res.headersSent) {
      res.status(500).json({ erro: 'Erro ao processar stream', detalhe: error.message });
    } else {
      res.write('\n  // ❌ ERRO: ' + error.message + '\n');
      res.write('  }],\n  "status": "erro"\n}');
      res.end();
    }
  }
}

// ================================================================
// ROTAS DE GÊNEROS
// ================================================================

router.get('/drama/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'drama', 190);
});

router.get('/suspense/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'suspense', 144);
});

router.get('/aventura/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'aventura', 103);
});

router.get('/acao/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'acao', 149);
});

router.get('/ficcao/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'ficcao', 10);
});

router.get('/comedia/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'comedia', 127);
});

router.get('/terror/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'terror', 88);
});

router.get('/romance/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'romance', 55);
});

router.get('/ficcao-cientifica/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'ficcao-cientifica', 37);
});

// ================================================================
// /api/genero/:slug/page/:num
// ================================================================
router.get('/:slug/page/:num', async (req, res) => {
  try {
    const { slug, num } = req.params;
    const pagina = parseInt(num) || 1;
    const url = pagina === 1 ? `${URL_BASE}/genero/${slug}/` : `${URL_BASE}/genero/${slug}/page/${pagina}/`;
    console.log(`🎭 Buscando gênero ${slug} - página ${pagina}`);
    const { data: html } = await axios.get(url, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'referer': `${URL_BASE}/`,
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(getCookie() && { 'cookie': getCookie() })
      },
      timeout: 15000
    });
    const $ = cheerio.load(html);
    const resultados = [];
    $('.default.poster.grid-item').each((i, el) => {
      const item = $(el);
      const linkElement = item.find('.poster__title a');
      const link = linkElement.attr('href') || '';
      const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
      const imgElement = item.find('.poster__img img');
      const imagem = imgElement.attr('src') || '';
      const ano = item.find('.bslide__meta span').first().text().trim() || '';
      let nota = 0;
      const notaElement = item.find('.bslide__meta .rating');
      if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
      const generos = [];
      item.find('.onslide-cats a').each((j, catEl) => {
        const genero = $(catEl).text().trim();
        if (genero && genero !== 'Filmes' && genero !== 'Séries') generos.push(genero);
      });
      let tipo = 'Filme';
      const ultimoGenero = item.find('.onslide-cats a').last().text().trim();
      if (ultimoGenero === 'Séries' || link.includes('/series/')) tipo = 'Série';
      else if (ultimoGenero === 'Animação' || link.includes('/genero/animacao/')) tipo = 'Animação';
      if (titulo && link) {
        resultados.push({ titulo, imagem, nota, ano, generos, tipo, link_assistir: link });
      }
    });
    let totalPaginas = 1;
    const paginationLinks = $('.pagination .pagination__pages a');
    if (paginationLinks.length > 0) {
      const ultimoLink = paginationLinks.last();
      const ultimoNumero = parseInt(ultimoLink.text().trim());
      if (!isNaN(ultimoNumero) && ultimoNumero > totalPaginas) totalPaginas = ultimoNumero;
    }
    res.json({ genero: slug, total: resultados.length, total_paginas: totalPaginas, pagina_atual: pagina, resultados });
  } catch (error) {
    console.error(`❌ Erro ao buscar gênero página:`, error.message);
    res.status(500).json({ erro: 'Erro ao buscar gênero', detalhe: error.message });
  }
});

module.exports = router;
