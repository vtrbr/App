// ================================================================
// ROTAS: HOME
// ================================================================

const router = require('express').Router();
const cheerio = require('cheerio');
const { getCache, setCache } = require('../services/cache');
const { CAROUSEL_FIXO } = require('../config/constants');
const { getHomeHTML, getCookie } = require('../services/scraper');
const { scrapeAgenda } = require('../services/agenda');

// ================================================================
// /api/home/carousel
// ================================================================
router.get('/carousel', async (req, res) => {
  res.json({
    fonte: 'fixo',
    total: CAROUSEL_FIXO.length,
    itens: CAROUSEL_FIXO
  });
});

// ================================================================
// /api/home/agenda
// ================================================================
router.get('/agenda', async (req, res) => {
  const cacheKey = 'home_agenda';
  
  const cached = getCache(cacheKey);
  if (cached && cached.dias && cached.dias.length > 0) {
    return res.json({ fonte: 'cache_memoria', ...cached });
  }

  try {
    console.log('📅 Cache EXPIRADO - Fazendo scraping da agenda...');
    const agendaData = await scrapeAgenda();
    
    setCache(cacheKey, agendaData, 7200000);
    console.log(`💾 Agenda salva no cache por 2 horas (${agendaData.dias.length} dias, ${agendaData.total_episodios} episódios)`);

    res.json({
      fonte: 'scraping',
      ...agendaData
    });

  } catch (error) {
    console.error('❌ Erro ao fazer scraping da agenda:', error);
    res.status(500).json({
      erro: 'Erro ao buscar agenda de lançamentos',
      detalhe: error.message
    });
  }
});

// ================================================================
// /api/home/lancamentos
// ================================================================
router.get('/lancamentos', async (req, res) => {
  const cacheKey = 'home_novos_online';
  
  const cached = getCache(cacheKey);
  if (cached) {
    return res.json({ fonte: 'cache_memoria', ...cached });
  }

  const HOME_HTML = getHomeHTML();
  if (!HOME_HTML) {
    return res.status(503).json({ 
      erro: 'Página inicial ainda não carregada. Tente novamente em alguns segundos.' 
    });
  }

  try {
    console.log('🆕 Fazendo scraping dos Novos Online...');
    const $ = cheerio.load(HOME_HTML);
    const resultados = [];

    $('.slick-home-generic[data-content="news"] .default.poster.grid-item, #slick-big .bslide').each((i, el) => {
      const item = $(el);
      const linkElement = item.find('.poster__title a, .bslide__poster a');
      const link = linkElement.attr('href') || '';
      const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
      const imgElement = item.find('.poster__img img, .bslide__poster img');
      const imagem = imgElement.attr('src') || '';
      const ano = item.find('.bslide__meta span').first().text().trim() || '';
      let nota = 0;
      const notaElement = item.find('.bslide__meta .rating');
      if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
      const generos = [];
      item.find('.onslide-cats a').each((j, catEl) => {
        const genero = $(catEl).text().trim();
        if (genero && genero !== 'Filmes' && genero !== 'Séries') generos.push(genero);
      });
      let tipo = 'Filme';
      const ultimoGenero = item.find('.onslide-cats a').last().text().trim();
      if (ultimoGenero === 'Séries' || link.includes('/series/')) tipo = 'Série';
      else if (ultimoGenero === 'Animação' || link.includes('/genero/animacao/')) tipo = 'Animação';
      
      if (titulo && link) {
        resultados.push({ titulo, imagem, nota, ano, generos, tipo, link_assistir: link });
      }
    });

    const responseData = {
      total: resultados.length,
      titulo_secao: 'Assistir Novos Online',
      link_ver_tudo: '/new.html',
      resultados
    };

    setCache(cacheKey, responseData, 3600000);
    res.json({ fonte: 'scraping', ...responseData });
  } catch (error) {
    console.error('Erro ao extrair novos online:', error);
    res.status(500).json({ erro: 'Erro ao extrair novos online' });
  }
});

// ================================================================
// /api/ultimos-filmes
// ================================================================
router.get('/ultimos-filmes', async (req, res) => {
  const cacheKey = 'ultimos_filmes';
  
  const cached = getCache(cacheKey);
  if (cached) {
    return res.json({ fonte: 'cache_memoria', filmes: cached });
  }

  const HOME_HTML = getHomeHTML();
  if (!HOME_HTML) {
    return res.status(503).json({ erro: 'Página inicial ainda não carregada. Tente novamente em alguns segundos.' });
  }

  try {
    console.log('🎬 Cache EXPIRADO - Fazendo scraping dos últimos filmes...');
    const $ = cheerio.load(HOME_HTML);
    const filmes = [];

    $('#slick-big .bslide').each((i, el) => {
      const item = $(el);
      const linkElement = item.find('.bslide__poster a');
      const link = linkElement.attr('href') || '';
      const imgElement = item.find('.bslide__poster img');
      const imagem = imgElement.attr('src') || '';
      const titulo = item.find('.bslide__title').text().trim() || '';
      const ano = item.find('.bslide__meta span').first().text().trim() || '';
      let nota = 0;
      const notaElement = item.find('.bslide__meta .rating');
      if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
      const generos = [];
      item.find('.onslide-cats a').each((j, catEl) => {
        const genero = $(catEl).text().trim();
        if (genero && genero !== 'Filmes') generos.push(genero);
      });
      filmes.push({ titulo, imagem, nota, ano, generos, link_assistir: link });
    });

    setCache(cacheKey, filmes, 3600000);
    console.log(`💾 Últimos filmes salvos no cache por 1 hora (${filmes.length} filmes)`);

    res.json({ 
      fonte: 'scraping', 
      total: filmes.length, 
      filmes 
    });

  } catch (error) {
    console.error('❌ Erro ao extrair últimos filmes:', error);
    res.status(500).json({ 
      erro: 'Erro ao extrair últimos filmes',
      detalhe: error.message 
    });
  }
});

module.exports = router;
