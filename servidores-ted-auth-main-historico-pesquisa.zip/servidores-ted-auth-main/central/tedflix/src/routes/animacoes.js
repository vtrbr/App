// ================================================================
// ROTAS: ANIMAÇÕES
// ================================================================

const router = require('express').Router();
const axios = require('axios');
const cheerio = require('cheerio');
const { salvarEmBlocos, buscarTodosBlocos } = require('../services/firestore');
const { URL_BASE } = require('../config/constants');
const { getCookie } = require('../services/scraper');

// ================================================================
// /api/animacoes/stream
// ================================================================
router.get('/stream', async (req, res) => {
  try {
    const firestoreData = await buscarTodosBlocos('animacoes');
    if (firestoreData && firestoreData.itens.length > 0) {
      console.log(`✅ Animações do Firestore: ${firestoreData.total} animações`);
      return res.json({
        fonte: 'firestore',
        total: firestoreData.total,
        atualizado_em: firestoreData.atualizado_em,
        animacoes: firestoreData.itens
      });
    }

    console.log('🎬 Animações não encontradas no Firestore, fazendo streaming...');
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    res.write('{\n  "fonte": "scraping",\n  "status": "carregando",\n  "total_paginas": 0,\n  "animacoes": [\n');

    let totalPaginas = 31;
    let primeiro = true;
    let totalAnimacoes = 0;
    const animacoesParaSalvar = [];

    console.log(`🎬 Iniciando streaming de animações (${totalPaginas} páginas)`);

    for (let pagina = 1; pagina <= totalPaginas; pagina++) {
      const url = pagina === 1 ? `${URL_BASE}/genero/animacao/` : `${URL_BASE}/genero/animacao/page/${pagina}/`;
      console.log(`🎬 Buscando animações página ${pagina}/${totalPaginas}`);

      try {
        const { data: html } = await axios.get(url, {
          headers: {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'pt-BR,pt;q=0.9',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'priority': 'u=0, i',
            'referer': `${URL_BASE}/series/`,
            'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
            ...(getCookie() && { 'cookie': getCookie() })
          },
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: status => status < 500
        });

        const $ = cheerio.load(html);
        const itens = $('.default.poster.grid-item');

        if (itens.length === 0) {
          console.log(`⚠️ Nenhuma animação encontrada na página ${pagina}`);
          break;
        }

        itens.each((i, el) => {
          const item = $(el);
          const linkElement = item.find('.poster__title a');
          const link = linkElement.attr('href') || '';
          const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
          const imgElement = item.find('.poster__img img');
          const imagem = imgElement.attr('src') || '';
          const ano = item.find('.bslide__meta span').first().text().trim() || '';
          let nota = 0;
          const notaElement = item.find('.bslide__meta .rating');
          if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
          const generos = [];
          item.find('.onslide-cats a').each((j, catEl) => {
            const genero = $(catEl).text().trim();
            if (genero && genero !== 'Animação') generos.push(genero);
          });
          const animacao = { titulo, imagem, nota, ano, generos, link_assistir: link, pagina };
          animacoesParaSalvar.push(animacao);
          if (!primeiro) res.write(',\n');
          primeiro = false;
          res.write(JSON.stringify(animacao, null, 2));
          totalAnimacoes++;
        });

        res.write(`\n  // ✅ Página ${pagina}/${totalPaginas} carregada (${itens.length} animações)`);
        await new Promise(resolve => setTimeout(resolve, 150));
      } catch (err) {
        console.log(`❌ Erro página ${pagina}:`, err.message);
        res.write(`\n  // ⚠️ Erro na página ${pagina}: ${err.message}`);
        continue;
      }
    }

    if (animacoesParaSalvar.length > 0) {
      await salvarEmBlocos('animacoes', animacoesParaSalvar, 100);
    }

    res.write('\n  ],\n');
    res.write(`  "total_animacoes": ${totalAnimacoes},\n`);
    res.write(`  "paginas_processadas": ${totalPaginas},\n`);
    res.write(`  "status": "completo"\n`);
    res.write('}');
    res.end();

    console.log(`✅ Stream finalizado: ${totalAnimacoes} animações em ${totalPaginas} páginas`);
  } catch (error) {
    console.error('❌ Erro no stream:', error);
    if (!res.headersSent) {
      res.status(500).json({ erro: 'Erro ao processar stream', detalhe: error.message });
    } else {
      res.write('\n  // ❌ ERRO: ' + error.message + '\n');
      res.write('  }],\n  "status": "erro"\n}');
      res.end();
    }
  }
});

module.exports = router;
