// ================================================================
// ROTAS: SÉRIES
// ================================================================

const router = require('express').Router();
const axios = require('axios');
const cheerio = require('cheerio');
const { getCache, setCache } = require('../services/cache');
const { salvarEmBlocos, buscarTodosBlocos } = require('../services/firestore');
const { URL_BASE } = require('../config/constants');
const { getCookie } = require('../services/scraper');

// ================================================================
// /api/series/stream
// ================================================================
router.get('/stream', async (req, res) => {
  try {
    const firestoreData = await buscarTodosBlocos('series');
    if (firestoreData && firestoreData.itens.length > 0) {
      console.log(`✅ Séries do Firestore: ${firestoreData.total} séries`);
      return res.json({
        fonte: 'firestore',
        total: firestoreData.total,
        atualizado_em: firestoreData.atualizado_em,
        series: firestoreData.itens
      });
    }

    console.log('📺 Séries não encontradas no Firestore, fazendo streaming...');
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    res.write('{\n  "fonte": "scraping",\n  "status": "carregando",\n  "total_paginas": 0,\n  "series": [\n');

    let totalPaginas = 41;
    let primeiro = true;
    let totalSeries = 0;
    const seriesParaSalvar = [];

    console.log(`📺 Iniciando streaming de séries (${totalPaginas} páginas)`);

    for (let pagina = 1; pagina <= totalPaginas; pagina++) {
      const url = pagina === 1 ? `${URL_BASE}/series/` : `${URL_BASE}/series/page/${pagina}/`;
      console.log(`📺 Buscando séries página ${pagina}/${totalPaginas}`);

      try {
        const { data: html } = await axios.get(url, {
          headers: {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'pt-BR,pt;q=0.9',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'priority': 'u=0, i',
            'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
            ...(getCookie() && { 'cookie': getCookie() })
          },
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: status => status < 500
        });

        const $ = cheerio.load(html);
        const itens = $('.default.poster.grid-item');

        if (itens.length === 0) {
          console.log(`⚠️ Nenhuma série encontrada na página ${pagina}`);
          break;
        }

        itens.each((i, el) => {
          const item = $(el);
          const linkElement = item.find('.poster__title a');
          const link = linkElement.attr('href') || '';
          const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
          const imgElement = item.find('.poster__img img');
          const imagem = imgElement.attr('src') || '';
          const ano = item.find('.bslide__meta span').first().text().trim() || '';
          let nota = 0;
          const notaElement = item.find('.bslide__meta .rating');
          if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
          const generos = [];
          item.find('.onslide-cats a').each((j, catEl) => {
            const genero = $(catEl).text().trim();
            if (genero && genero !== 'Séries') generos.push(genero);
          });
          const serie = { titulo, imagem, nota, ano, generos, link_assistir: link, pagina };
          seriesParaSalvar.push(serie);
          if (!primeiro) res.write(',\n');
          primeiro = false;
          res.write(JSON.stringify(serie, null, 2));
          totalSeries++;
        });

        res.write(`\n  // ✅ Página ${pagina}/${totalPaginas} carregada (${itens.length} séries)`);
        await new Promise(resolve => setTimeout(resolve, 150));
      } catch (err) {
        console.log(`❌ Erro página ${pagina}:`, err.message);
        res.write(`\n  // ⚠️ Erro na página ${pagina}: ${err.message}`);
        continue;
      }
    }

    if (seriesParaSalvar.length > 0) {
      await salvarEmBlocos('series', seriesParaSalvar, 100);
    }

    res.write('\n  ],\n');
    res.write(`  "total_series": ${totalSeries},\n`);
    res.write(`  "paginas_processadas": ${totalPaginas},\n`);
    res.write(`  "status": "completo"\n`);
    res.write('}');
    res.end();

    console.log(`✅ Stream finalizado: ${totalSeries} séries em ${totalPaginas} páginas`);
  } catch (error) {
    console.error('❌ Erro no stream:', error);
    if (!res.headersSent) {
      res.status(500).json({ erro: 'Erro ao processar stream', detalhe: error.message });
    } else {
      res.write('\n  // ❌ ERRO: ' + error.message + '\n');
      res.write('  }],\n  "status": "erro"\n}');
      res.end();
    }
  }
});

// ================================================================
// /api/serie/:categoria/:slug/temporadas
// ================================================================
router.get('/serie/:categoria/:slug/temporadas', async (req, res) => {
  try {
    const { categoria, slug } = req.params;
    const url = `${URL_BASE}/${categoria}/${slug}`;
    
    console.log(`📺 Buscando temporadas: ${categoria}/${slug}`);
    
    const { data: html } = await axios.get(url, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Cookie': getCookie() || 'PHPSESSID=1gje0s9sb6nhova0o3c37toc57'
      },
      timeout: 15000
    });

    const $ = cheerio.load(html);
    
    const titulo = $('.movieinfo h1').text().trim() || '';
    const temporadas = [];

    $('.seasons-v2 .season-link, .seasons .season-link').each((i, el) => {
      const link = $(el);
      const href = link.attr('href') || '';
      
      const seasonMatch = href.match(/--s(\d+)/);
      const numero = seasonMatch ? parseInt(seasonMatch[1]) : i + 1;
      
      const tituloTemp = link.find('.pstitle').text().trim() || `Temporada ${numero}`;
      
      const imagemStyle = link.find('.seasonimg').css('background-image') || '';
      const imagemMatch = imagemStyle.match(/url\(["']?([^"']*)["']?\)/);
      const imagem = imagemMatch ? imagemMatch[1] : '';
      
      temporadas.push({
        numero: numero,
        titulo: tituloTemp,
        imagem: imagem,
        link: href
      });
    });

    res.json({
      serie: titulo,
      categoria: categoria,
      slug: slug,
      total_temporadas: temporadas.length,
      temporadas: temporadas
    });

  } catch (error) {
    console.error('❌ Erro ao buscar temporadas:', error.message);
    res.status(500).json({ erro: 'Erro ao buscar temporadas', detalhe: error.message });
  }
});

// ================================================================
// /api/serie/:categoria/:slug/temporada/:num/episodios
// ================================================================
router.get('/serie/:categoria/:slug/temporada/:num/episodios', async (req, res) => {
  try {
    const { categoria, slug, num } = req.params;
    const temporadaNum = parseInt(num);
    const url = `${URL_BASE}/${categoria}/${slug}--s${temporadaNum}/`;
    
    console.log(`📺 Buscando episódios: ${categoria}/${slug} - Temporada ${temporadaNum}`);
    
    const { data: html } = await axios.get(url, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Cookie': getCookie() || 'PHPSESSID=1gje0s9sb6nhova0o3c37toc57'
      },
      timeout: 15000
    });

    const $ = cheerio.load(html);
    
    const tituloSerie = $('.movieinfo h1').text().trim() || '';
    const episodios = [];

    $('.seasoncontent .epi-link, .seasoncontent-v2 .epi-link').each((i, el) => {
      const ep = $(el);
      const href = ep.attr('href') || '';
      
      const epMatch = href.match(/--s\d+e(\d+)/);
      const numero = epMatch ? parseInt(epMatch[1]) : i + 1;
      
      const nome = ep.find('.epiname').text().trim() || `Episódio ${numero}`;
      const tituloEp = ep.find('.epinicename').text().trim() || '';
      
      const imagemStyle = ep.find('.epiframe').css('background-image') || '';
      const imagemMatch = imagemStyle.match(/url\(["']?([^"']*)["']?\)/);
      const imagem = imagemMatch ? imagemMatch[1] : '';
      
      const ativo = ep.hasClass('active');
      
      episodios.push({
        numero: numero,
        nome: nome,
        titulo: tituloEp,
        imagem: imagem,
        link: href,
        ativo: ativo
      });
    });

    episodios.sort((a, b) => a.numero - b.numero);

    res.json({
      serie: tituloSerie,
      categoria: categoria,
      slug: slug,
      temporada: temporadaNum,
      total_episodios: episodios.length,
      episodios: episodios
    });

  } catch (error) {
    console.error('❌ Erro ao buscar episódios:', error.message);
    res.status(500).json({ erro: 'Erro ao buscar episódios', detalhe: error.message });
  }
});

module.exports = router;
