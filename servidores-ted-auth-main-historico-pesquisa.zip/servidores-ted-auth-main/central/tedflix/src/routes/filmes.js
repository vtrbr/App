// ================================================================
// ROTAS: FILMES
// ================================================================

const router = require('express').Router();
const axios = require('axios');
const cheerio = require('cheerio');
const { getCache, setCache } = require('../services/cache');
const { salvarEmBlocos, buscarTodosBlocos } = require('../services/firestore');
const { URL_BASE, COOKIE_STRING } = require('../config/constants');
const { getCookie } = require('../services/scraper');

// ================================================================
// /api/filmes/stream
// ================================================================
router.get('/stream', async (req, res) => {
  try {
    const firestoreData = await buscarTodosBlocos('filmes');
    if (firestoreData && firestoreData.itens.length > 0) {
      console.log(`✅ Filmes do Firestore: ${firestoreData.total} filmes`);
      return res.json({
        fonte: 'firestore',
        total: firestoreData.total,
        atualizado_em: firestoreData.atualizado_em,
        filmes: firestoreData.itens
      });
    }

    console.log('🎬 Filmes não encontrados no Firestore, fazendo streaming...');
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    res.write('{\n  "fonte": "scraping",\n  "status": "carregando",\n  "total_paginas": 0,\n  "filmes": [\n');

    let totalPaginas = 435;
    let primeiro = true;
    let totalFilmes = 0;
    const filmesParaSalvar = [];

    console.log(`🎬 Iniciando streaming de filmes (${totalPaginas} páginas)`);

    for (let pagina = 1; pagina <= totalPaginas; pagina++) {
      const url = pagina === 1 ? `${URL_BASE}/filmes/` : `${URL_BASE}/filmes/page/${pagina}/`;
      console.log(`🎬 Buscando filmes página ${pagina}/${totalPaginas}`);

      try {
        const { data: html } = await axios.get(url, {
          headers: {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'pt-BR,pt;q=0.9',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'priority': 'u=0, i',
            'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
            ...(getCookie() && { 'cookie': getCookie() })
          },
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: status => status < 500
        });

        const $ = cheerio.load(html);
        const itens = $('.default.poster.grid-item');

        if (itens.length === 0) {
          console.log(`⚠️ Nenhum filme encontrado na página ${pagina}`);
          break;
        }

        itens.each((i, el) => {
          const item = $(el);
          const linkElement = item.find('.poster__title a');
          const link = linkElement.attr('href') || '';
          const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
          const imgElement = item.find('.poster__img img');
          const imagem = imgElement.attr('src') || '';
          const ano = item.find('.bslide__meta span').first().text().trim() || '';
          let nota = 0;
          const notaElement = item.find('.bslide__meta .rating');
          if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
          const generos = [];
          item.find('.onslide-cats a').each((j, catEl) => {
            const genero = $(catEl).text().trim();
            if (genero && genero !== 'Filmes') generos.push(genero);
          });
          const filme = { titulo, imagem, nota, ano, generos, link_assistir: link, pagina };
          filmesParaSalvar.push(filme);
          if (!primeiro) res.write(',\n');
          primeiro = false;
          res.write(JSON.stringify(filme, null, 2));
          totalFilmes++;
        });

        res.write(`\n  // ✅ Página ${pagina}/${totalPaginas} carregada (${itens.length} filmes)`);
        await new Promise(resolve => setTimeout(resolve, 150));
      } catch (err) {
        console.log(`❌ Erro página ${pagina}:`, err.message);
        res.write(`\n  // ⚠️ Erro na página ${pagina}: ${err.message}`);
        continue;
      }
    }

    if (filmesParaSalvar.length > 0) {
      await salvarEmBlocos('filmes', filmesParaSalvar, 100);
    }

    res.write('\n  ],\n');
    res.write(`  "total_filmes": ${totalFilmes},\n`);
    res.write(`  "paginas_processadas": ${totalPaginas},\n`);
    res.write(`  "status": "completo"\n`);
    res.write('}');
    res.end();

    console.log(`✅ Stream finalizado: ${totalFilmes} filmes em ${totalPaginas} páginas`);
  } catch (error) {
    console.error('❌ Erro no stream:', error);
    if (!res.headersSent) {
      res.status(500).json({ erro: 'Erro ao processar stream', detalhe: error.message });
    } else {
      res.write('\n  // ❌ ERRO: ' + error.message + '\n');
      res.write('  }],\n  "status": "erro"\n}');
      res.end();
    }
  }
});

// ================================================================
// /api/filme/:categoria/:slug
// ================================================================
router.get('/filme/:categoria/:slug', async (req, res) => {
  try {
    const { categoria, slug } = req.params;
    const url = `${URL_BASE}/${categoria}/${slug}`;
    console.log(`🎬 Buscando filme: ${categoria}/${slug}`);
    const { data: html } = await axios.get(url, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(getCookie() && { 'cookie': getCookie() })
      },
      timeout: 15000
    });
    const $ = cheerio.load(html);
    const titulo = $('.movieinfo h1').text().trim() || '';
    const imagem = $('.movieposter img').attr('src') || '';
    let nota = 0;
    const notaElement = $('.movieinfo .rating');
    if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
    const ano = $('.movieinfo .yearof').text().replace('Ano:', '').trim() || '';
    const descricao = $('.movie-description').text().trim() || '';
    let duracao = 0;
    const duracaoElement = $('.movieinfo .duration .tohr');
    if (duracaoElement.length) duracao = parseInt(duracaoElement.text().trim()) || 0;
    const diretores = [];
    $('.credits p:contains("Diretor(es)")').each((i, el) => {
      const text = $(el).text().replace('Diretor(es):', '').trim();
      diretores.push(text);
    });
    const atores = [];
    $('.credits p:contains("Atores") a').each((i, el) => {
      atores.push($(el).text().trim());
    });
    const generos = [];
    $('.onslide-cats a').each((i, el) => {
      const genero = $(el).text().trim();
      if (genero && genero !== 'Filmes') generos.push(genero);
    });
    const recomendados = [];
    $('.rec_wrap .default.poster.grid-item').each((i, el) => {
      const item = $(el);
      const link = item.find('.poster__title a').attr('href') || '';
      const tituloRec = item.find('.poster__title a span').text().trim() || '';
      const imagemRec = item.find('.poster__img img').attr('src') || '';
      const anoRec = item.find('.bslide__meta span').first().text().trim() || '';
      let notaRec = 0;
      const notaElementRec = item.find('.bslide__meta .rating');
      if (notaElementRec.length) notaRec = parseFloat(notaElementRec.text().trim()) || 0;
      recomendados.push({ titulo: tituloRec, imagem: imagemRec, nota: notaRec, ano: anoRec, link_assistir: link });
    });
    res.json({ titulo, imagem, nota, ano, duracao, descricao, diretores, atores, generos, tipo: 'Filme', categoria, slug, recomendados });
  } catch (error) {
    console.error('❌ Erro ao buscar filme:', error.message);
    res.status(500).json({ erro: 'Erro ao buscar filme', detalhe: error.message });
  }
});

// ================================================================
// /api/filme-player/:categoria/:slug
// CORRIGIDO: a=false
// ================================================================
router.get('/filme-player/:categoria/:slug', async (req, res) => {
  try {
    const { categoria, slug } = req.params;
    const episodeUrl = `${URL_BASE}/${categoria}/${slug}/`;
    
    console.log(`🎬 Buscando player: ${episodeUrl}`);
    
    const cookie = getCookie() || 'PHPSESSID=1gje0s9sb6nhova0o3c37toc57';
    const userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

    // 1. Pega página do filme
    const { data: html } = await axios.get(episodeUrl, {
      headers: {
        'User-Agent': userAgent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
        'Accept-Language': 'pt-BR,pt;q=0.9',
        'Cookie': cookie,
        'Referer': `${URL_BASE}/`
      },
      timeout: 30000
    });

    // 2. Extrai itemId
    const itemIdMatch = html.match(/var itemId = "(\d+)";/);
    if (!itemIdMatch) throw new Error('itemId não encontrado');
    const itemId = itemIdMatch[1];
    console.log(`📌 itemId: ${itemId}`);

    // 3. Season/episode
    const seasonMatch = slug.match(/--s(\d+)e(\d+)/i);
    let season = 1;
    let episode = 1;
    
    if (seasonMatch) {
      season = seasonMatch[1];
      episode = seasonMatch[2];
      console.log(`📌 É episódio! Season: ${season}, Episode: ${episode}`);
    } else {
      console.log(`📌 É filme! Usando season: 1, series: 1`);
    }

    // 4. Chama /json COM a=true (CORRIGIDO)
 const jsonUrl = `${URL_BASE}/json?id=${itemId}&version=0&season=${season}&series=${episode}&a=true&android=0`;
    console.log(`📡 Buscando JSON: ${jsonUrl}`);

    const { data: jsonData } = await axios.get(jsonUrl, {
      headers: {
        'User-Agent': userAgent,
        'Accept': '*/*',
        'Accept-Language': 'pt-BR,pt;q=0.9',
        'Referer': episodeUrl,
        'Cookie': cookie,
        'Origin': URL_BASE
      },
      timeout: 30000
    });

    const m3u8Path = jsonData.video_url;
    if (!m3u8Path) throw new Error('video_url não encontrado no JSON');

    const m3u8Url = m3u8Path.startsWith('http') ? m3u8Path : `${URL_BASE}${m3u8Path}`;
    console.log(`📹 M3U8 URL: ${m3u8Url}`);

    // 5. Pega M3U8
    const { data: m3u8Content } = await axios.get(m3u8Url, {
      headers: {
        'User-Agent': userAgent,
        'Accept': '*/*',
        'Accept-Language': 'pt-BR,pt;q=0.9',
        'Referer': episodeUrl,
        'Cookie': cookie,
        'Origin': URL_BASE
      },
      timeout: 30000
    });

    res.setHeader('Content-Type', 'application/vnd.apple.mpegurl');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'no-cache');
    res.send(m3u8Content);

    console.log(`✅ M3U8 retornado!`);

  } catch (error) {
    console.error('❌ Erro:', error.message);
    res.status(500).json({ success: false, erro: error.message });
  }
});

// ================================================================
// /api/filme-info/:categoria/:slug
// CORRIGIDO: a=false
// ================================================================
router.get('/filme-info/:categoria/:slug', async (req, res) => {
  try {
    const { categoria, slug } = req.params;
    const filmeUrl = `${URL_BASE}/${categoria}/${slug}/`;
    console.log(`🎬 Buscando info do filme: ${filmeUrl}`);
    
    const cookie = getCookie() || 'PHPSESSID=1gje0s9sb6nhova0o3c37toc57';
    const userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

    const { data: html } = await axios.get(filmeUrl, {
      headers: {
        'User-Agent': userAgent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
        'Accept-Language': 'pt-BR,pt;q=0.9',
        'Cookie': cookie,
        'Referer': `${URL_BASE}/`
      },
      timeout: 15000
    });

    const $ = cheerio.load(html);
    const titulo = $('.movieinfo h1').text().trim() || '';
    const imagem = $('.movieposter img').attr('src') || '';
    let nota = 0;
    const notaElement = $('.movieinfo .rating');
    if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
    const ano = $('.movieinfo .yearof').text().replace('Ano:', '').trim() || '';
    const descricao = $('.movie-description').text().trim() || '';
    let duracao = 0;
    const duracaoElement = $('.movieinfo .duration .tohr');
    if (duracaoElement.length) duracao = parseInt(duracaoElement.text().trim()) || 0;
    const itemIdMatch = html.match(/var itemId = "(\d+)";/);
    const itemId = itemIdMatch ? itemIdMatch[1] : null;
    let m3u8Url = null;

    if (itemId) {
      try {
        // CORRIGIDO: a=true
        const jsonUrl = `${URL_BASE}/json?id=${itemId}&version=0&season=1&series=1&a=true&android=0`;
        const { data: jsonData } = await axios.get(jsonUrl, {
          headers: {
            'User-Agent': userAgent,
            'Accept': '*/*',
            'Accept-Language': 'pt-BR,pt;q=0.9',
            'Referer': filmeUrl,
            'Cookie': cookie,
            'Origin': URL_BASE
          },
          timeout: 15000
        });
        const path = jsonData.video_url;
        if (path) m3u8Url = path.startsWith('http') ? path : `${URL_BASE}${path}`;
      } catch (e) {
        console.warn('⚠️ Não foi possível obter M3U8:', e.message);
      }
    }

    res.json({ 
      titulo, imagem, nota, ano, duracao, descricao, 
      categoria, slug, item_id: itemId, m3u8_url: m3u8Url, player_url: filmeUrl 
    });

  } catch (error) {
    console.error('❌ Erro ao buscar info do filme:', error.message);
    res.status(500).json({ erro: error.message });
  }
});

module.exports = router;
