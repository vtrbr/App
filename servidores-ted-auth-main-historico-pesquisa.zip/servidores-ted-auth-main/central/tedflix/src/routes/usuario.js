// ================================================================
// ROTAS: USUÁRIO (FAVORITOS E HISTÓRICO)
// ================================================================

const router = require('express').Router();
const { db } = require('../config/firebase');
const { COLLECTIONS } = require('../config/constants');
const tokenMiddleware = require('../middleware/auth');

// ================================================================
// FAVORITOS - TOGGLE
// ================================================================
router.post('/favorites/toggle', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const { filmeId, titulo, thumb } = req.body;

    if (!filmeId) {
      return res.status(400).json({
        success: false,
        message: 'filmeId é obrigatório'
      });
    }

    const favoritoId = `${token}_${filmeId}`;
    const favoritoDoc = await db.collection(COLLECTIONS.FAVORITOS).doc(favoritoId).get();

    if (favoritoDoc.exists) {
      await favoritoDoc.ref.delete();
      return res.status(200).json({
        success: true,
        message: 'Removido dos favoritos',
        favorited: false
      });
    } else {
      await db.collection(COLLECTIONS.FAVORITOS).doc(favoritoId).set({
        token: token,
        filmeId,
        titulo: titulo || 'Sem título',
        thumb: thumb || '',
        adicionadoEm: new Date().toISOString()
      });

      return res.status(200).json({
        success: true,
        message: 'Adicionado aos favoritos',
        favorited: true
      });
    }

  } catch (error) {
    console.error('❌ Erro em /api/favorites/toggle:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// ================================================================
// FAVORITOS - LISTAR
// ================================================================
router.get('/favorites/list', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;

    const favoritesQuery = await db.collection(COLLECTIONS.FAVORITOS)
      .where('token', '==', token)
      .orderBy('adicionadoEm', 'desc')
      .get();

    const favoritos = [];
    favoritesQuery.forEach(doc => {
      const data = doc.data();
      favoritos.push({
        filmeId: data.filmeId,
        titulo: data.titulo,
        thumb: data.thumb,
        adicionadoEm: data.adicionadoEm
      });
    });

    return res.status(200).json({
      success: true,
      favoritos
    });

  } catch (error) {
    console.error('❌ Erro em /api/favorites/list:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// ================================================================
// HISTÓRICO - SALVAR PROGRESSO
// ================================================================
router.post('/history/save-progress', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const { filmeId, titulo, tempo, thumb } = req.body;

    if (!filmeId) {
      return res.status(400).json({
        success: false,
        message: 'filmeId é obrigatório'
      });
    }

    const historyId = `${token}_${filmeId}`;

    const historyData = {
      token: token,
      filmeId,
      titulo: titulo || 'Sem título',
      tempo: tempo || '00:00:00',
      thumb: thumb || '',
      ultimoAcesso: new Date().toISOString()
    };

    await db.collection(COLLECTIONS.HISTORICO).doc(historyId).set(historyData, { merge: true });

    return res.status(200).json({
      success: true,
      message: 'Progresso salvo com sucesso'
    });

  } catch (error) {
    console.error('❌ Erro em /api/history/save-progress:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// ================================================================
// HISTÓRICO - CONTINUAR ASSISTINDO
// ================================================================
router.get('/history/continue-watching', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;

    const historyQuery = await db.collection(COLLECTIONS.HISTORICO)
      .where('token', '==', token)
      .orderBy('ultimoAcesso', 'desc')
      .limit(20)
      .get();

    const continuarAssistindo = [];
    historyQuery.forEach(doc => {
      const data = doc.data();
      continuarAssistindo.push({
        filmeId: data.filmeId,
        titulo: data.titulo,
        tempo: data.tempo,
        thumb: data.thumb,
        ultimoAcesso: data.ultimoAcesso
      });
    });

    return res.status(200).json({
      success: true,
      continuarAssistindo
    });

  } catch (error) {
    console.error('❌ Erro em /api/history/continue-watching:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});


// ================================================================
// HISTÓRICO DE PESQUISAS - SALVAR
// ================================================================
router.post('/search/history', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const query = String(req.body?.query || req.body?.pesquisa || '').trim();

    if (!query) {
      return res.status(400).json({
        success: false,
        message: 'query é obrigatória'
      });
    }

    const historicoQuery = await db.collection(COLLECTIONS.HISTORICO_PESQUISAS)
      .where('token', '==', token)
      .get();

    const existente = historicoQuery.docs.find(doc =>
      String(doc.data().query || '').toLowerCase() === query.toLowerCase()
    );

    const agora = new Date().toISOString();
    if (existente) {
      await existente.ref.set({ query, atualizadoEm: agora }, { merge: true });
      return res.status(200).json({
        success: true,
        message: 'Pesquisa atualizada no histórico',
        id: existente.id
      });
    }

    const ref = await db.collection(COLLECTIONS.HISTORICO_PESQUISAS).add({
      token,
      query,
      criadoEm: agora,
      atualizadoEm: agora
    });

    return res.status(201).json({
      success: true,
      message: 'Pesquisa salva no histórico',
      id: ref.id
    });
  } catch (error) {
    console.error('❌ Erro em /api/search/history POST:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// ================================================================
// HISTÓRICO DE PESQUISAS - LISTAR
// ================================================================
router.get('/search/history', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const snapshot = await db.collection(COLLECTIONS.HISTORICO_PESQUISAS)
      .where('token', '==', token)
      .limit(50)
      .get();

    const pesquisas = snapshot.docs
      .map(doc => ({ id: doc.id, ...doc.data() }))
      .sort((a, b) => String(b.atualizadoEm || b.criadoEm || '').localeCompare(String(a.atualizadoEm || a.criadoEm || '')));

    return res.status(200).json({
      success: true,
      total: pesquisas.length,
      pesquisas
    });
  } catch (error) {
    console.error('❌ Erro em /api/search/history GET:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// ================================================================
// HISTÓRICO DE PESQUISAS - APAGAR UMA
// ================================================================
router.delete('/search/history/:id', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const ref = db.collection(COLLECTIONS.HISTORICO_PESQUISAS).doc(req.params.id);
    const doc = await ref.get();

    if (!doc.exists || doc.data().token !== token) {
      return res.status(404).json({
        success: false,
        message: 'Pesquisa não encontrada'
      });
    }

    await ref.delete();
    return res.status(200).json({
      success: true,
      message: 'Pesquisa removida do histórico'
    });
  } catch (error) {
    console.error('❌ Erro em /api/search/history/:id DELETE:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// ================================================================
// HISTÓRICO DE PESQUISAS - APAGAR TUDO
// ================================================================
router.delete('/search/history', tokenMiddleware, async (req, res) => {
  try {
    const token = req.token;
    const snapshot = await db.collection(COLLECTIONS.HISTORICO_PESQUISAS)
      .where('token', '==', token)
      .get();

    if (snapshot.empty) {
      return res.status(200).json({
        success: true,
        removidas: 0,
        message: 'Histórico de pesquisas já está vazio'
      });
    }

    let batch = db.batch();
    let count = 0;

    for (const doc of snapshot.docs) {
      batch.delete(doc.ref);
      count++;
      if (count === 500) {
        await batch.commit();
        batch = db.batch();
        count = 0;
      }
    }

    if (count > 0) await batch.commit();

    return res.status(200).json({
      success: true,
      removidas: snapshot.size,
      message: 'Histórico de pesquisas apagado com sucesso'
    });
  } catch (error) {
    console.error('❌ Erro em /api/search/history DELETE:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

module.exports = router;
