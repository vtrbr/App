// ================================================================
// FIREBASE ADMIN - DOIS PROJETOS
// ================================================================

const admin = require('firebase-admin');

// ================================================================
// PROJETO 1: tedflix-54f17 (filmes, histórico, favoritos)
// ================================================================
const serviceAccountTedflix = {
  "type": "service_account",
  "project_id": "tedflix-54f17",
  "private_key_id": "4b35e9f878a07cb1209db1a6321f01d068d4c479",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC5/F2gTWb7jVc0\nBM0olBaoBaswZIabFhAjJWsWZnrLRttyK04UCD4hOOoIO0uscRqDPyGEZ7mRMrSy\n7eCTCyOp4+HiQfEHkW+jj5NDdT7WLC+/051d9nhXVU06Z1C/dQUtnONg6JcX10dh\nsgFaB4Hy8FvQt6TIznHHy+bxjsHp6x8MQyvkwpaVIoBHwUGukdpedDisYIIxrI0f\nJ/QDaM64g6cX+HxkM/g/uUzVkd2lou0a7kclfSk6Q8zvWlkoxrW9kH2aEldsrpHF\n4pKzKQQwBjwRubTPcCJpc8Ypdvy/1iL3Y2GiZfduDeN51TxUpE+c5QTjeaDNt2uc\nma3h/3uJAgMBAAECggEADfta0wmqnavoI78eKMgsRVyqvFg8VdWkaC4AlVYmMli8\n9+HpTGB7wj3f+zcw9tFobbg95fExzkh+dOqk7M0ENPoOoda0/u2IM+a/6oz6iLmY\n694F6TnVnXQqWoMImyIaHe4a2m7V6AsNQNsT1q+0jV3UOzZJHzcE7wElVyDVM2dy\ncllDNLmpbwzPoDtYhkQr+03YCzc072nwU4uShYRcL8lnQ7OQX/ZsHoL5SkN2B5bV\n74X9kB4ZQQDrlHfN7sd2gpLlcg51gL9zcUJM9gKy39y2pJTmfN2OyL6gNWm88qCF\nZsCAEKQOYBpDV/Th4QJyf7riLBgl4Xj1oy982XI9wQKBgQD350NE9KazccrdEX7V\nyXjW05BfXQQQD3M7ZHuFMS2K6QT17t22HJSp8SMLYL4aRE0dktV5kyBzORdwfnvZ\nHYqeWX+xQDF/fCDeG6uozsnYErMLGy1KsRtWVhK9w8WRHCRQ58TuBL+uiwaE7Png\nanPs4tNbt1d6yZGqA3lkRlxDSQKBgQDAD2fo9woaKmPBKiQq386dJM+UVIL5B0G7\nFCkJKdrlByv4HOV8VTu7w5OLaltyocQYI9MYJD6EFCsnuhSGLw2zvitCAPeDsgWs\ngm7c8BmT910aM8mZp4xrQjgVliepmHxigiTKXll+XWTIdzDayXuXN3RRfBVDhET6\neu/52lk2QQKBgQCClaWPuzfcqoJr9P1U7C3lK8iPE1ZCh4DxtjqCrKcK1zgvvEW5\n2lBNPKJzKeC5wWTFwUUGJ4QebeJ09YuTkMYmJ4rl+aSZPO+rT/QaleMpGKCLpyMy\nhxyZW/m/UFLP330ZyRypLIM0FDO47YOqvSiXjdw8IdXI7kj2v6HAOnf7UQKBgDh+\nz6QZtyEHQxy5FrZ96zsSbvVE/tneJpmvTnrhkwA34dk0NtUiBVYwK6ChApFvwE0R\njLDXSIR1olQnSo5GHRO4ZuUdf7F/lmeuXoojHoMGCp8AiNboEEgkzHadGsGqlzwq\n6EOXCWBAfLrzRK23AuHycAbgJykbKWc87oZikkeBAoGBANvXv86sEIaCtbh376gN\nz48dYYI3lgsJXiHklMNOVl/xMmOze+F3S5HidxQ68EYo+jWNSwrz2y+vkfDpNWus\npma9t2SGAO/R1ygYrh10ks9m8mwCAQEEcjWfVP6jDKhifa4MpSA+eSp4w1AwG/gt\ngy6qJlQHIgkB6n5A+ppj4W0v\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-fbsvc@tedflix-54f17.iam.gserviceaccount.com",
  "client_id": "110795109688739513918",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40tedflix-54f17.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
};

// ================================================================
// PROJETO 2: postagem-e3677 (tokens)
// ================================================================
const serviceAccountAuth = {
  "type": "service_account",
  "project_id": "postagem-e3677",
  "private_key_id": "3d07995fcc7d3776b81ceb11d1b4b3c72f2861c3",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCjfxQq66ZPXeJc\n0PCaZhpBVrkP725BxyHBMi9Eq0LTExB7V93wragw6V4hZIgb3DDL+rEglIhM7ekx\nkcjy6YIV6sCFycWlGBethBMxupASsWixvPaSyUwxCT1cij+bKM1O/72cU4/fJeOH\nQ3EFepaSFQ2HT9A/AfZwaUoWpg3py4Hz5HpkdK1iY1CDS6tP2Njiknh4NiVc+lFW\nb5BsDAmbWQ4aSJL9kPfqBZ4QrdAVq1etbrqr39q8lT2ej4f1D741JJWRjjE4m1+r\nl5DHMPbdxSQhBZB1LcQwJSLskjFoaArJ4HVBjLtqAUArl65FxpaIWl9iKJ3XE3/f\nidO1l025AgMBAAECggEADdK/vMVBwXIZomlT/mnljGKtsOg4dT1F4FTC5FZqhvgU\nq6kJLcEw+Dmy6LXcQCbExWpDsZJ9V6vBzJwb1lXh1sKLVoRxvnyj+9qv2MOCTOJN\nDMICQvTcCUVTt9BEgnTXrvc2a9Iw1tgYPaZ5FtJ/iohXJXqdC8a5tFVimzmc8YhN\npmX/ygzG+Rt4pgXNVyYQzw9VguodC1sAtOMGRfZlpEzRa+4A+V2zJzqTCWT7EMDj\nouJ9mPZnGautRqqejt3f5t497OUSm69GphcFgBXpUfEoNqa13/88GyGygnzePdUB\n/t6Knf3u6EQKxAnIKVzNbXLnN4Gqab7Bxfj9BrD4NQKBgQDX3kK7RMI8khsiz0fI\ngWg6f0ytc3UwGpQ4e2TTmCUNAyJ1X4X41nLfkxI+NO9G4DUjol3kxt5Ora5JLQFZ\n+YPbs73L6a2pQBJT4nYQuPjbzGegHL27VlFpxqE2TIZi98xiJOXNpX3Va1YfxWwm\nkNUGHmIb7PTGyQP0A0smCCZukwKBgQDB5E4pA6xLfQ2nMGntY4MODMcVWDXNaZM7\njsbEuo2bH9aaiwPL2Rlby+Xq7MqqZLo9SzuwFMclZWacXlcwo8pnzrBxFQEIjz+d\n/r1DS9UUAX8M61XmRk+2YauU1asHGKE1+qhBewuTm/BtOkzJHu4zffWlPxtDyw+1\nCbe5qIs2AwKBgGIvnSiyqKqGRkN6BouDmNXqqwTF3Eqp/DsInR7FOC0H/PdoIHbD\ni/J3Ybfbue4B8wmnQ4/YiKs+wmRUTSYQoNIgmjaSrkOqeeufuNX4XHEVMxkXmZEJ\nPPSgvRkGi6WeUl9dqwzzth2Jud2vnXaZL9udnEBZciisq9ikWt0MnfZzAoGBAKbG\nLOCkcye/WeYMA6EYLlsAbKGUbTrRa74X0irXWAQtP5dQqaRGicRmvs3yfWRRHcyp\nEJ8lUCJ/dOJdV1vUFr5xj1zFN01Ygdzxh3QCHzaFDvZa2lkm81up6T8tBl4lNk1K\n3DzujIeb4xLgyblY7ITH/Gn1vQrz9/+9axW7vnpnAoGBAIPilavsY0PF/25NTHDq\ngCpcHdKyCjyHXj40yjlZ/OcO6cIxKVxVJYYv5pJj3MQsI3xXWVHLlTNBok6L610X\n8iId7KmFS8gBOG7SMix9QqsWYwn2TX1qkExx2zXdnPcMUPQao/stAa2qQ16m28u3\nQlhEmQGCOZCgWJeIagS5hL81\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-fbsvc@postagem-e3677.iam.gserviceaccount.com",
  "client_id": "104250812427310327843",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40postagem-e3677.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
};

// ================================================================
// INICIALIZAR OS DOIS PROJETOS
// ================================================================

const appTedflix = admin.initializeApp({
  credential: admin.credential.cert(serviceAccountTedflix),
  projectId: 'tedflix-54f17'
}, 'tedflix');

const appAuth = admin.initializeApp({
  credential: admin.credential.cert(serviceAccountAuth),
  projectId: 'postagem-e3677'
}, 'auth');

// ================================================================
// EXPORTAR OS DOIS BANCOS
// ================================================================

module.exports = {
  db: appTedflix.firestore(),
  dbAuth: appAuth.firestore()
};
