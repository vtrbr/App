// ================================================================
// CONSTANTES GLOBAIS
// ================================================================

module.exports = {
  PORT: process.env.PORT || 7100,
  URL_BASE: 'https://novelasflix.video',
  URL_BASE_NOVELAS: 'https://megacine.quest',
  
  COLLECTIONS: {
    HISTORICO: 'historico',
    HISTORICO_PESQUISAS: 'historico_pesquisas',
    FAVORITOS: 'favoritos'
  },
  
  CACHE_TTL: {
    HOME: 86400000,
    FILMES: 86400000,
    SERIES: 86400000,
    ANIMACOES: 86400000,
    ULTIMOS_FILMES: 3600000,
    CARROSSEL: 86400000,
    LANCAMENTOS: 86400000,
    COLECOES: 86400000,
    CATEGORIA: 86400000,
    BUSCA: 86400000,
    AGENDA: 432000000
  },
  
  // ================================================================
  // CAROUSEL FIXO (mantido exatamente como no original)
  // ================================================================
  CAROUSEL_FIXO: [
    {
      titulo: "A Casa do Dragão – House of the Dragon",
      imagem: "https://image.tmdb.org/t/p/original/577eXC8wFQT0eUrJcgznSiFPRmk.jpg",
      logo: "https://image.tmdb.org/t/p/w500/14UIbr8ETzGnDe0eB2NUiJovg3o.png",
      nota: 8.3,
      ano: "2022",
      tipo: "Série",
      descricao: "200 anos antes dos eventos de 'Game of Thrones', os Targaryen estavam no ápice de seu poder, tendo inúmeros dragões sob seu comando, mas nem tudo dura para sempre. O início do…",
      generos: ["Action & Adventure", "Drama", "Sci-Fi & Fantasy"],
      link_assistir: "https://novelasflix.video/drama/6068-a-casa-do-dragao-noads"
    },
    {
      titulo: "Stuart Não Consegue Salvar o Universo – Stuart Fails to Save the Universe",
      imagem: "https://image.tmdb.org/t/p/original/2ngdvUiEKW8Q37ta8BBdydE2cuq.jpg",
      logo: "https://image.tmdb.org/t/p/w500/sHUYYn9Pb4GeVOZ1gm3vK9NIp1Q.png",
      nota: 8.7,
      ano: "2026",
      tipo: "Série",
      descricao: "O dono da loja de quadrinhos Stuart Bloom é encarregado de restaurar a realidade após quebrar acidentalmente um dispositivo construído por Sheldon e Leonard, desencadeando um Armagedom no multiverso. Nessa missão, Stuart…",
      generos: ["Comédia", "Sci-Fi & Fantasy"],
      link_assistir: "https://novelasflix.video/comedia/13761-stuart-nao-consegue-salvar-o-universo"
    },
    {
      titulo: "Dia D",
      imagem: "https://image.tmdb.org/t/p/original/s6ly8laenkHWlIBRkLSfIuEMLC6.jpg",
      logo: "https://image.tmdb.org/t/p/w500/9pp8pOfBZBM5WXoZ0DmMrDOlqPH.png",
      nota: 7.0,
      ano: "2026",
      tipo: "Filme",
      descricao: "A existência de vida extraterrestre torna-se uma realidade inegável para todos os habitantes da Terra em um único instante. O mundo entra em colapso quando uma meteorologista, em plena transmissão ao vivo,…",
      generos: ["Ação", "Ficção científica", "Thriller"],
      link_assistir: "https://novelasflix.video/suspense/13362-dia-d"
    },
    {
      titulo: "Todo Mundo em Pânico 6",
      imagem: "https://m.media-amazon.com/images/S/pv-target-images/176ce41686585da6854ae7deab3fa3f3d672d689d4678773d033812673afd6dc._SX1080_FMjpg_.jpg",
      logo: "https://image.tmdb.org/t/p/original/ashfJUIvWyypy2YxaKA4k0ahMY4.png",
      nota: 6.5,
      ano: "2026",
      tipo: "Filme",
      descricao: "Vinte e seis anos depois de escaparem de um assassino mascarado suspeitosamente familiar, o Quarteto Fantástico está de volta à mira do criminoso, e nenhuma propriedade intelectual de filmes de terror está a salvo.",
      generos: ["Comédia"],
      link_assistir: "https://novelasflix.video/comedia/13768-todo-mundo-em-panico-6"
    },
    {
      titulo: "Como Mágica",
      imagem: "https://media.themoviedb.org/t/p/w533_and_h300_face/q5LJT8QYjUU4uKlT9x2aQpxz09t.jpg",
      logo: "https://image.tmdb.org/t/p/original/v1ZdIuHLmv3NmDzOEXnNwZsnMNY.png",
      nota: 8.2,
      ano: "2026",
      tipo: "Filme",
      descricao: "Uma pequena criatura da floresta e um pássaro majestoso trocam de corpo e precisam se unir para sobreviver à aventura mais incrível de suas vidas.",
      generos: ["Aventura"],
      link_assistir: "https://novelasflix.video/aventura/12978-como-magica"
    }
  ]
};
