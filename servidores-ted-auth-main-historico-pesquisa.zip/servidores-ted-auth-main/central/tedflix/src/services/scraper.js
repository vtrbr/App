// ================================================================
// SCRAPER - CARREGAMENTO DAS PÁGINAS
// ================================================================

const axios = require('axios');
const { URL_BASE } = require('../config/constants');

// Variáveis compartilhadas
let HOME_HTML = '';
let FILMES_HTML = '';
let SERIES_HTML = '';
let ANIMACOES_HTML = '';
let COOKIE_STRING = '';

// ================================================================
// CARREGAMENTO HOME
// ================================================================
async function carregarHome() {
  try {
    console.log('🌐 Carregando página inicial...');
    const response = await axios.get(`${URL_BASE}/`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'
      },
      timeout: 15000,
      maxRedirects: 5,
      validateStatus: status => status < 500
    });

    HOME_HTML = response.data || '';
    const setCookie = response.headers['set-cookie'];
    if (setCookie && setCookie.length > 0) {
      const cookieArray = Array.isArray(setCookie) ? setCookie : [setCookie];
      COOKIE_STRING = cookieArray.map(cookie => cookie.split(';')[0]).join('; ');
      console.log('🍪 Cookies obtidos:', COOKIE_STRING);
    } else {
      COOKIE_STRING = '';
      console.warn('⚠️ Nenhum cookie retornado pelo servidor.');
    }

    console.log(`📄 HTML carregado: ${HOME_HTML.length} bytes`);
    console.log('✅ Página inicial carregada com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao carregar home:', error.message);
  }
}

// ================================================================
// CARREGAMENTO FILMES
// ================================================================
async function carregarFilmes() {
  try {
    console.log('🌐 Carregando página filmes...');
    const response = await axios.get(`${URL_BASE}/filmes/`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
      },
      timeout: 15000,
      maxRedirects: 5,
      validateStatus: status => status < 500
    });
    FILMES_HTML = response.data || '';
    console.log(`📄 HTML filmes carregado: ${FILMES_HTML.length} bytes`);
    console.log('✅ Página filmes carregada com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao carregar filmes:', error.message);
  }
}

// ================================================================
// CARREGAMENTO SÉRIES
// ================================================================
async function carregarSeries() {
  try {
    console.log('🌐 Carregando página séries...');
    const response = await axios.get(`${URL_BASE}/series/`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
      },
      timeout: 15000,
      maxRedirects: 5,
      validateStatus: status => status < 500
    });
    SERIES_HTML = response.data || '';
    console.log(`📄 HTML séries carregado: ${SERIES_HTML.length} bytes`);
    console.log('✅ Página séries carregada com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao carregar séries:', error.message);
  }
}

// ================================================================
// CARREGAMENTO ANIMAÇÕES
// ================================================================
async function carregarAnimacoes() {
  try {
    console.log('🌐 Carregando página animações...');
    const response = await axios.get(`${URL_BASE}/genero/animacao/`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'referer': `${URL_BASE}/series/`,
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
      },
      timeout: 15000,
      maxRedirects: 5,
      validateStatus: status => status < 500
    });
    ANIMACOES_HTML = response.data || '';
    console.log(`📄 HTML animações carregado: ${ANIMACOES_HTML.length} bytes`);
    console.log('✅ Página animações carregada com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao carregar animações:', error.message);
  }
}

// ================================================================
// GETTERS PARA ACESSAR OS HTMLs E COOKIE
// ================================================================
function getHomeHTML() { return HOME_HTML; }
function getFilmesHTML() { return FILMES_HTML; }
function getSeriesHTML() { return SERIES_HTML; }
function getAnimacoesHTML() { return ANIMACOES_HTML; }
function getCookie() { return COOKIE_STRING; }

module.exports = {
  carregarHome,
  carregarFilmes,
  carregarSeries,
  carregarAnimacoes,
  getHomeHTML,
  getFilmesHTML,
  getSeriesHTML,
  getAnimacoesHTML,
  getCookie
};
