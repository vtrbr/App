// ================================================================
// CACHE EM MEMÓRIA
// ================================================================

const cache = new Map();

function getCache(key) {
  if (cache.has(key)) {
    const item = cache.get(key);
    if (Date.now() < item.expiry) {
      console.log(`✅ Cache HIT: ${key}`);
      return item.data;
    } else {
      console.log(`⏰ Cache EXPIRED: ${key}`);
      cache.delete(key);
      return null;
    }
  }
  console.log(`❌ Cache MISS: ${key}`);
  return null;
}

function setCache(key, data, ttl = 86400000) {
  cache.set(key, {
    data: data,
    expiry: Date.now() + ttl
  });
  console.log(`💾 Cache SAVED: ${key} (expira em ${ttl/1000/60/60} horas)`);
}

function clearCache() {
  cache.clear();
  console.log('🧹 Cache limpo!');
}

// Limpa cache automaticamente a cada 24 horas
setInterval(clearCache, 24 * 60 * 60 * 1000);

module.exports = {
  getCache,
  setCache,
  clearCache
};
