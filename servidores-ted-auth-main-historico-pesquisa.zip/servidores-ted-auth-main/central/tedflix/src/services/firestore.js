// ================================================================
// FIRESTORE - SALVAR E BUSCAR EM BLOCOS
// ================================================================

const { db } = require('../config/firebase');

async function salvarEmBlocos(colecao, itens, tamanhoBloco = 50) {
  if (!itens || itens.length === 0) {
    console.log(`⚠️ Nenhum item para salvar na coleção ${colecao}`);
    return 0;
  }

  const totalBlocos = Math.ceil(itens.length / tamanhoBloco);
  console.log(`📦 Salvando ${itens.length} itens em ${totalBlocos} blocos (${tamanhoBloco} cada)`);

  for (let i = 0; i < totalBlocos; i++) {
    const inicio = i * tamanhoBloco;
    const fim = Math.min(inicio + tamanhoBloco, itens.length);
    const blocoItens = itens.slice(inicio, fim);

    await db.collection(colecao).doc(`bloco_${i + 1}`).set({
      bloco: i + 1,
      total_itens: blocoItens.length,
      itens: blocoItens,
      atualizado_em: new Date().toISOString()
    });
    console.log(`✅ Bloco ${i + 1}/${totalBlocos} salvo (${blocoItens.length} itens)`);
  }

  await db.collection(colecao).doc('_metadados').set({
    total_itens: itens.length,
    total_blocos: totalBlocos,
    tamanho_bloco: tamanhoBloco,
    atualizado_em: new Date().toISOString()
  });

  console.log(`✅ ${itens.length} itens salvos em ${totalBlocos} blocos!`);
  return totalBlocos;
}

async function buscarTodosBlocos(colecao) {
  try {
    const metaDoc = await db.collection(colecao).doc('_metadados').get();
    if (!metaDoc.exists) return null;

    const meta = metaDoc.data();
    console.log(`📦 ${meta.total_itens} itens em ${meta.total_blocos} blocos`);

    const todosItens = [];
    for (let i = 1; i <= meta.total_blocos; i++) {
      const blocoDoc = await db.collection(colecao).doc(`bloco_${i}`).get();
      if (blocoDoc.exists) {
        const dados = blocoDoc.data();
        todosItens.push(...dados.itens);
      }
    }

    return {
      total: meta.total_itens,
      total_blocos: meta.total_blocos,
      itens: todosItens,
      atualizado_em: meta.atualizado_em
    };

  } catch (error) {
    console.error(`❌ Erro ao buscar blocos da coleção ${colecao}:`, error.message);
    return null;
  }
}

module.exports = {
  salvarEmBlocos,
  buscarTodosBlocos
};
