// ================================================================
// AGENDA - MEGACINE
// ================================================================

const axios = require('axios');
const { URL_BASE_NOVELAS } = require('../config/constants');

// ================================================================
// OBTER COOKIE DO MEGACINE
// ================================================================
async function obterCookieMegacine() {
  try {
    console.log('🍪 Obtendo cookie do megacine para agenda...');
    const response = await axios.get(`${URL_BASE_NOVELAS}/`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'
      },
      timeout: 15000,
      maxRedirects: 5,
      validateStatus: status => status < 500
    });

    const setCookie = response.headers['set-cookie'];
    if (setCookie && setCookie.length > 0) {
      const cookieArray = Array.isArray(setCookie) ? setCookie : [setCookie];
      const cookiesFiltrados = cookieArray
        .map(cookie => cookie.split(';')[0])
        .filter(cookie => cookie.includes('PHPSESSID') || cookie.includes('wordpress'));
      
      if (cookiesFiltrados.length > 0) {
        const cookieString = cookiesFiltrados.join('; ');
        console.log('✅ Cookie do megacine obtido com sucesso');
        return cookieString;
      }
    }
    
    console.log('⚠️ Usando cookie padrão para megacine');
    return 'PHPSESSID=1gje0s9sb6nhova0o3c37toc57';
    
  } catch (error) {
    console.error('❌ Erro ao obter cookie do megacine:', error.message);
    return 'PHPSESSID=1gje0s9sb6nhova0o3c37toc57';
  }
}

// ================================================================
// SCRAPING DA AGENDA
// ================================================================
async function scrapeAgenda() {
  const cheerio = require('cheerio');
  const cookieMegacine = await obterCookieMegacine();
  
  const { data: html } = await axios.get(`${URL_BASE_NOVELAS}/generos/acao`, {
    headers: {
      'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'cookie': cookieMegacine,
      'referer': 'https://megacine.quest/'
    },
    timeout: 15000
  });

  const $ = cheerio.load(html);
  const dias = [];

  $('.megacine-release-calendar-widget .mc-calendar__day, .mc-calendar .mc-calendar__day, .mc-calendar__days .mc-calendar__day').each((i, dayEl) => {
    const day = $(dayEl);
    const nomeDia = day.find('h3').text().trim() || '';
    const dataEl = day.find('time');
    const data = dataEl.attr('datetime') || '';
    const dataFormatada = dataEl.text().trim() || '';
    
    let tipoDia = 'outro';
    const nomeLower = nomeDia.toLowerCase();
    if (nomeLower.includes('hoje')) tipoDia = 'hoje';
    else if (nomeLower.includes('amanhã') || nomeLower.includes('amanha')) tipoDia = 'amanha';
    
    const episodios = [];
    
    day.find('.mc-calendar__item').each((j, itemEl) => {
      const item = $(itemEl);
      const link = item.find('a').attr('href') || '';
      const horario = item.find('.mc-calendar__time').text().trim() || '';
      const tituloEp = item.find('a').attr('title') || '';
      const serie = item.find('.mc-calendar__series').text().trim() || '';
      const episodio = item.find('.mc-calendar__episode').text().trim() || '';
      
      let temporada = null;
      let numeroEpisodio = null;
      const epMatch = episodio.match(/T(\d+)\s*E(\d+)/i);
      if (epMatch) {
        temporada = parseInt(epMatch[1]);
        numeroEpisodio = parseInt(epMatch[2]);
      }
      
      episodios.push({
        titulo: tituloEp || `Episódio ${episodio}`,
        serie: serie || 'Série',
        episodio: episodio,
        temporada: temporada,
        numero: numeroEpisodio,
        horario: horario || '--:--',
        link: link
      });
    });
    
    if (episodios.length > 0 || nomeDia) {
      dias.push({
        nome: nomeDia || 'Dia',
        data: data,
        data_formatada: dataFormatada,
        tipo: tipoDia,
        total_episodios: episodios.length,
        episodios: episodios
      });
    }
  });

  return {
    total_dias: dias.length,
    total_episodios: dias.reduce((acc, d) => acc + d.total_episodios, 0),
    dias: dias
  };
}

module.exports = {
  obterCookieMegacine,
  scrapeAgenda
};
