// ================================================================
// APP - INICIALIZAÇÃO DO SERVIDOR
// ================================================================

const express = require('express');
const { PORT } = require('./config/constants');
const cors = require('./middleware/cors');

// Importa as rotas
const homeRoutes = require('./routes/home');
const filmesRoutes = require('./routes/filmes');
const seriesRoutes = require('./routes/series');
const animacoesRoutes = require('./routes/animacoes');
const generosRoutes = require('./routes/generos');
const buscaRoutes = require('./routes/busca');
const usuarioRoutes = require('./routes/usuario');

// Importa os serviços de scraping
const { carregarHome, carregarFilmes, carregarSeries, carregarAnimacoes } = require('./services/scraper');

const app = express();

// ================================================================
// MIDDLEWARES
// ================================================================
app.use(cors);
app.use(express.json());

// ================================================================
// ROTAS
// ================================================================
app.use('/api/home', homeRoutes);
app.use('/api/filmes', filmesRoutes);
app.use('/api/series', seriesRoutes);
app.use('/api/animacoes', animacoesRoutes);
app.use('/api/genero', generosRoutes);
app.use('/api', buscaRoutes);       // /api/buscar e /api/buscar/:query
app.use('/api', usuarioRoutes);     // /api/favorites e /api/history

// ================================================================
// CARREGAMENTOS INICIAIS
// ================================================================
carregarHome();
carregarFilmes();
carregarSeries();
carregarAnimacoes();

// ================================================================
// INTERVALOS (6 em 6 horas)
// ================================================================
setInterval(carregarHome, 6 * 60 * 60 * 1000);
setInterval(carregarFilmes, 6 * 60 * 60 * 1000);
setInterval(carregarSeries, 6 * 60 * 60 * 1000);
setInterval(carregarAnimacoes, 6 * 60 * 60 * 1000);

// ================================================================
// INICIA O SERVIDOR
// ================================================================
app.listen(PORT, () => {
  const now = new Date().toLocaleString("pt-BR");
  console.log("======================================");
  console.log("🚀 Servidor iniciado com sucesso");
  console.log(`🕒 Inicializado em: ${now}`);
  console.log(`🌐 Porta: ${PORT}`);
  console.log("✅ Estrutura modular organizada");
  console.log("======================================");
});

module.exports = app;
