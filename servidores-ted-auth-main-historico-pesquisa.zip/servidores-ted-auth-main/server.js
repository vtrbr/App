// ================================================================
//                       🚀 SERVIDOR NOVELASFLIX
//            COM FIRESTORE + CACHE (SOMENTE NOS STREAMS)
//                    🔒 TUDO PROTEGIDO COM BEARER
// ================================================================

const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const jwt = require('jsonwebtoken');

const app = express();

// ================================================================
//                        🔓 CORS CORRETO
// ================================================================
app.use((req, res, next) => {
  const allowedOrigins = [
    'https://tedflixtv.vercel.app',
    'http://localhost:3000',
    'http://localhost:6100',
    'http://localhost:5500'
  ];
  
  const origin = req.headers.origin;
  if (allowedOrigins.includes(origin) || !origin) {
    res.header('Access-Control-Allow-Origin', origin || '*');
  } else {
    res.header('Access-Control-Allow-Origin', '*');
  }
  
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.header('Access-Control-Allow-Credentials', 'true');
  res.header('Access-Control-Max-Age', '86400');
  
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  
  next();
});

app.use(express.json());

const PORT = process.env.PORT || 7100;
const URL_BASE = 'https://novelasflix.video';
const URL_BASE_NOVELAS = 'https://megacine.quest';
const COLLECTIONS = {
  HISTORICO: 'historico',
  FAVORITOS: 'favoritos'
};

// ================================================================
// 🔥 FIREBASE ADMIN - DOIS PROJETOS
// ================================================================

const admin = require('firebase-admin');

// ================================================================
// PROJETO 1: tedflix-54f17 (filmes, histórico, favoritos)
// ================================================================
const serviceAccountTedflix = {
  "type": "service_account",
  "project_id": "tedflix-54f17",
  "private_key_id": "4b35e9f878a07cb1209db1a6321f01d068d4c479",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC5/F2gTWb7jVc0\nBM0olBaoBaswZIabFhAjJWsWZnrLRttyK04UCD4hOOoIO0uscRqDPyGEZ7mRMrSy\n7eCTCyOp4+HiQfEHkW+jj5NDdT7WLC+/051d9nhXVU06Z1C/dQUtnONg6JcX10dh\nsgFaB4Hy8FvQt6TIznHHy+bxjsHp6x8MQyvkwpaVIoBHwUGukdpedDisYIIxrI0f\nJ/QDaM64g6cX+HxkM/g/uUzVkd2lou0a7kclfSk6Q8zvWlkoxrW9kH2aEldsrpHF\n4pKzKQQwBjwRubTPcCJpc8Ypdvy/1iL3Y2GiZfduDeN51TxUpE+c5QTjeaDNt2uc\nma3h/3uJAgMBAAECggEADfta0wmqnavoI78eKMgsRVyqvFg8VdWkaC4AlVYmMli8\n9+HpTGB7wj3f+zcw9tFobbg95fExzkh+dOqk7M0ENPoOoda0/u2IM+a/6oz6iLmY\n694F6TnVnXQqWoMImyIaHe4a2m7V6AsNQNsT1q+0jV3UOzZJHzcE7wElVyDVM2dy\ncllDNLmpbwzPoDtYhkQr+03YCzc072nwU4uShYRcL8lnQ7OQX/ZsHoL5SkN2B5bV\n74X9kB4ZQQDrlHfN7sd2gpLlcg51gL9zcUJM9gKy39y2pJTmfN2OyL6gNWm88qCF\nZsCAEKQOYBpDV/Th4QJyf7riLBgl4Xj1oy982XI9wQKBgQD350NE9KazccrdEX7V\nyXjW05BfXQQQD3M7ZHuFMS2K6QT17t22HJSp8SMLYL4aRE0dktV5kyBzORdwfnvZ\nHYqeWX+xQDF/fCDeG6uozsnYErMLGy1KsRtWVhK9w8WRHCRQ58TuBL+uiwaE7Png\nanPs4tNbt1d6yZGqA3lkRlxDSQKBgQDAD2fo9woaKmPBKiQq386dJM+UVIL5B0G7\nFCkJKdrlByv4HOV8VTu7w5OLaltyocQYI9MYJD6EFCsnuhSGLw2zvitCAPeDsgWs\ngm7c8BmT910aM8mZp4xrQjgVliepmHxigiTKXll+XWTIdzDayXuXN3RRfBVDhET6\neu/52lk2QQKBgQCClaWPuzfcqoJr9P1U7C3lK8iPE1ZCh4DxtjqCrKcK1zgvvEW5\n2lBNPKJzKeC5wWTFwUUGJ4QebeJ09YuTkMYmJ4rl+aSZPO+rT/QaleMpGKCLpyMy\nhxyZW/m/UFLP330ZyRypLIM0FDO47YOqvSiXjdw8IdXI7kj2v6HAOnf7UQKBgDh+\nz6QZtyEHQxy5FrZ96zsSbvVE/tneJpmvTnrhkwA34dk0NtUiBVYwK6ChApFvwE0R\njLDXSIR1olQnSo5GHRO4ZuUdf7F/lmeuXoojHoMGCp8AiNboEEgkzHadGsGqlzwq\n6EOXCWBAfLrzRK23AuHycAbgJykbKWc87oZikkeBAoGBANvXv86sEIaCtbh376gN\nz48dYYI3lgsJXiHklMNOVl/xMmOze+F3S5HidxQ68EYo+jWNSwrz2y+vkfDpNWus\npma9t2SGAO/R1ygYrh10ks9m8mwCAQEEcjWfVP6jDKhifa4MpSA+eSp4w1AwG/gt\ngy6qJlQHIgkB6n5A+ppj4W0v\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-fbsvc@tedflix-54f17.iam.gserviceaccount.com",
  "client_id": "110795109688739513918",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40tedflix-54f17.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
};

// ================================================================
// PROJETO 2: postagem-e3677 (usuários, autenticação)
// ================================================================
const serviceAccountAuth = {
  "type": "service_account",
  "project_id": "postagem-e3677",
  "private_key_id": "3d07995fcc7d3776b81ceb11d1b4b3c72f2861c3",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCjfxQq66ZPXeJc\n0PCaZhpBVrkP725BxyHBMi9Eq0LTExB7V93wragw6V4hZIgb3DDL+rEglIhM7ekx\nkcjy6YIV6sCFycWlGBethBMxupASsWixvPaSyUwxCT1cij+bKM1O/72cU4/fJeOH\nQ3EFepaSFQ2HT9A/AfZwaUoWpg3py4Hz5HpkdK1iY1CDS6tP2Njiknh4NiVc+lFW\nb5BsDAmbWQ4aSJL9kPfqBZ4QrdAVq1etbrqr39q8lT2ej4f1D741JJWRjjE4m1+r\nl5DHMPbdxSQhBZB1LcQwJSLskjFoaArJ4HVBjLtqAUArl65FxpaIWl9iKJ3XE3/f\nidO1l025AgMBAAECggEADdK/vMVBwXIZomlT/mnljGKtsOg4dT1F4FTC5FZqhvgU\nq6kJLcEw+Dmy6LXcQCbExWpDsZJ9V6vBzJwb1lXh1sKLVoRxvnyj+9qv2MOCTOJN\nDMICQvTcCUVTt9BEgnTXrvc2a9Iw1tgYPaZ5FtJ/iohXJXqdC8a5tFVimzmc8YhN\npmX/ygzG+Rt4pgXNVyYQzw9VguodC1sAtOMGRfZlpEzRa+4A+V2zJzqTCWT7EMDj\nouJ9mPZnGautRqqejt3f5t497OUSm69GphcFgBXpUfEoNqa13/88GyGygnzePdUB\n/t6Knf3u6EQKxAnIKVzNbXLnN4Gqab7Bxfj9BrD4NQKBgQDX3kK7RMI8khsiz0fI\ngWg6f0ytc3UwGpQ4e2TTmCUNAyJ1X4X41nLfkxI+NO9G4DUjol3kxt5Ora5JLQFZ\n+YPbs73L6a2pQBJT4nYQuPjbzGegHL27VlFpxqE2TIZi98xiJOXNpX3Va1YfxWwm\nkNUGHmIb7PTGyQP0A0smCCZukwKBgQDB5E4pA6xLfQ2nMGntY4MODMcVWDXNaZM7\njsbEuo2bH9aaiwPL2Rlby+Xq7MqqZLo9SzuwFMclZWacXlcwo8pnzrBxFQEIjz+d\n/r1DS9UUAX8M61XmRk+2YauU1asHGKE1+qhBewuTm/BtOkzJHu4zffWlPxtDyw+1\nCbe5qIs2AwKBgGIvnSiyqKqGRkN6BouDmNXqqwTF3Eqp/DsInR7FOC0H/PdoIHbD\ni/J3Ybfbue4B8wmnQ4/YiKs+wmRUTSYQoNIgmjaSrkOqeeufuNX4XHEVMxkXmZEJ\nPPSgvRkGi6WeUl9dqwzzth2Jud2vnXaZL9udnEBZciisq9ikWt0MnfZzAoGBAKbG\nLOCkcye/WeYMA6EYLlsAbKGUbTrRa74X0irXWAQtP5dQqaRGicRmvs3yfWRRHcyp\nEJ8lUCJ/dOJdV1vUFr5xj1zFN01Ygdzxh3QCHzaFDvZa2lkm81up6T8tBl4lNk1K\n3DzujIeb4xLgyblY7ITH/Gn1vQrz9/+9axW7vnpnAoGBAIPilavsY0PF/25NTHDq\ngCpcHdKyCjyHXj40yjlZ/OcO6cIxKVxVJYYv5pJj3MQsI3xXWVHLlTNBok6L610X\n8iId7KmFS8gBOG7SMix9QqsWYwn2TX1qkExx2zXdnPcMUPQao/stAa2qQ16m28u3\nQlhEmQGCOZCgWJeIagS5hL81\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-fbsvc@postagem-e3677.iam.gserviceaccount.com",
  "client_id": "104250812427310327843",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40postagem-e3677.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
};

// ================================================================
// INICIALIZAR OS DOIS PROJETOS
// ================================================================

const appTedflix = admin.initializeApp({
  credential: admin.credential.cert(serviceAccountTedflix),
  projectId: 'tedflix-54f17'
}, 'tedflix');

const appAuth = admin.initializeApp({
  credential: admin.credential.cert(serviceAccountAuth),
  projectId: 'postagem-e3677'
}, 'auth');

// ================================================================
// EXPORTAR OS DOIS BANCOS
// ================================================================

const db = appTedflix.firestore();      // filmes, historico, favoritos
const dbAuth = appAuth.firestore();     // users, access_codes



// ================================================================
// 🔐 MIDDLEWARE DE AUTENTICAÇÃO GLOBAL
// ================================================================

// 🔥 LISTA DE ROTAS PÚBLICAS (NÃO PRECISAM DE TOKEN)
// 🔥 ADICIONE AQUI AS ROTAS QUE QUER DEIXAR PÚBLICAS
// 🔥 Exemplo: health check, webhooks, etc.
const PUBLIC_ROUTES = [
  '/',

  // Home
  '/api/home/carousel',
  '/api/home/agenda',
  '/api/ultimos-filmes',
  '/api/home/lancamentos',

  // Catálogos
  '/api/filmes/stream',
  '/api/series/stream',
  '/api/animacoes/stream',

  // Gêneros
  '/api/genero/drama/stream',
  '/api/genero/suspense/stream',
  '/api/genero/aventura/stream',
  '/api/genero/acao/stream',
  '/api/genero/ficcao/stream',
  '/api/genero/comedia/stream',
  '/api/genero/terror/stream',
  '/api/genero/romance/stream',
  '/api/genero/ficcao-cientifica/stream',
  '/api/genero', // cobre /api/genero/:slug/page/:num

  // Busca
  '/api/buscar',

  // Filme
  '/api/filme',
  '/api/filme-info',
  '/api/filme-player',

  // Série
  '/api/serie'
];


// 🔥 Função para verificar se a rota é pública
function isPublicRoute(path) {
  return PUBLIC_ROUTES.some(route => path === route || path.startsWith(route + '/'));
}

// 🔥 Middleware global de autenticação
app.use(async (req, res, next) => {
  // 🔥 Se for rota pública, passa direto
  if (isPublicRoute(req.path)) {
    return next();
  }

  // 🔥 Verifica se tem token
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      error: 'Token não fornecido'
    });
  }

  const token = authHeader.split(' ')[1];

  try {
    // 🔥 Valida o JWT
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded; // { userId, email, username, expiresAt, status }

    // 🔥 (OPCIONAL) Verifica se o usuário ainda existe no Firestore
    // Isso dá uma camada extra de segurança
    const userDoc = await dbAuth.collection('users').doc(decoded.userId).get();
    if (!userDoc.exists) {
      return res.status(401).json({
        success: false,
        error: 'Usuário não encontrado'
      });
    }

    const userData = userDoc.data();

    // 🔥 Verifica se está bloqueado
    if (userData.accountStatus === 'blocked') {
      return res.status(403).json({
        success: false,
        error: 'Conta bloqueada'
      });
    }

    // 🔥 Verifica se expirou
    if (userData.accountExpiresAt) {
      const expDate = new Date(userData.accountExpiresAt);
      if (expDate < new Date()) {
        return res.status(403).json({
          success: false,
          error: 'Assinatura expirada',
          expiresAt: userData.accountExpiresAt
        });
      }
    }

    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      error: 'Token inválido ou expirado'
    });
  }
});

// ================================================================
//  📦 FUNÇÕES PARA SALVAR E BUSCAR DO FIRESTORE
// ================================================================

async function salvarEmBlocos(colecao, itens, tamanhoBloco = 50) {
  if (!itens || itens.length === 0) {
    console.log(`⚠️ Nenhum item para salvar na coleção ${colecao}`);
    return 0;
  }

  const totalBlocos = Math.ceil(itens.length / tamanhoBloco);
  console.log(`📦 Salvando ${itens.length} itens em ${totalBlocos} blocos (${tamanhoBloco} cada)`);

  for (let i = 0; i < totalBlocos; i++) {
    const inicio = i * tamanhoBloco;
    const fim = Math.min(inicio + tamanhoBloco, itens.length);
    const blocoItens = itens.slice(inicio, fim);

    await db.collection(colecao).doc(`bloco_${i + 1}`).set({
      bloco: i + 1,
      total_itens: blocoItens.length,
      itens: blocoItens,
      atualizado_em: new Date().toISOString()
    });
    console.log(`✅ Bloco ${i + 1}/${totalBlocos} salvo (${blocoItens.length} itens)`);
  }

  await db.collection(colecao).doc('_metadados').set({
    total_itens: itens.length,
    total_blocos: totalBlocos,
    tamanho_bloco: tamanhoBloco,
    atualizado_em: new Date().toISOString()
  });

  console.log(`✅ ${itens.length} itens salvos em ${totalBlocos} blocos!`);
  return totalBlocos;
}

async function buscarTodosBlocos(colecao) {
  try {
    const metaDoc = await db.collection(colecao).doc('_metadados').get();
    if (!metaDoc.exists) return null;

    const meta = metaDoc.data();
    console.log(`📦 ${meta.total_itens} itens em ${meta.total_blocos} blocos`);

    const todosItens = [];
    for (let i = 1; i <= meta.total_blocos; i++) {
      const blocoDoc = await db.collection(colecao).doc(`bloco_${i}`).get();
      if (blocoDoc.exists) {
        const dados = blocoDoc.data();
        todosItens.push(...dados.itens);
      }
    }

    return {
      total: meta.total_itens,
      total_blocos: meta.total_blocos,
      itens: todosItens,
      atualizado_em: meta.atualizado_em
    };

  } catch (error) {
    console.error(`❌ Erro ao buscar blocos da coleção ${colecao}:`, error.message);
    return null;
  }
}

// ================================================================
//                        🗄️ CACHE EM MEMÓRIA
// ================================================================
const cache = new Map();
const CACHE_TTL = {
  HOME: 86400000,
  FILMES: 86400000,
  SERIES: 86400000,
  ANIMACOES: 86400000,
  ULTIMOS_FILMES: 3600000,
  CARROSSEL: 86400000,
  LANCAMENTOS: 86400000,
  COLECOES: 86400000,
  CATEGORIA: 86400000,
  BUSCA: 86400000,
  AGENDA: 432000000
};

function getCache(key) {
  if (cache.has(key)) {
    const item = cache.get(key);
    if (Date.now() < item.expiry) {
      console.log(`✅ Cache HIT: ${key}`);
      return item.data;
    } else {
      console.log(`⏰ Cache EXPIRED: ${key}`);
      cache.delete(key);
      return null;
    }
  }
  console.log(`❌ Cache MISS: ${key}`);
  return null;
}

function setCache(key, data, ttl = 86400000) {
  cache.set(key, {
    data: data,
    expiry: Date.now() + ttl
  });
  console.log(`💾 Cache SAVED: ${key} (expira em ${ttl/1000/60/60} horas)`);
}

function clearCache() {
  cache.clear();
  console.log('🧹 Cache limpo!');
}

setInterval(clearCache, 24 * 60 * 60 * 1000);

// ================================================================
// 🌐 CARREGAMENTO INICIAL – HTML + COOKIE
// ================================================================
let HOME_HTML = '';
let FILMES_HTML = '';
let SERIES_HTML = '';
let ANIMACOES_HTML = '';
let COOKIE_STRING = '';

// ================================================================
// 🌐 CARREGAMENTO HOME
// ================================================================
async function carregarHome() {
  try {
    console.log('🌐 Carregando página inicial...');
    const response = await axios.get(`${URL_BASE}/`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'
      },
      timeout: 15000,
      maxRedirects: 5,
      validateStatus: status => status < 500
    });

    HOME_HTML = response.data || '';
    const setCookie = response.headers['set-cookie'];
    if (setCookie && setCookie.length > 0) {
      const cookieArray = Array.isArray(setCookie) ? setCookie : [setCookie];
      COOKIE_STRING = cookieArray.map(cookie => cookie.split(';')[0]).join('; ');
      console.log('🍪 Cookies obtidos:', COOKIE_STRING);
    } else {
      COOKIE_STRING = '';
      console.warn('⚠️ Nenhum cookie retornado pelo servidor.');
    }

    console.log(`📄 HTML carregado: ${HOME_HTML.length} bytes`);
    console.log('✅ Página inicial carregada com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao carregar home:', error.message);
  }
}

// ================================================================
// 🌐 FUNÇÃO PARA OBTER COOKIE DO MEGACINE (USADO NA AGENDA)
// ================================================================
async function obterCookieMegacine() {
  try {
    console.log('🍪 Obtendo cookie do megacine para agenda...');
    const response = await axios.get(`${URL_BASE_NOVELAS}/`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'
      },
      timeout: 15000,
      maxRedirects: 5,
      validateStatus: status => status < 500
    });

    const setCookie = response.headers['set-cookie'];
    if (setCookie && setCookie.length > 0) {
      const cookieArray = Array.isArray(setCookie) ? setCookie : [setCookie];
      const cookiesFiltrados = cookieArray
        .map(cookie => cookie.split(';')[0])
        .filter(cookie => cookie.includes('PHPSESSID') || cookie.includes('wordpress'));
      
      if (cookiesFiltrados.length > 0) {
        const cookieString = cookiesFiltrados.join('; ');
        console.log('✅ Cookie do megacine obtido com sucesso');
        return cookieString;
      }
    }
    
    console.log('⚠️ Usando cookie padrão para megacine');
    return process.env.COOKIE_STRING || '';
    
  } catch (error) {
    console.error('❌ Erro ao obter cookie do megacine:', error.message);
    return process.env.COOKIE_STRING || '';
  }
}

// ================================================================
// 🌐 CARREGAMENTO FILMES
// ================================================================
async function carregarFilmes() {
  try {
    console.log('🌐 Carregando página filmes...');
    const response = await axios.get(`${URL_BASE}/filmes/`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
      },
      timeout: 15000,
      maxRedirects: 5,
      validateStatus: status => status < 500
    });
    FILMES_HTML = response.data || '';
    console.log(`📄 HTML filmes carregado: ${FILMES_HTML.length} bytes`);
    console.log('✅ Página filmes carregada com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao carregar filmes:', error.message);
  }
}

// ================================================================
// 🌐 CARREGAMENTO SÉRIES
// ================================================================
async function carregarSeries() {
  try {
    console.log('🌐 Carregando página séries...');
    const response = await axios.get(`${URL_BASE}/series/`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
      },
      timeout: 15000,
      maxRedirects: 5,
      validateStatus: status => status < 500
    });
    SERIES_HTML = response.data || '';
    console.log(`📄 HTML séries carregado: ${SERIES_HTML.length} bytes`);
    console.log('✅ Página séries carregada com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao carregar séries:', error.message);
  }
}

// ================================================================
// 🌐 CARREGAMENTO ANIMAÇÕES
// ================================================================
async function carregarAnimacoes() {
  try {
    console.log('🌐 Carregando página animações...');
    const response = await axios.get(`${URL_BASE}/genero/animacao/`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'referer': `${URL_BASE}/series/`,
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
      },
      timeout: 15000,
      maxRedirects: 5,
      validateStatus: status => status < 500
    });
    ANIMACOES_HTML = response.data || '';
    console.log(`📄 HTML animações carregado: ${ANIMACOES_HTML.length} bytes`);
    console.log('✅ Página animações carregada com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao carregar animações:', error.message);
  }
}

// ================================================================
// 🚀 INICIA OS CARREGAMENTOS
// ================================================================
carregarHome();
carregarFilmes();
carregarSeries();
carregarAnimacoes();

setInterval(carregarHome, 6 * 60 * 60 * 1000);
setInterval(carregarFilmes, 6 * 60 * 60 * 1000);
setInterval(carregarSeries, 6 * 60 * 60 * 1000);
setInterval(carregarAnimacoes, 6 * 60 * 60 * 1000);

// ================================================================
// 🔍 ENDPOINT: /api/buscar (POST)
// ================================================================
app.post('/api/buscar', async (req, res) => {
  try {
    const { query, pagina } = req.body;
    const searchQuery = query || req.query.q || req.query.query || '';
    const page = parseInt(pagina) || 1;

    if (!searchQuery || searchQuery.trim().length < 2) {
      return res.json({
        query: searchQuery,
        total: 0,
        resultados: [],
        mensagem: 'Digite pelo menos 2 caracteres'
      });
    }

    console.log(`🔍 Buscando: "${searchQuery}" - Página ${page}`);

    const response = await axios.post(
      `${URL_BASE}/`,
      `do=search&subaction=search&story=${encodeURIComponent(searchQuery.trim())}`,
      {
        headers: {
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
          'accept-encoding': 'gzip, deflate, br, zstd',
          'accept-language': 'pt-BR,pt;q=0.9',
          'cache-control': 'no-cache',
          'content-type': 'application/x-www-form-urlencoded',
          'cookie': COOKIE_STRING || '',
          'origin': URL_BASE,
          'pragma': 'no-cache',
          'priority': 'u=0, i',
          'referer': `${URL_BASE}/`,
          'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
          'sec-ch-ua-mobile': '?0',
          'sec-ch-ua-platform': '"Windows"',
          'sec-fetch-dest': 'document',
          'sec-fetch-mode': 'navigate',
          'sec-fetch-site': 'same-origin',
          'sec-fetch-user': '?1',
          'sec-gpc': '1',
          'upgrade-insecure-requests': '1',
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'
        },
        timeout: 15000,
        maxRedirects: 5
      }
    );

    const html = response.data;
    const $ = cheerio.load(html);
    const resultados = [];

    $('#dle-content .default.poster.grid-item').each((i, el) => {
      const item = $(el);
      const linkElement = item.find('.poster__title a');
      const link = linkElement.attr('href') || '';
      const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
      const imgElement = item.find('.poster__img img');
      const imagem = imgElement.attr('src') || '';
      const ano = item.find('.bslide__meta span').first().text().trim() || '';
      let nota = 0;
      const notaElement = item.find('.bslide__meta .rating');
      if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
      const generos = [];
      item.find('.onslide-cats a').each((j, catEl) => {
        const genero = $(catEl).text().trim();
        if (genero && genero !== 'Filmes' && genero !== 'Séries') generos.push(genero);
      });
      let tipo = 'Filme';
      const ultimoGenero = item.find('.onslide-cats a').last().text().trim();
      if (ultimoGenero === 'Séries' || link.includes('/series/')) tipo = 'Série';
      else if (ultimoGenero === 'Animação' || link.includes('/genero/animacao/')) tipo = 'Animação';
      if (titulo && link) {
        resultados.push({ titulo, imagem, nota, ano, generos, tipo, link_assistir: link });
      }
    });

    let totalPaginas = 1;
    const paginationLinks = $('.pagination .pagination__pages a');
    if (paginationLinks.length > 0) {
      const ultimoLink = paginationLinks.last();
      const ultimoNumero = parseInt(ultimoLink.text().trim());
      if (!isNaN(ultimoNumero) && ultimoNumero > totalPaginas) totalPaginas = ultimoNumero;
    }
    const hasNext = $('.pagination .pagination__pages-btn a[onclick*="list_submit"]').length > 0;
    res.json({ query: searchQuery, total: resultados.length, total_paginas: totalPaginas, pagina_atual: page, has_next: hasNext, resultados });
  } catch (error) {
    console.error('❌ Erro na busca:', error.message);
    res.status(500).json({ erro: 'Erro ao realizar busca', detalhe: error.message });
  }
});

// ================================================================
// 🔍 ENDPOINT: /api/buscar/:query (GET)
// ================================================================
app.get('/api/buscar/:query', async (req, res) => {
  try {
    const query = req.params.query.trim();
    const pagina = parseInt(req.query.pagina) || 1;
    if (!query || query.length < 2) {
      return res.json({ query: query, total: 0, resultados: [], mensagem: 'Digite pelo menos 2 caracteres' });
    }
    console.log(`🔍 Buscando GET: "${query}" - Página ${pagina}`);
    const url = pagina === 1 
      ? `${URL_BASE}/index.php?do=search&subaction=search&story=${encodeURIComponent(query)}`
      : `${URL_BASE}/index.php?do=search&subaction=search&story=${encodeURIComponent(query)}&page=${pagina}`;
    const { data: html } = await axios.get(url, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
      },
      timeout: 15000
    });
    const $ = cheerio.load(html);
    const resultados = [];
    $('#dle-content .default.poster.grid-item').each((i, el) => {
      const item = $(el);
      const linkElement = item.find('.poster__title a');
      const link = linkElement.attr('href') || '';
      const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
      const imgElement = item.find('.poster__img img');
      const imagem = imgElement.attr('src') || '';
      const ano = item.find('.bslide__meta span').first().text().trim() || '';
      let nota = 0;
      const notaElement = item.find('.bslide__meta .rating');
      if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
      const generos = [];
      item.find('.onslide-cats a').each((j, catEl) => {
        const genero = $(catEl).text().trim();
        if (genero && genero !== 'Filmes' && genero !== 'Séries') generos.push(genero);
      });
      let tipo = 'Filme';
      const ultimoGenero = item.find('.onslide-cats a').last().text().trim();
      if (ultimoGenero === 'Séries' || link.includes('/series/')) tipo = 'Série';
      else if (ultimoGenero === 'Animação' || link.includes('/genero/animacao/')) tipo = 'Animação';
      if (titulo && link) {
        resultados.push({ titulo, imagem, nota, ano, generos, tipo, link_assistir: link });
      }
    });
    let totalPaginas = 1;
    const paginationLinks = $('.pagination .pagination__pages a');
    if (paginationLinks.length > 0) {
      const ultimoLink = paginationLinks.last();
      const ultimoNumero = parseInt(ultimoLink.text().trim());
      if (!isNaN(ultimoNumero) && ultimoNumero > totalPaginas) totalPaginas = ultimoNumero;
    }
    res.json({ query: query, total: resultados.length, total_paginas: totalPaginas, pagina_atual: pagina, resultados });
  } catch (error) {
    console.error('❌ Erro na busca GET:', error.message);
    res.status(500).json({ erro: 'Erro ao realizar busca', detalhe: error.message });
  }
});

// ================================================================
// 🎠 ENDPOINT: /api/home/carousel (FIXO - SEM FIRESTORE)
// ================================================================

const CAROUSEL_FIXO = [
  {
    titulo: "A Casa do Dragão – House of the Dragon",
    imagem: "https://image.tmdb.org/t/p/original/577eXC8wFQT0eUrJcgznSiFPRmk.jpg",
    logo: "https://image.tmdb.org/t/p/w500/14UIbr8ETzGnDe0eB2NUiJovg3o.png",
    nota: 8.3,
    ano: "2022",
    tipo: "Série",
    descricao: "200 anos antes dos eventos de 'Game of Thrones', os Targaryen estavam no ápice de seu poder, tendo inúmeros dragões sob seu comando, mas nem tudo dura para sempre. O início do…",
    generos: ["Action & Adventure", "Drama", "Sci-Fi & Fantasy"],
    link_assistir: "https://novelasflix.video/drama/6068-a-casa-do-dragao-noads"
  },
  {
    titulo: "Stuart Não Consegue Salvar o Universo – Stuart Fails to Save the Universe",
    imagem: "https://image.tmdb.org/t/p/original/2ngdvUiEKW8Q37ta8BBdydE2cuq.jpg",
    logo: "https://image.tmdb.org/t/p/w500/sHUYYn9Pb4GeVOZ1gm3vK9NIp1Q.png",
    nota: 8.7,
    ano: "2026",
    tipo: "Série",
    descricao: "O dono da loja de quadrinhos Stuart Bloom é encarregado de restaurar a realidade após quebrar acidentalmente um dispositivo construído por Sheldon e Leonard, desencadeando um Armagedom no multiverso. Nessa missão, Stuart…",
    generos: ["Comédia", "Sci-Fi & Fantasy"],
    link_assistir: "https://novelasflix.video/comedia/13761-stuart-nao-consegue-salvar-o-universo"
  },
  {
    titulo: "Dia D",
    imagem: "https://image.tmdb.org/t/p/original/s6ly8laenkHWlIBRkLSfIuEMLC6.jpg",
    logo: "https://image.tmdb.org/t/p/w500/9pp8pOfBZBM5WXoZ0DmMrDOlqPH.png",
    nota: 7.0,
    ano: "2026",
    tipo: "Filme",
    descricao: "A existência de vida extraterrestre torna-se uma realidade inegável para todos os habitantes da Terra em um único instante. O mundo entra em colapso quando uma meteorologista, em plena transmissão ao vivo,…",
    generos: ["Ação", "Ficção científica", "Thriller"],
    link_assistir: "https://novelasflix.video/suspense/13362-dia-d"
  },
  {
    titulo: "Todo Mundo em Pânico 6",
    imagem: "https://m.media-amazon.com/images/S/pv-target-images/176ce41686585da6854ae7deab3fa3f3d672d689d4678773d033812673afd6dc._SX1080_FMjpg_.jpg",
    logo: "https://image.tmdb.org/t/p/original/ashfJUIvWyypy2YxaKA4k0ahMY4.png",
    nota: 6.5,
    ano: "2026",
    tipo: "Filme",
    descricao: "Vinte e seis anos depois de escaparem de um assassino mascarado suspeitosamente familiar, o Quarteto Fantástico está de volta à mira do criminoso, e nenhuma propriedade intelectual de filmes de terror está a salvo.",
    generos: ["Comédia"],
    link_assistir: "https://novelasflix.video/comedia/13768-todo-mundo-em-panico-6"
  },
  {
    titulo: "Como Mágica",
    imagem: "https://media.themoviedb.org/t/p/w533_and_h300_face/q5LJT8QYjUU4uKlT9x2aQpxz09t.jpg",
    logo: "https://image.tmdb.org/t/p/original/v1ZdIuHLmv3NmDzOEXnNwZsnMNY.png",
    nota: 8.2,
    ano: "2026",
    tipo: "Filme",
    descricao: "Uma pequena criatura da floresta e um pássaro majestoso trocam de corpo e precisam se unir para sobreviver à aventura mais incrível de suas vidas.",
    generos: ["Aventura"],
    link_assistir: "https://novelasflix.video/aventura/12978-como-magica"
  }
];

app.get('/api/home/carousel', async (req, res) => {
  res.json({
    fonte: 'fixo',
    total: CAROUSEL_FIXO.length,
    itens: CAROUSEL_FIXO
  });
});

// ================================================================
// 📅 ENDPOINT: /api/home/agenda
// ================================================================
// 📅 ENDPOINT: /api/home/agenda (CACHE + SCRAPING - SEM FIRESTORE)
app.get('/api/home/agenda', async (req, res) => {
  const cacheKey = 'home_agenda';
  
  // Tenta pegar do cache primeiro (igual aos lançamentos)
  const cached = getCache(cacheKey);
  if (cached && cached.dias && cached.dias.length > 0) {
    return res.json({ fonte: 'cache_memoria', ...cached });
  }

  try {
    console.log('📅 Cache EXPIRADO - Fazendo scraping da agenda...');

    // Busca o cookie do megacine
    const cookieMegacine = await obterCookieMegacine();
    
    const { data: html } = await axios.get(`${URL_BASE_NOVELAS}/generos/acao`, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'cookie': cookieMegacine,
        'referer': 'https://megacine.quest/'
      },
      timeout: 15000
    });

    const $ = cheerio.load(html);
    const dias = [];

    $('.megacine-release-calendar-widget .mc-calendar__day, .mc-calendar .mc-calendar__day, .mc-calendar__days .mc-calendar__day').each((i, dayEl) => {
      const day = $(dayEl);
      const nomeDia = day.find('h3').text().trim() || '';
      const dataEl = day.find('time');
      const data = dataEl.attr('datetime') || '';
      const dataFormatada = dataEl.text().trim() || '';
      
      let tipoDia = 'outro';
      const nomeLower = nomeDia.toLowerCase();
      if (nomeLower.includes('hoje')) tipoDia = 'hoje';
      else if (nomeLower.includes('amanhã') || nomeLower.includes('amanha')) tipoDia = 'amanha';
      
      const episodios = [];
      
      day.find('.mc-calendar__item').each((j, itemEl) => {
        const item = $(itemEl);
        const link = item.find('a').attr('href') || '';
        const horario = item.find('.mc-calendar__time').text().trim() || '';
        const tituloEp = item.find('a').attr('title') || '';
        const serie = item.find('.mc-calendar__series').text().trim() || '';
        const episodio = item.find('.mc-calendar__episode').text().trim() || '';
        
        let temporada = null;
        let numeroEpisodio = null;
        const epMatch = episodio.match(/T(\d+)\s*E(\d+)/i);
        if (epMatch) {
          temporada = parseInt(epMatch[1]);
          numeroEpisodio = parseInt(epMatch[2]);
        }
        
        episodios.push({
          titulo: tituloEp || `Episódio ${episodio}`,
          serie: serie || 'Série',
          episodio: episodio,
          temporada: temporada,
          numero: numeroEpisodio,
          horario: horario || '--:--',
          link: link
        });
      });
      
      if (episodios.length > 0 || nomeDia) {
        dias.push({
          nome: nomeDia || 'Dia',
          data: data,
          data_formatada: dataFormatada,
          tipo: tipoDia,
          total_episodios: episodios.length,
          episodios: episodios
        });
      }
    });

    const responseData = {
      total_dias: dias.length,
      total_episodios: dias.reduce((acc, d) => acc + d.total_episodios, 0),
      dias: dias
    };

    // Salva no cache por 2 horas (7200000 ms) - IGUAL AOS LANÇAMENTOS
    setCache(cacheKey, responseData, 7200000);
    console.log(`💾 Agenda salva no cache por 2 horas (${dias.length} dias, ${responseData.total_episodios} episódios)`);

    res.json({
      fonte: 'scraping',
      ...responseData
    });

  } catch (error) {
    console.error('❌ Erro ao fazer scraping da agenda:', error);
    res.status(500).json({
      erro: 'Erro ao buscar agenda de lançamentos',
      detalhe: error.message
    });
  }
});
// ================================================================
// 🎬 ENDPOINT: /api/ultimos-filmes
// ================================================================
// 🎬 ENDPOINT: /api/ultimos-filmes (CACHE + SCRAPING - SEM FIRESTORE)
app.get('/api/ultimos-filmes', async (req, res) => {
  const cacheKey = 'ultimos_filmes';
  
  // Tenta pegar do cache primeiro
  const cached = getCache(cacheKey);
  if (cached) {
    return res.json({ fonte: 'cache_memoria', filmes: cached });
  }

  // Verifica se o HTML da home está carregado
  if (!HOME_HTML) {
    return res.status(503).json({ erro: 'Página inicial ainda não carregada. Tente novamente em alguns segundos.' });
  }

  try {
    console.log('🎬 Cache EXPIRADO - Fazendo scraping dos últimos filmes...');
    const $ = cheerio.load(HOME_HTML);
    const filmes = [];

    $('#slick-big .bslide').each((i, el) => {
      const item = $(el);
      const linkElement = item.find('.bslide__poster a');
      const link = linkElement.attr('href') || '';
      const imgElement = item.find('.bslide__poster img');
      const imagem = imgElement.attr('src') || '';
      const titulo = item.find('.bslide__title').text().trim() || '';
      const ano = item.find('.bslide__meta span').first().text().trim() || '';
      let nota = 0;
      const notaElement = item.find('.bslide__meta .rating');
      if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
      const generos = [];
      item.find('.onslide-cats a').each((j, catEl) => {
        const genero = $(catEl).text().trim();
        if (genero && genero !== 'Filmes') generos.push(genero);
      });
      filmes.push({ titulo, imagem, nota, ano, generos, link_assistir: link });
    });

    // Salva no cache por 1 hora (3600000 ms) - IGUAL AOS LANÇAMENTOS
    setCache(cacheKey, filmes, 3600000);
    console.log(`💾 Últimos filmes salvos no cache por 1 hora (${filmes.length} filmes)`);

    res.json({ 
      fonte: 'scraping', 
      total: filmes.length, 
      filmes 
    });

  } catch (error) {
    console.error('❌ Erro ao extrair últimos filmes:', error);
    res.status(500).json({ 
      erro: 'Erro ao extrair últimos filmes',
      detalhe: error.message 
    });
  }
});
// ================================================================
// 🆕 ENDPOINT: /api/home/Lançamentos (SEM FIRESTORE - SEMPRE SCRAPING)
// ================================================================
app.get('/api/home/lancamentos', async (req, res) => {
  const cacheKey = 'home_novos_online';
  
  // TTL menor: 1 hora (os dados mudam a cada 6 horas quando o HTML é recarregado)
  const cached = getCache(cacheKey);
  if (cached) {
    return res.json({ fonte: 'cache_memoria', ...cached });
  }

  if (!HOME_HTML) {
    return res.status(503).json({ 
      erro: 'Página inicial ainda não carregada. Tente novamente em alguns segundos.' 
    });
  }

  try {
    console.log('🆕 Fazendo scraping dos Novos Online...');
    const $ = cheerio.load(HOME_HTML);
    const resultados = [];

    // Seletor atualizado para o novo HTML
    $('.slick-home-generic[data-content="news"] .default.poster.grid-item, #slick-big .bslide').each((i, el) => {
      const item = $(el);
      const linkElement = item.find('.poster__title a, .bslide__poster a');
      const link = linkElement.attr('href') || '';
      const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
      const imgElement = item.find('.poster__img img, .bslide__poster img');
      const imagem = imgElement.attr('src') || '';
      const ano = item.find('.bslide__meta span').first().text().trim() || '';
      let nota = 0;
      const notaElement = item.find('.bslide__meta .rating');
      if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
      const generos = [];
      item.find('.onslide-cats a').each((j, catEl) => {
        const genero = $(catEl).text().trim();
        if (genero && genero !== 'Filmes' && genero !== 'Séries') generos.push(genero);
      });
      let tipo = 'Filme';
      const ultimoGenero = item.find('.onslide-cats a').last().text().trim();
      if (ultimoGenero === 'Séries' || link.includes('/series/')) tipo = 'Série';
      else if (ultimoGenero === 'Animação' || link.includes('/genero/animacao/')) tipo = 'Animação';
      
      if (titulo && link) {
        resultados.push({ titulo, imagem, nota, ano, generos, tipo, link_assistir: link });
      }
    });

    const responseData = {
      total: resultados.length,
      titulo_secao: 'Assistir Novos Online',
      link_ver_tudo: '/new.html',
      resultados
    };

    // Cache em memória por 1 hora (menor que o TTL do HTML que é 6 horas)
    setCache(cacheKey, responseData, 3600000); // 1 hora
    res.json({ fonte: 'scraping', ...responseData });
  } catch (error) {
    console.error('Erro ao extrair novos online:', error);
    res.status(500).json({ erro: 'Erro ao extrair novos online' });
  }
});

// ================================================================
// 🎬 ENDPOINT: /api/filmes/stream
// ================================================================
app.get('/api/filmes/stream', async (req, res) => {
  try {
    const firestoreData = await buscarTodosBlocos('filmes');
    if (firestoreData && firestoreData.itens.length > 0) {
      console.log(`✅ Filmes do Firestore: ${firestoreData.total} filmes`);
      return res.json({
        fonte: 'firestore',
        total: firestoreData.total,
        atualizado_em: firestoreData.atualizado_em,
        filmes: firestoreData.itens
      });
    }

    console.log('🎬 Filmes não encontrados no Firestore, fazendo streaming...');
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    res.write('{\n  "fonte": "scraping",\n  "status": "carregando",\n  "total_paginas": 0,\n  "filmes": [\n');

    let totalPaginas = 435;
    let primeiro = true;
    let totalFilmes = 0;
    const filmesParaSalvar = [];

    console.log(`🎬 Iniciando streaming de filmes (${totalPaginas} páginas)`);

    for (let pagina = 1; pagina <= totalPaginas; pagina++) {
      const url = pagina === 1 ? `${URL_BASE}/filmes/` : `${URL_BASE}/filmes/page/${pagina}/`;
      console.log(`🎬 Buscando filmes página ${pagina}/${totalPaginas}`);

      try {
        const { data: html } = await axios.get(url, {
          headers: {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'pt-BR,pt;q=0.9',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'priority': 'u=0, i',
            'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
            ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
          },
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: status => status < 500
        });

        const $ = cheerio.load(html);
        const itens = $('.default.poster.grid-item');

        if (itens.length === 0) {
          console.log(`⚠️ Nenhum filme encontrado na página ${pagina}`);
          break;
        }

        itens.each((i, el) => {
          const item = $(el);
          const linkElement = item.find('.poster__title a');
          const link = linkElement.attr('href') || '';
          const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
          const imgElement = item.find('.poster__img img');
          const imagem = imgElement.attr('src') || '';
          const ano = item.find('.bslide__meta span').first().text().trim() || '';
          let nota = 0;
          const notaElement = item.find('.bslide__meta .rating');
          if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
          const generos = [];
          item.find('.onslide-cats a').each((j, catEl) => {
            const genero = $(catEl).text().trim();
            if (genero && genero !== 'Filmes') generos.push(genero);
          });
          const filme = { titulo, imagem, nota, ano, generos, link_assistir: link, pagina };
          filmesParaSalvar.push(filme);
          if (!primeiro) res.write(',\n');
          primeiro = false;
          res.write(JSON.stringify(filme, null, 2));
          totalFilmes++;
        });

        res.write(`\n  // ✅ Página ${pagina}/${totalPaginas} carregada (${itens.length} filmes)`);
        await new Promise(resolve => setTimeout(resolve, 150));
      } catch (err) {
        console.log(`❌ Erro página ${pagina}:`, err.message);
        res.write(`\n  // ⚠️ Erro na página ${pagina}: ${err.message}`);
        continue;
      }
    }

    if (filmesParaSalvar.length > 0) {
      await salvarEmBlocos('filmes', filmesParaSalvar, 100);
    }

    res.write('\n  ],\n');
    res.write(`  "total_filmes": ${totalFilmes},\n`);
    res.write(`  "paginas_processadas": ${totalPaginas},\n`);
    res.write(`  "status": "completo"\n`);
    res.write('}');
    res.end();

    console.log(`✅ Stream finalizado: ${totalFilmes} filmes em ${totalPaginas} páginas`);
  } catch (error) {
    console.error('❌ Erro no stream:', error);
    if (!res.headersSent) {
      res.status(500).json({ erro: 'Erro ao processar stream', detalhe: error.message });
    } else {
      res.write('\n  // ❌ ERRO: ' + error.message + '\n');
      res.write('  }],\n  "status": "erro"\n}');
      res.end();
    }
  }
});

// ================================================================
// 📺 ENDPOINT: /api/series/stream
// ================================================================
app.get('/api/series/stream', async (req, res) => {
  try {
    const firestoreData = await buscarTodosBlocos('series');
    if (firestoreData && firestoreData.itens.length > 0) {
      console.log(`✅ Séries do Firestore: ${firestoreData.total} séries`);
      return res.json({
        fonte: 'firestore',
        total: firestoreData.total,
        atualizado_em: firestoreData.atualizado_em,
        series: firestoreData.itens
      });
    }

    console.log('📺 Séries não encontradas no Firestore, fazendo streaming...');
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    res.write('{\n  "fonte": "scraping",\n  "status": "carregando",\n  "total_paginas": 0,\n  "series": [\n');

    let totalPaginas = 41;
    let primeiro = true;
    let totalSeries = 0;
    const seriesParaSalvar = [];

    console.log(`📺 Iniciando streaming de séries (${totalPaginas} páginas)`);

    for (let pagina = 1; pagina <= totalPaginas; pagina++) {
      const url = pagina === 1 ? `${URL_BASE}/series/` : `${URL_BASE}/series/page/${pagina}/`;
      console.log(`📺 Buscando séries página ${pagina}/${totalPaginas}`);

      try {
        const { data: html } = await axios.get(url, {
          headers: {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'pt-BR,pt;q=0.9',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'priority': 'u=0, i',
            'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
            ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
          },
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: status => status < 500
        });

        const $ = cheerio.load(html);
        const itens = $('.default.poster.grid-item');

        if (itens.length === 0) {
          console.log(`⚠️ Nenhuma série encontrada na página ${pagina}`);
          break;
        }

        itens.each((i, el) => {
          const item = $(el);
          const linkElement = item.find('.poster__title a');
          const link = linkElement.attr('href') || '';
          const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
          const imgElement = item.find('.poster__img img');
          const imagem = imgElement.attr('src') || '';
          const ano = item.find('.bslide__meta span').first().text().trim() || '';
          let nota = 0;
          const notaElement = item.find('.bslide__meta .rating');
          if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
          const generos = [];
          item.find('.onslide-cats a').each((j, catEl) => {
            const genero = $(catEl).text().trim();
            if (genero && genero !== 'Séries') generos.push(genero);
          });
          const serie = { titulo, imagem, nota, ano, generos, link_assistir: link, pagina };
          seriesParaSalvar.push(serie);
          if (!primeiro) res.write(',\n');
          primeiro = false;
          res.write(JSON.stringify(serie, null, 2));
          totalSeries++;
        });

        res.write(`\n  // ✅ Página ${pagina}/${totalPaginas} carregada (${itens.length} séries)`);
        await new Promise(resolve => setTimeout(resolve, 150));
      } catch (err) {
        console.log(`❌ Erro página ${pagina}:`, err.message);
        res.write(`\n  // ⚠️ Erro na página ${pagina}: ${err.message}`);
        continue;
      }
    }

    if (seriesParaSalvar.length > 0) {
      await salvarEmBlocos('series', seriesParaSalvar, 100);
    }

    res.write('\n  ],\n');
    res.write(`  "total_series": ${totalSeries},\n`);
    res.write(`  "paginas_processadas": ${totalPaginas},\n`);
    res.write(`  "status": "completo"\n`);
    res.write('}');
    res.end();

    console.log(`✅ Stream finalizado: ${totalSeries} séries em ${totalPaginas} páginas`);
  } catch (error) {
    console.error('❌ Erro no stream:', error);
    if (!res.headersSent) {
      res.status(500).json({ erro: 'Erro ao processar stream', detalhe: error.message });
    } else {
      res.write('\n  // ❌ ERRO: ' + error.message + '\n');
      res.write('  }],\n  "status": "erro"\n}');
      res.end();
    }
  }
});

// ================================================================
// 🎬 ENDPOINT: /api/animacoes/stream
// ================================================================
app.get('/api/animacoes/stream', async (req, res) => {
  try {
    const firestoreData = await buscarTodosBlocos('animacoes');
    if (firestoreData && firestoreData.itens.length > 0) {
      console.log(`✅ Animações do Firestore: ${firestoreData.total} animações`);
      return res.json({
        fonte: 'firestore',
        total: firestoreData.total,
        atualizado_em: firestoreData.atualizado_em,
        animacoes: firestoreData.itens
      });
    }

    console.log('🎬 Animações não encontradas no Firestore, fazendo streaming...');
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    res.write('{\n  "fonte": "scraping",\n  "status": "carregando",\n  "total_paginas": 0,\n  "animacoes": [\n');

    let totalPaginas = 31;
    let primeiro = true;
    let totalAnimacoes = 0;
    const animacoesParaSalvar = [];

    console.log(`🎬 Iniciando streaming de animações (${totalPaginas} páginas)`);

    for (let pagina = 1; pagina <= totalPaginas; pagina++) {
      const url = pagina === 1 ? `${URL_BASE}/genero/animacao/` : `${URL_BASE}/genero/animacao/page/${pagina}/`;
      console.log(`🎬 Buscando animações página ${pagina}/${totalPaginas}`);

      try {
        const { data: html } = await axios.get(url, {
          headers: {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'pt-BR,pt;q=0.9',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'priority': 'u=0, i',
            'referer': `${URL_BASE}/series/`,
            'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
            ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
          },
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: status => status < 500
        });

        const $ = cheerio.load(html);
        const itens = $('.default.poster.grid-item');

        if (itens.length === 0) {
          console.log(`⚠️ Nenhuma animação encontrada na página ${pagina}`);
          break;
        }

        itens.each((i, el) => {
          const item = $(el);
          const linkElement = item.find('.poster__title a');
          const link = linkElement.attr('href') || '';
          const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
          const imgElement = item.find('.poster__img img');
          const imagem = imgElement.attr('src') || '';
          const ano = item.find('.bslide__meta span').first().text().trim() || '';
          let nota = 0;
          const notaElement = item.find('.bslide__meta .rating');
          if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
          const generos = [];
          item.find('.onslide-cats a').each((j, catEl) => {
            const genero = $(catEl).text().trim();
            if (genero && genero !== 'Animação') generos.push(genero);
          });
          const animacao = { titulo, imagem, nota, ano, generos, link_assistir: link, pagina };
          animacoesParaSalvar.push(animacao);
          if (!primeiro) res.write(',\n');
          primeiro = false;
          res.write(JSON.stringify(animacao, null, 2));
          totalAnimacoes++;
        });

        res.write(`\n  // ✅ Página ${pagina}/${totalPaginas} carregada (${itens.length} animações)`);
        await new Promise(resolve => setTimeout(resolve, 150));
      } catch (err) {
        console.log(`❌ Erro página ${pagina}:`, err.message);
        res.write(`\n  // ⚠️ Erro na página ${pagina}: ${err.message}`);
        continue;
      }
    }

    if (animacoesParaSalvar.length > 0) {
      await salvarEmBlocos('animacoes', animacoesParaSalvar, 100);
    }

    res.write('\n  ],\n');
    res.write(`  "total_animacoes": ${totalAnimacoes},\n`);
    res.write(`  "paginas_processadas": ${totalPaginas},\n`);
    res.write(`  "status": "completo"\n`);
    res.write('}');
    res.end();

    console.log(`✅ Stream finalizado: ${totalAnimacoes} animações em ${totalPaginas} páginas`);
  } catch (error) {
    console.error('❌ Erro no stream:', error);
    if (!res.headersSent) {
      res.status(500).json({ erro: 'Erro ao processar stream', detalhe: error.message });
    } else {
      res.write('\n  // ❌ ERRO: ' + error.message + '\n');
      res.write('  }],\n  "status": "erro"\n}');
      res.end();
    }
  }
});

// ================================================================
// 🎭 ENDPOINTS DE GÊNEROS - STREAMING
// ================================================================

app.get('/api/genero/drama/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'drama', 190);
});

app.get('/api/genero/suspense/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'suspense', 144);
});

app.get('/api/genero/aventura/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'aventura', 103);
});

app.get('/api/genero/acao/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'acao', 149);
});

app.get('/api/genero/ficcao/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'ficcao', 10);
});

app.get('/api/genero/comedia/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'comedia', 127);
});

app.get('/api/genero/terror/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'terror', 88);
});

app.get('/api/genero/romance/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'romance', 55);
});

app.get('/api/genero/ficcao-cientifica/stream', async (req, res) => {
  await streamGeneroComFirestore(req, res, 'ficcao-cientifica', 37);
});

// ================================================================
// 🎭 FUNÇÃO GENÉRICA PARA STREAM DE GÊNEROS
// ================================================================
async function streamGeneroComFirestore(req, res, genero, totalPaginas) {
  try {
    const nomeGenero = genero.charAt(0).toUpperCase() + genero.slice(1);
    const colecaoNome = `genero_${genero}`;

    try {
      const firestoreData = await buscarTodosBlocos(colecaoNome);
      if (firestoreData && firestoreData.itens.length > 0) {
        console.log(`✅ Gênero ${nomeGenero} do Firestore: ${firestoreData.total} itens`);
        return res.json({
          fonte: 'firestore',
          genero: nomeGenero,
          slug: genero,
          total: firestoreData.total,
          atualizado_em: firestoreData.atualizado_em,
          resultados: firestoreData.itens
        });
      }
    } catch (error) {
      console.warn(`⚠️ Erro ao buscar gênero ${genero} do Firestore:`, error.message);
    }

    console.log(`🎭 Gênero ${nomeGenero} não encontrado no Firestore, fazendo streaming...`);
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    res.write(`{\n  "fonte": "scraping",\n  "genero": "${nomeGenero}",\n`);
    res.write(`  "slug": "${genero}",\n`);
    res.write(`  "status": "carregando",\n`);
    res.write(`  "total_paginas": ${totalPaginas},\n`);
    res.write(`  "resultados": [\n`);

    let primeiro = true;
    let totalItens = 0;
    const itensParaSalvar = [];

    console.log(`🎭 Iniciando streaming de ${nomeGenero} (${totalPaginas} páginas)`);

    for (let pagina = 1; pagina <= totalPaginas; pagina++) {
      const url = pagina === 1 ? `${URL_BASE}/genero/${genero}/` : `${URL_BASE}/genero/${genero}/page/${pagina}/`;
      console.log(`🎭 Buscando ${nomeGenero} página ${pagina}/${totalPaginas}`);

      try {
        const { data: html } = await axios.get(url, {
          headers: {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'pt-BR,pt;q=0.9',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'priority': 'u=0, i',
            'referer': `${URL_BASE}/`,
            'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
            ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
          },
          timeout: 15000,
          maxRedirects: 5,
          validateStatus: status => status < 500
        });

        const $ = cheerio.load(html);
        const itens = $('.default.poster.grid-item');

        if (itens.length === 0) {
          console.log(`⚠️ Nenhum item encontrado na página ${pagina} de ${nomeGenero}`);
          continue;
        }

        itens.each((i, el) => {
          const item = $(el);
          const linkElement = item.find('.poster__title a');
          const link = linkElement.attr('href') || '';
          const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
          const imgElement = item.find('.poster__img img');
          const imagem = imgElement.attr('src') || '';
          const ano = item.find('.bslide__meta span').first().text().trim() || '';
          let nota = 0;
          const notaElement = item.find('.bslide__meta .rating');
          if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
          const generos = [];
          item.find('.onslide-cats a').each((j, catEl) => {
            const generoCat = $(catEl).text().trim();
            if (generoCat && generoCat !== 'Filmes' && generoCat !== 'Séries' && generoCat !== nomeGenero) {
              generos.push(generoCat);
            }
          });
          let tipo = 'Filme';
          const ultimoGenero = item.find('.onslide-cats a').last().text().trim();
          if (ultimoGenero === 'Séries' || link.includes('/series/')) tipo = 'Série';
          else if (ultimoGenero === 'Animação' || link.includes('/genero/animacao/')) tipo = 'Animação';
          const resultado = { titulo, imagem, nota, ano, generos, tipo, link_assistir: link, pagina };
          itensParaSalvar.push(resultado);
          if (!primeiro) res.write(',\n');
          primeiro = false;
          res.write(JSON.stringify(resultado, null, 2));
          totalItens++;
        });

        res.write(`\n  // ✅ Página ${pagina}/${totalPaginas} carregada (${itens.length} itens)`);
        await new Promise(resolve => setTimeout(resolve, 150));
      } catch (err) {
        console.log(`❌ Erro página ${pagina} de ${nomeGenero}:`, err.message);
        res.write(`\n  // ⚠️ Erro na página ${pagina}: ${err.message}`);
        continue;
      }
    }

    if (itensParaSalvar.length > 0) {
      await salvarEmBlocos(colecaoNome, itensParaSalvar, 100);
    }

    res.write('\n  ],\n');
    res.write(`  "total_itens": ${totalItens},\n`);
    res.write(`  "paginas_processadas": ${totalPaginas},\n`);
    res.write(`  "status": "completo"\n`);
    res.write('}');
    res.end();

    console.log(`✅ Stream finalizado: ${totalItens} itens de ${nomeGenero} em ${totalPaginas} páginas`);
  } catch (error) {
    console.error(`❌ Erro no stream do gênero:`, error.message);
    if (!res.headersSent) {
      res.status(500).json({ erro: 'Erro ao processar stream', detalhe: error.message });
    } else {
      res.write('\n  // ❌ ERRO: ' + error.message + '\n');
      res.write('  }],\n  "status": "erro"\n}');
      res.end();
    }
  }
}

// ================================================================
// 🎭 ENDPOINT: /api/genero/:slug/page/:num
// ================================================================
app.get('/api/genero/:slug/page/:num', async (req, res) => {
  try {
    const { slug, num } = req.params;
    const pagina = parseInt(num) || 1;
    const url = pagina === 1 ? `${URL_BASE}/genero/${slug}/` : `${URL_BASE}/genero/${slug}/page/${pagina}/`;
    console.log(`🎭 Buscando gênero ${slug} - página ${pagina}`);
    const { data: html } = await axios.get(url, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'referer': `${URL_BASE}/`,
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
      },
      timeout: 15000
    });
    const $ = cheerio.load(html);
    const resultados = [];
    $('.default.poster.grid-item').each((i, el) => {
      const item = $(el);
      const linkElement = item.find('.poster__title a');
      const link = linkElement.attr('href') || '';
      const titulo = linkElement.find('span').text().trim() || linkElement.text().trim() || '';
      const imgElement = item.find('.poster__img img');
      const imagem = imgElement.attr('src') || '';
      const ano = item.find('.bslide__meta span').first().text().trim() || '';
      let nota = 0;
      const notaElement = item.find('.bslide__meta .rating');
      if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
      const generos = [];
      item.find('.onslide-cats a').each((j, catEl) => {
        const genero = $(catEl).text().trim();
        if (genero && genero !== 'Filmes' && genero !== 'Séries') generos.push(genero);
      });
      let tipo = 'Filme';
      const ultimoGenero = item.find('.onslide-cats a').last().text().trim();
      if (ultimoGenero === 'Séries' || link.includes('/series/')) tipo = 'Série';
      else if (ultimoGenero === 'Animação' || link.includes('/genero/animacao/')) tipo = 'Animação';
      if (titulo && link) {
        resultados.push({ titulo, imagem, nota, ano, generos, tipo, link_assistir: link });
      }
    });
    let totalPaginas = 1;
    const paginationLinks = $('.pagination .pagination__pages a');
    if (paginationLinks.length > 0) {
      const ultimoLink = paginationLinks.last();
      const ultimoNumero = parseInt(ultimoLink.text().trim());
      if (!isNaN(ultimoNumero) && ultimoNumero > totalPaginas) totalPaginas = ultimoNumero;
    }
    res.json({ genero: slug, total: resultados.length, total_paginas: totalPaginas, pagina_atual: pagina, resultados });
  } catch (error) {
    console.error(`❌ Erro ao buscar gênero página:`, error.message);
    res.status(500).json({ erro: 'Erro ao buscar gênero', detalhe: error.message });
  }
});

// ================================================================
// 🎬 ENDPOINT: /api/filme/:categoria/:slug
// ================================================================
app.get('/api/filme/:categoria/:slug', async (req, res) => {
  try {
    const { categoria, slug } = req.params;
    const url = `${URL_BASE}/${categoria}/${slug}`;
    console.log(`🎬 Buscando filme: ${categoria}/${slug}`);
    const { data: html } = await axios.get(url, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'pt-BR,pt;q=0.9',
        'cache-control': 'no-cache',
        'pragma': 'no-cache',
        'priority': 'u=0, i',
        'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Brave";v="150"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'sec-gpc': '1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',
        ...(COOKIE_STRING && { 'cookie': COOKIE_STRING })
      },
      timeout: 15000
    });
    const $ = cheerio.load(html);
    const titulo = $('.movieinfo h1').text().trim() || '';
    const imagem = $('.movieposter img').attr('src') || '';
    let nota = 0;
    const notaElement = $('.movieinfo .rating');
    if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
    const ano = $('.movieinfo .yearof').text().replace('Ano:', '').trim() || '';
    const descricao = $('.movie-description').text().trim() || '';
    let duracao = 0;
    const duracaoElement = $('.movieinfo .duration .tohr');
    if (duracaoElement.length) duracao = parseInt(duracaoElement.text().trim()) || 0;
    const diretores = [];
    $('.credits p:contains("Diretor(es)")').each((i, el) => {
      const text = $(el).text().replace('Diretor(es):', '').trim();
      diretores.push(text);
    });
    const atores = [];
    $('.credits p:contains("Atores") a').each((i, el) => {
      atores.push($(el).text().trim());
    });
    const generos = [];
    $('.onslide-cats a').each((i, el) => {
      const genero = $(el).text().trim();
      if (genero && genero !== 'Filmes') generos.push(genero);
    });
    const recomendados = [];
    $('.rec_wrap .default.poster.grid-item').each((i, el) => {
      const item = $(el);
      const link = item.find('.poster__title a').attr('href') || '';
      const tituloRec = item.find('.poster__title a span').text().trim() || '';
      const imagemRec = item.find('.poster__img img').attr('src') || '';
      const anoRec = item.find('.bslide__meta span').first().text().trim() || '';
      let notaRec = 0;
      const notaElementRec = item.find('.bslide__meta .rating');
      if (notaElementRec.length) notaRec = parseFloat(notaElementRec.text().trim()) || 0;
      recomendados.push({ titulo: tituloRec, imagem: imagemRec, nota: notaRec, ano: anoRec, link_assistir: link });
    });
    res.json({ titulo, imagem, nota, ano, duracao, descricao, diretores, atores, generos, tipo: 'Filme', categoria, slug, recomendados });
  } catch (error) {
    console.error('❌ Erro ao buscar filme:', error.message);
    res.status(500).json({ erro: 'Erro ao buscar filme', detalhe: error.message });
  }
});

// ================================================================
// 📺 ENDPOINT: /api/serie/:categoria/:slug/temporadas
// ================================================================
app.get('/api/serie/:categoria/:slug/temporadas', async (req, res) => {
  try {
    const { categoria, slug } = req.params;
    const url = `${URL_BASE}/${categoria}/${slug}`;
    
    console.log(`📺 Buscando temporadas: ${categoria}/${slug}`);
    
    const { data: html } = await axios.get(url, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Cookie': COOKIE_STRING || ''
      },
      timeout: 15000
    });

    const $ = cheerio.load(html);
    
    const titulo = $('.movieinfo h1').text().trim() || '';
    const temporadas = [];

    $('.seasons-v2 .season-link, .seasons .season-link').each((i, el) => {
      const link = $(el);
      const href = link.attr('href') || '';
      
      const seasonMatch = href.match(/--s(\d+)/);
      const numero = seasonMatch ? parseInt(seasonMatch[1]) : i + 1;
      
      const tituloTemp = link.find('.pstitle').text().trim() || `Temporada ${numero}`;
      
      const imagemStyle = link.find('.seasonimg').css('background-image') || '';
      const imagemMatch = imagemStyle.match(/url\(["']?([^"']*)["']?\)/);
      const imagem = imagemMatch ? imagemMatch[1] : '';
      
      temporadas.push({
        numero: numero,
        titulo: tituloTemp,
        imagem: imagem,
        link: href
      });
    });

    res.json({
      serie: titulo,
      categoria: categoria,
      slug: slug,
      total_temporadas: temporadas.length,
      temporadas: temporadas
    });

  } catch (error) {
    console.error('❌ Erro ao buscar temporadas:', error.message);
    res.status(500).json({ erro: 'Erro ao buscar temporadas', detalhe: error.message });
  }
});

// ================================================================
// 📺 ENDPOINT: /api/serie/:categoria/:slug/temporada/:num/episodios
// ================================================================
app.get('/api/serie/:categoria/:slug/temporada/:num/episodios', async (req, res) => {
  try {
    const { categoria, slug, num } = req.params;
    const temporadaNum = parseInt(num);
    const url = `${URL_BASE}/${categoria}/${slug}--s${temporadaNum}/`;
    
    console.log(`📺 Buscando episódios: ${categoria}/${slug} - Temporada ${temporadaNum}`);
    
    const { data: html } = await axios.get(url, {
      headers: {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Cookie': COOKIE_STRING || ''
      },
      timeout: 15000
    });

    const $ = cheerio.load(html);
    
    const tituloSerie = $('.movieinfo h1').text().trim() || '';
    const episodios = [];

    $('.seasoncontent .epi-link, .seasoncontent-v2 .epi-link').each((i, el) => {
      const ep = $(el);
      const href = ep.attr('href') || '';
      
      const epMatch = href.match(/--s\d+e(\d+)/);
      const numero = epMatch ? parseInt(epMatch[1]) : i + 1;
      
      const nome = ep.find('.epiname').text().trim() || `Episódio ${numero}`;
      const tituloEp = ep.find('.epinicename').text().trim() || '';
      
      const imagemStyle = ep.find('.epiframe').css('background-image') || '';
      const imagemMatch = imagemStyle.match(/url\(["']?([^"']*)["']?\)/);
      const imagem = imagemMatch ? imagemMatch[1] : '';
      
      const ativo = ep.hasClass('active');
      
      episodios.push({
        numero: numero,
        nome: nome,
        titulo: tituloEp,
        imagem: imagem,
        link: href,
        ativo: ativo
      });
    });

    episodios.sort((a, b) => a.numero - b.numero);

    res.json({
      serie: tituloSerie,
      categoria: categoria,
      slug: slug,
      temporada: temporadaNum,
      total_episodios: episodios.length,
      episodios: episodios
    });

  } catch (error) {
    console.error('❌ Erro ao buscar episódios:', error.message);
    res.status(500).json({ erro: 'Erro ao buscar episódios', detalhe: error.message });
  }
});

// ================================================================
// 🎬 ENDPOINT: /api/filme-player/:categoria/:slug
// ================================================================
// A origem usa PHPSESSID para autorizar a sequência página → JSON → M3U8.
// Axios não mantém cookies entre requisições por padrão; abrir três requests
// independentes fazia o JSON receber uma sessão inválida e devolver 401.
async function originGet(url, session, headers = {}, redirects = 0) {
  if (redirects > 4) throw new Error('Redirecionamentos demais na origem do vídeo');
  const response = await axios.get(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      ...headers,
      ...(session.cookie ? { Cookie: session.cookie } : {}),
    },
    maxRedirects: 0,
    validateStatus: (status) => status >= 200 && status < 400,
    timeout: 30000,
  });
  const setCookie = response.headers['set-cookie'];
  if (Array.isArray(setCookie) && setCookie.length) {
    session.cookie = setCookie.map((value) => value.split(';', 1)[0]).join('; ');
  }
  if (response.status >= 300 && response.status < 400 && response.headers.location) {
    return originGet(new URL(response.headers.location, url).toString(), session, headers, redirects + 1);
  }
  return response;
}

app.get('/api/filme-player/:categoria/:slug', async (req, res) => {
  try {
    const { categoria, slug } = req.params;
    // A origem assina o vídeo usando a URL canônica com barra final; sem ela,
    // lançamentos novos podem responder 401 mesmo quando filmes antigos funcionam.
    const episodeUrl = `${URL_BASE}/${categoria}/${slug}/`;
    const session = { cookie: COOKIE_STRING || '' };
    console.log(`🎬 Buscando player: ${episodeUrl}`);

    const pageResponse = await originGet(episodeUrl, session, {
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9',
    });
    const html = pageResponse.data;
    const itemIdMatch = html.match(/var itemId = "(\d+)";/);
    if (!itemIdMatch) throw new Error('itemId não encontrado');
    const itemId = itemIdMatch[1];
    console.log(`📌 itemId: ${itemId}`);

    const seasonMatch = slug.match(/--s(\d+)e(\d+)/i);
    const season = seasonMatch ? seasonMatch[1] : 1;
    const episode = seasonMatch ? seasonMatch[2] : 1;
    const jsonUrl = `${URL_BASE}/json?id=${itemId}&version=0&season=${season}&series=${episode}&a=true&android=0`;
    console.log(`📡 Buscando JSON: ${jsonUrl}`);

    const jsonResponse = await originGet(jsonUrl, session, {
      Accept: '*/*',
      Referer: episodeUrl,
    });
    const mediaPath = jsonResponse.data.video_url;
    if (!mediaPath) throw new Error('video_url não encontrado');

    const mediaUrl = mediaPath.startsWith('http') ? mediaPath : `${URL_BASE}${mediaPath}`;
    const mediaFormat = String(jsonResponse.data.video_format || '').toLowerCase();
    const isProgressive = /video\/(mp4|x-matroska|webm)/i.test(mediaFormat) || /\.(mp4|mkv|webm)(?:$|\?)/i.test(mediaPath);
    console.log(`📹 URL de mídia: ${mediaUrl} (${isProgressive ? 'progressiva' : 'HLS'})`);

    const mediaResponse = await axios.get(mediaUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        Accept: '*/*',
        Referer: episodeUrl,
        Origin: URL_BASE,
        ...(session.cookie ? { Cookie: session.cookie } : {}),
      },
      maxRedirects: 0,
      validateStatus: (status) => status >= 200 && status < 400,
      responseType: isProgressive ? 'stream' : 'text',
      timeout: 30000,
    });

    // Arquivos MP4/MKV são grandes e não devem ser baixados e devolvidos como
    // se fossem HLS. A origem fornece um URL CDN assinado via 307; repasse-o
    // para o ExoPlayer, que suporta Range e streaming progressivo.
    if (isProgressive && mediaResponse.status >= 300 && mediaResponse.status < 400 && mediaResponse.headers.location) {
      res.setHeader('Cache-Control', 'no-store');
      return res.redirect(307, new URL(mediaResponse.headers.location, mediaUrl).toString());
    }

    if (isProgressive) {
      res.setHeader('Content-Type', mediaResponse.headers['content-type'] || 'video/mp4');
      res.setHeader('Accept-Ranges', 'bytes');
      return mediaResponse.data.pipe(res);
    }

    const manifestResponse = mediaResponse.data;
    if (typeof manifestResponse !== 'string' || !manifestResponse.includes('#EXTM3U')) {
      throw new Error('A origem não retornou uma playlist HLS válida');
    }
    res.setHeader('Content-Type', 'application/vnd.apple.mpegurl');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'no-cache');
    res.send(manifestResponse);
    console.log(`✅ M3U8 retornado!`);
  } catch (error) {
    console.error('❌ Erro:', error.message);
    res.status(502).json({ success: false, erro: `Origem do vídeo indisponível: ${error.message}` });
  }
});

// ================================================================
// 🎬 ENDPOINT: /api/filme-info/:categoria/:slug
// ================================================================
app.get('/api/filme-info/:categoria/:slug', async (req, res) => {
  try {
    const { categoria, slug } = req.params;
    const filmeUrl = `${URL_BASE}/${categoria}/${slug}/`;
    console.log(`🎬 Buscando info do filme: ${filmeUrl}`);
    const { data: html } = await axios.get(filmeUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
        'Cookie': COOKIE_STRING || ''
      },
      timeout: 15000
    });
    const $ = cheerio.load(html);
    const titulo = $('.movieinfo h1').text().trim() || '';
    const imagem = $('.movieposter img').attr('src') || '';
    let nota = 0;
    const notaElement = $('.movieinfo .rating');
    if (notaElement.length) nota = parseFloat(notaElement.text().trim()) || 0;
    const ano = $('.movieinfo .yearof').text().replace('Ano:', '').trim() || '';
    const descricao = $('.movie-description').text().trim() || '';
    let duracao = 0;
    const duracaoElement = $('.movieinfo .duration .tohr');
    if (duracaoElement.length) duracao = parseInt(duracaoElement.text().trim()) || 0;
    const itemIdMatch = html.match(/var itemId = "(\d+)";/);
    const itemId = itemIdMatch ? itemIdMatch[1] : null;
    let m3u8Url = null;
    if (itemId) {
      try {
        const jsonUrl = `${URL_BASE}/json?id=${itemId}&version=0&season=1&series=1&a=true&android=0`;
        const { data: jsonData } = await axios.get(jsonUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': '*/*',
            'Referer': filmeUrl,
            'Cookie': COOKIE_STRING || ''
          },
          timeout: 15000
        });
        const path = jsonData.video_url;
        if (path) m3u8Url = path.startsWith('http') ? path : `${URL_BASE}${path}`;
      } catch (e) {
        console.warn('⚠️ Não foi possível obter M3U8:', e.message);
      }
    }
    res.json({ titulo, imagem, nota, ano, duracao, descricao, categoria, slug, item_id: itemId, m3u8_url: m3u8Url, player_url: filmeUrl });
  } catch (error) {
    console.error('❌ Erro ao buscar info do filme:', error.message);
    res.status(500).json({ erro: error.message });
  }
});

// ================================================================
//  ENDPOINT: HISTÓRICO - SALVAR PROGRESSO (COM userId DO TOKEN)
// ================================================================
app.post('/api/history/save-progress', async (req, res) => {
  try {
    const userId = req.user.userId; // 🔥 PEGA DO TOKEN
    const { filmeId, titulo, tempo, thumb } = req.body;

    if (!filmeId) {
      return res.status(400).json({
        success: false,
        message: 'filmeId é obrigatório'
      });
    }

    const historyId = `${userId}_${filmeId}`;

    const historyData = {
      userId: userId,
      filmeId,
      titulo: titulo || 'Sem título',
      tempo: tempo || '00:00:00',
      thumb: thumb || '',
      ultimoAcesso: new Date(),
      atualizadoEm: new Date()
    };

    await db.collection(COLLECTIONS.HISTORICO).doc(historyId).set(historyData, { merge: true });

    return res.status(200).json({
      success: true,
      message: 'Progresso salvo com sucesso'
    });

  } catch (error) {
    console.error('❌ Erro em /api/history/save-progress:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// ================================================================
// HISTÓRICO — CONTINUE WATCHING
// ================================================================
// TEDFLIX — ENDPOINTS DE CONTINUE WATCHING
// Cole este bloco depois de inicializar `app`, `db`, `authMiddleware` e `COLLECTIONS`.
// Não mistura esta coleção com favoritos.

const crypto = require('node:crypto');

const CONTINUE_WATCHING_COLLECTION = COLLECTIONS.HISTORICO;

function numberOrZero(value) {
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? Math.floor(number) : 0;
}

function nullableNumber(value) {
  if (value === undefined || value === null || value === '') return null;
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? Math.floor(number) : null;
}

function text(value, maxLength = 2000) {
  return String(value ?? '').trim().slice(0, maxLength);
}

function contentKey({ filmeId, categoria, slug, tipo, temporada, episodio }) {
  // Episódios diferentes nunca sobrescrevem uns aos outros.
  const raw = [
    text(filmeId, 120),
    text(categoria, 120),
    text(slug, 300),
    text(tipo, 40),
    temporada ?? '',
    episodio ?? '',
  ].join('|');
  return crypto.createHash('sha256').update(raw).digest('hex').slice(0, 40);
}

// Salva ou atualiza automaticamente o progresso do conteúdo atual.
app.post('/api/history/continue-watching', async (req, res) => {
  try {
    const userId = text(req.user?.userId, 200);
    if (!userId) {
      return res.status(401).json({ success: false, message: 'Usuário não autenticado' });
    }

    const body = req.body || {};
    const filmeId = text(body.filmeId || body.id, 120);
    if (!filmeId) {
      return res.status(400).json({ success: false, message: 'filmeId é obrigatório' });
    }

    const categoria = text(body.categoria, 120);
    const slug = text(body.slug, 300);
    const tipo = text(body.tipo || 'filme', 40);
    const temporada = nullableNumber(body.temporada);
    const episodio = nullableNumber(body.episodio);
    const tempo = numberOrZero(body.tempo ?? body.posicao ?? body.position);
    const duracaoTotal = numberOrZero(body.duracaoTotal ?? body.duracao ?? body.duration);
    const progresso = duracaoTotal > 0
      ? Math.min(100, Math.floor((tempo / duracaoTotal) * 100))
      : numberOrZero(body.progresso);
    const agora = Date.now();
    const id = `${userId}_${contentKey({ filmeId, categoria, slug, tipo, temporada, episodio })}`;

    const registro = {
      userId,
      filmeId,
      titulo: text(body.titulo || body.nome, 300),
      thumb: text(body.thumb || body.imagem || body.capa, 2000),
      imagem: text(body.imagem || body.thumb || body.capa, 2000),
      linkAssistir: text(body.linkAssistir || body.link_assistir, 2000),
      link_assistir: text(body.link_assistir || body.linkAssistir, 2000),
      categoria,
      slug,
      tipo,
      serieCategoria: text(body.serieCategoria, 120),
      serieSlug: text(body.serieSlug, 300),
      temporada,
      episodio,
      tituloEpisodio: text(body.tituloEpisodio, 300),
      tempo,
      duracaoTotal,
      progresso,
      tempoFormatado: text(body.tempoFormatado, 40),
      assistido: Boolean(body.assistido) || (duracaoTotal > 0 && tempo >= duracaoTotal * 0.95),
      ultimoAcesso: agora,
      atualizadoEm: agora,
    };

    await db.collection(CONTINUE_WATCHING_COLLECTION).doc(id).set(registro, { merge: true });

    return res.status(200).json({
      success: true,
      mensagem: 'Progresso registrado',
      continuarAssistindo: registro,
    });
  } catch (error) {
    console.error('Erro em POST /api/history/continue-watching:', error.message);
    return res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Lista somente o histórico do usuário autenticado.
// Não usa orderBy no Firestore, portanto não exige índice composto.
app.get('/api/history/continue-watching', async (req, res) => {
  try {
    const userId = text(req.user?.userId, 200);
    if (!userId) {
      return res.status(401).json({ success: false, message: 'Usuário não autenticado' });
    }

    const limiteSolicitado = Number.parseInt(req.query.limite, 10);
    const limite = Number.isFinite(limiteSolicitado)
      ? Math.min(50, Math.max(1, limiteSolicitado))
      : 20;

    const snapshot = await db.collection(CONTINUE_WATCHING_COLLECTION)
      .where('userId', '==', userId)
      .get();

    const continuarAssistindo = snapshot.docs
      .map((doc) => ({ id: doc.id, ...doc.data() }))
      .filter((item) => item.filmeId)
      .sort((a, b) => Number(b.ultimoAcesso || b.atualizadoEm || 0) - Number(a.ultimoAcesso || a.atualizadoEm || 0))
      .slice(0, limite);

    return res.status(200).json({
      success: true,
      continuarAssistindo,
    });
  } catch (error) {
    console.error('Erro em GET /api/history/continue-watching:', error.message);
    return res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// ================================================================
//  ENDPOINT: FAVORITOS - TOGGLE (COM userId DO TOKEN)
// ================================================================
app.post('/api/favorites/toggle', async (req, res) => {
  try {
    const userId = req.user.userId; // 🔥 PEGA DO TOKEN
    const { filmeId, titulo, thumb } = req.body;

    if (!filmeId) {
      return res.status(400).json({
        success: false,
        message: 'filmeId é obrigatório'
      });
    }

    const favoritoId = `${userId}_${filmeId}`;
    const favoritoDoc = await db.collection(COLLECTIONS.FAVORITOS).doc(favoritoId).get();

    if (favoritoDoc.exists) {
      await favoritoDoc.ref.delete();
      return res.status(200).json({
        success: true,
        message: 'Removido dos favoritos',
        favorited: false
      });
    } else {
      await db.collection(COLLECTIONS.FAVORITOS).doc(favoritoId).set({
        userId: userId,
        filmeId,
        titulo: titulo || 'Sem título',
        thumb: thumb || '',
        adicionadoEm: new Date()
      });

      return res.status(200).json({
        success: true,
        message: 'Adicionado aos favoritos',
        favorited: true
      });
    }

  } catch (error) {
    console.error('❌ Erro em /api/favorites/toggle:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// ================================================================
//  ENDPOINT: FAVORITOS - LISTAR (COM userId DO TOKEN)
// ================================================================
app.get('/api/favorites/list', async (req, res) => {
  try {
    const userId = req.user.userId; // 🔥 PEGA DO TOKEN

    const favoritesQuery = await db.collection(COLLECTIONS.FAVORITOS)
      .where('userId', '==', userId)
      .orderBy('adicionadoEm', 'desc')
      .get();

    const favoritos = [];
    favoritesQuery.forEach(doc => {
      const data = doc.data();
      favoritos.push({
        filmeId: data.filmeId,
        titulo: data.titulo,
        thumb: data.thumb,
        adicionadoEm: data.adicionadoEm
      });
    });

    return res.status(200).json({
      success: true,
      favoritos
    });

  } catch (error) {
    console.error('❌ Erro em /api/favorites/list:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// ================================================================
// 🚀 INICIA O SERVIDOR
// ================================================================
app.listen(PORT, () => {
  const now = new Date().toLocaleString("pt-BR");
  console.log("======================================");
  console.log("🚀 Servidor iniciado com sucesso");
  console.log(`🕒 Inicializado em: ${now}`);
  console.log(`🌐 Porta: ${PORT}`);
  console.log(`📺 URL Base: ${URL_BASE}`);
  console.log("✅ Firestore integrado nos endpoints de STREAM");
  console.log("🔒 TODAS AS ROTAS PROTEGIDAS COM BEARER TOKEN");
  console.log("======================================");
});
