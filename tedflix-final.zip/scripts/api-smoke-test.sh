#!/usr/bin/env bash
# Smoke test das 3 APIs oficiais do TEDFLIX
set -euo pipefail

CONTENT="https://servidores-ted-auth-1.onrender.com/api"
USER="https://servidores-ted-auth.onrender.com"
TEDTOP="https://servidores-ted-apply2.onrender.com"

ok=0; fail=0
check() {
  local name="$1" url="$2" expect="$3"
  code=$(curl -s -o /tmp/tedflix_probe.json -w "%{http_code}" --max-time 30 "$url" || echo ERR)
  if [[ "$code" == "$expect" ]]; then
    echo "OK  $code  $name"
    ok=$((ok+1))
  else
    echo "FAIL $code (esperado $expect)  $name  $url"
    fail=$((fail+1))
  fi
}

echo "=== CONTENT ==="
check "home/carousel"        "$CONTENT/home/carousel" 200
check "home/lancamentos"     "$CONTENT/home/lancamentos" 200
check "home/ultimos-filmes"  "$CONTENT/home/ultimos-filmes" 200
check "filmes/stream"        "$CONTENT/filmes/stream" 200
check "series/stream"        "$CONTENT/series/stream" 200
check "genero/acao/stream"   "$CONTENT/genero/acao/stream" 200
check "buscar/matrix"        "$CONTENT/buscar/matrix" 200

echo "=== USER (sem token = 401) ==="
check "auth/me"              "$USER/api/auth/me" 401
check "profiles"             "$USER/api/profiles" 401

echo "=== TEDTOP ==="
check "telao"                "$TEDTOP/telao" 200
check "filme/o-fim-da-rua"   "$TEDTOP/filme/o-fim-da-rua" 200
check "ingresso/o-fim-da-rua" "$TEDTOP/ingresso/o-fim-da-rua" 200
check "bilheteria"           "$TEDTOP/bilheteria" 200

echo ""
echo "Resultado: $ok ok, $fail falhas"
[[ "$fail" -eq 0 ]]
