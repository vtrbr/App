import { el } from "../dom.js";
import { hero } from "../components/hero.js";
import { fileira } from "../components/row.js";
import {
  getCarousel,
  getUltimosFilmes,
  buscar,
  parseLink,
  getLancamentos,
  getSeries,
  getGenero,
  getTedtopTelao,
  getTedtopBilheteria,
} from "../api.js";
import { CATEGORIAS } from "../config.js";

/**
 * Home estilo Netflix:
 * 1. Hero / destaques
 * 2. Continuar assistindo (destaque)
 * 3. Em cartaz / Bilheteria (TEDTOP)
 * 4. Lançamentos, séries, gêneros (CONTENT)
 */
export default async function paginaInicio(raiz) {
  const page = el("div", { class: "page home-netflix" });
  const topo = el("div", { class: "hero skel" });
  page.append(topo);
  raiz.append(page);

  // Continuar assistindo — prioridade Netflix (logo abaixo do hero)
  const continuar = await carregarContinuarAssistindo();
  if (continuar.length) {
    page.append(
      fileira({
        titulo: "Continuar assistindo",
        carregar: async () => continuar,
        limite: 20,
        variante: "continuar",
      }),
    );
  }

  // TEDTOP — Em cartaz / bilheteria (segunda API visível na home)
  page.append(
    fileira({
      titulo: "Em cartaz",
      carregar: async () => { const d = await getTedtopTelao(1); return d.itens || []; },
      limite: 18,
      variante: "tedtop",
    }),
    fileira({
      titulo: "Bilheteria",
      carregar: async () => normalizarTedtop(await getTedtopBilheteria()),
      limite: 18,
      variante: "tedtop",
    }),
  );

  // CONTENT — catálogo principal
  page.append(
    fileira({ titulo: "Últimos filmes", carregar: getUltimosFilmes, limite: 24 }),
    fileira({
      titulo: "Lançamentos",
      verTudo: "#/categoria/lancamentos",
      carregar: getLancamentos,
      limite: 24,
    }),
    fileira({
      titulo: "Séries",
      verTudo: "#/series",
      carregar: async () => (await getSeries()).slice(0, 24),
      limite: 24,
    }),
  );

  CATEGORIAS.slice(0, 6).forEach((c) => {
    page.append(
      fileira({
        titulo: c.label,
        verTudo: `#/categoria/${c.slug}`,
        carregar: async () => (await getGenero(c.slug)).slice(0, 24),
        limite: 24,
      }),
    );
  });

  try {
    const destaques = await getCarousel();
    const h = hero(destaques);
    topo.replaceWith(h);
    page.destruir = () => h.destruir?.();
  } catch (e) {
    topo.classList.remove("skel");
    topo.append(el("div", { class: "center" }, "Não foi possível carregar os destaques."));
  }

  return page;
}

/** Normaliza itens TEDTOP para o card (slug + imagem https + rota de detalhe). */
function normalizarTedtop(lista) {
  const itens = Array.isArray(lista) ? lista : [];
  return itens
    .map((item) => {
      const slug = String(item.slug || "").trim();
      let imagem = String(item.imagem || item.thumb || item.poster || "").trim();
      if (imagem.startsWith("//")) imagem = `https:${imagem}`;
      const categoria = String(item.categoria || "destaque").trim() || "destaque";
      return {
        ...item,
        titulo: item.titulo || slug,
        slug,
        categoria,
        imagem,
        tipo: item.tipo || "Filme",
        ano: item.ano || "",
        link_assistir: item.link_assistir || `#/titulo/filme/${categoria}/${slug}`,
        origem: "tedtop",
        badgeExtra: item.trailer || item.tem_trailer ? "Trailer" : null,
      };
    })
    .filter((i) => i.slug || i.titulo);
}

async function carregarContinuarAssistindo() {
  try {
    if (!window.AndroidPlayer?.getContinueWatching) return [];

    const lerSnapshot = () => {
      try {
        const valor = JSON.parse(window.AndroidPlayer.getContinueWatching() || "[]");
        return Array.isArray(valor) ? valor : [];
      } catch (_) {
        return [];
      }
    };

    const localSnapshot = lerSnapshot();
    let itens = localSnapshot;
    if (window.AndroidPlayer.refreshContinueWatching) {
      await new Promise((resolve) => {
        let finalizado = false;
        const concluir = () => {
          if (finalizado) return;
          finalizado = true;
          window.__tedflixHistoryReady = null;
          resolve();
        };
        window.__tedflixHistoryReady = concluir;
        try {
          window.AndroidPlayer.refreshContinueWatching();
        } catch (_) {
          concluir();
        }
        setTimeout(concluir, 2500);
      });
      const remotoMesclado = lerSnapshot();
      if (remotoMesclado.length) itens = remotoMesclado;
    }

    if (!itens.length) return [];

    const cards = await Promise.all(
      itens
        .filter((item) => item && (item.categoria || item.slug || item.titulo || item.filmeId))
        .slice(0, 20)
        .map(async (item) => {
          let categoria = String(item.categoria || "").trim();
          let slug = String(item.slug || "").trim();
          let detalhe = null;

          if ((!categoria || !slug) && (item.titulo || item.filmeId)) {
            try {
              const busca = await buscar(item.titulo || item.filmeId);
              const resultados = Array.isArray(busca?.resultados) ? busca.resultados : [];
              const id = String(item.filmeId || "").trim();
              const titulo = String(item.titulo || "").trim().toLowerCase();
              const encontrado =
                resultados.find((candidato) => {
                  const candidatoId = String(
                    candidato.filmeId || candidato.id || candidato._id || "",
                  ).trim();
                  return (
                    (id && candidatoId === id) ||
                    (titulo &&
                      String(candidato.titulo || "").trim().toLowerCase() === titulo)
                  );
                }) || resultados[0];
              if (encontrado) {
                const partes = parseLink(encontrado.link_assistir);
                categoria = categoria || encontrado.categoria || partes.categoria;
                slug = slug || encontrado.slug || partes.slug;
                detalhe = encontrado;
              }
            } catch (_) {
              /* mantém o que temos */
            }
          }

          const percent = Number(item.percent || item.progresso || 0);
          const pos = Number(item.positionMs || 0);
          const dur = Number(item.durationMs || 0);
          const progresso =
            percent > 0
              ? percent
              : dur > 0
                ? Math.min(99, Math.round((pos * 100) / dur))
                : 0;

          const titulo = item.titulo || detalhe?.titulo || slug || "Continuar";
          const imagem =
            item.thumb || item.imagem || detalhe?.imagem || detalhe?.thumb || "";

          return {
            titulo,
            imagem,
            categoria: categoria || "filme",
            slug: slug || String(item.filmeId || "").trim(),
            filmeId: item.filmeId || slug,
            tipo: item.tipo || detalhe?.tipo || "Filme",
            progresso,
            continuarTexto: progresso > 0 ? `${progresso}% assistido` : "Continuar",
            link_assistir:
              categoria && slug
                ? `#/titulo/filme/${categoria}/${slug}`
                : item.link_assistir || "#/",
            serieCategoria: item.serieCategoria || "",
            serieSlug: item.serieSlug || "",
          };
        }),
    );

    return cards.filter((c) => c && (c.slug || c.filmeId));
  } catch (_) {
    return [];
  }
}
