import { el, limpar } from "../dom.js";
import { cardTitulo, skeletonCard } from "../components/card.js";
import { buscar, parseLink } from "../api.js";

/**
 * Favoritos como seção do app (SPA) — não abre Activity nativa.
 */
export default async function paginaFavoritos(raiz) {
  const page = el("div", { class: "page page-favoritos" });
  page.append(
    el("h1", { class: "page-title pad" }, "Minha lista"),
    el("p", { class: "sub pad", style: "padding-top:0" }, "Títulos que você marcou como favorito"),
  );
  const grid = el("div", { class: "grid pad", style: "margin-top:12px" });
  for (let i = 0; i < 6; i++) grid.append(skeletonCard());
  page.append(grid);
  raiz.append(page);

  try {
    if (!window.AndroidPlayer?.getFavorites) {
      limpar(grid);
      grid.append(el("p", { class: "sub" }, "Favoritos disponíveis apenas no app."));
      return page;
    }
    const raw = JSON.parse(window.AndroidPlayer.getFavorites() || "{}");
    const lista = Array.isArray(raw.favoritos) ? raw.favoritos : Array.isArray(raw) ? raw : [];
    if (!lista.length) {
      limpar(grid);
      grid.append(
        el("div", { class: "empty-state" }, [
          el("p", { class: "sub" }, "Sua lista está vazia."),
          el("a", { class: "btn primary", href: "#/" }, "Explorar catálogo"),
        ]),
      );
      return page;
    }

    // Resolve rota de detalhe em paralelo (slug/categoria via busca quando faltar)
    const cards = await Promise.all(
      lista.map(async (item) => {
        const titulo = String(item.titulo || "").trim();
        const filmeId = String(item.filmeId || item.id || "").trim();
        let categoria = String(item.categoria || "").trim();
        let slug = String(item.slug || "").trim();
        let imagem = String(item.thumb || item.imagem || "").trim();
        let tipo = String(item.tipo || item.contentType || "Filme");

        if ((!categoria || !slug) && (titulo || filmeId)) {
          try {
            const busca = await buscar(titulo || filmeId);
            const resultados = Array.isArray(busca?.resultados) ? busca.resultados : [];
            const hit =
              resultados.find((r) => {
                const id = String(r.filmeId || r.id || "").trim();
                return (filmeId && id === filmeId) ||
                  (titulo && String(r.titulo || "").toLowerCase() === titulo.toLowerCase());
              }) || resultados[0];
            if (hit) {
              const p = parseLink(hit.link_assistir);
              categoria = categoria || hit.categoria || p.categoria;
              slug = slug || hit.slug || p.slug;
              imagem = imagem || hit.imagem || hit.thumb || "";
              tipo = hit.tipo || tipo;
            }
          } catch (_) {}
        }

        const href =
          categoria && slug
            ? `#/titulo/${/sér|serie/i.test(tipo) ? "serie" : "filme"}/${categoria}/${slug}`
            : titulo
              ? `#/favorito?titulo=${encodeURIComponent(titulo)}`
              : "#/";

        return {
          titulo: titulo || slug || "Favorito",
          imagem,
          categoria,
          slug,
          tipo,
          filmeId,
          link_assistir: href,
        };
      }),
    );

    limpar(grid);
    const frag = document.createDocumentFragment();
    cards.forEach((c) => frag.append(cardTitulo(c, { size: "md", eager: true })));
    grid.append(frag);
  } catch (e) {
    limpar(grid);
    grid.append(el("p", { class: "sub" }, "Não foi possível carregar os favoritos."));
  }

  return page;
}
