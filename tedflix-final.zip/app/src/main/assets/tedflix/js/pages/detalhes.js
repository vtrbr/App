import { el, svgIcone, limpar, anoCurto } from "../dom.js";
import { getTitulo, getTemporadas, getEpisodios, parseLink, getTedtopFilme, extrairYoutubeId } from "../api.js";
import { backdrop, poster } from "../img.js";
import { cardTitulo } from "../components/card.js";

/** Monta o bloco do trailer YouTube (TEDTOP) — ou null se indisponível. */
function blocoTrailer(trailerUrl) {
  const videoId = extrairYoutubeId(trailerUrl);
  if (!videoId) return null;

  const wrap = el("div", { class: "trailer-wrap", style: "margin-top:20px;position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:12px;background:#111" });
  const iframe = el("iframe", {
    src: `https://www.youtube.com/embed/${videoId}?rel=0&modestbranding=1`,
    title: "Trailer",
    frameborder: "0",
    allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
    allowfullscreen: "true",
    style: "position:absolute;top:0;left:0;width:100%;height:100%;border:0",
    loading: "lazy",
  });
  wrap.append(iframe);
  return el("section", { class: "section trailer-section" }, [
    el("div", { class: "section-head" }, [el("h2", {}, "Trailer")]),
    wrap,
  ]);
}

export default async function paginaDetalhe(raiz, { tipo, categoria, slug }) {
  const page = el("div", { class: "page" });
  raiz.append(page);
  // Shell imediato: hero skeleton (não espera a API para pintar algo na tela)
  const shellHero = el("div", { class: "detail-hero skel detail-hero-shell" });
  page.append(shellHero);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let dados;
  let tedtop = null;
  try {
    // CONTENT principal; TEDTOP complementar. Se CONTENT falhar, usa TEDTOP.
    const [contentResult, ted] = await Promise.all([
      getTitulo(categoria, slug, tipo).then((d) => ({ ok: true, d })).catch((e) => ({ ok: false, e })),
      getTedtopFilme(slug).catch(() => null),
    ]);
    tedtop = ted;
    if (contentResult.ok) {
      dados = contentResult.d;
    } else if (ted) {
      dados = {
        titulo: ted.titulo || slug,
        imagem: (ted.imagem || "").startsWith("//") ? `https:${ted.imagem}` : (ted.imagem || ""),
        ano: ted.ano || "",
        duracao: ted.duracao || "",
        descricao: ted.sinopse || ted.descricao || "",
        generos: ted.genero ? [ted.genero] : [],
        tipo: tipo === "serie" ? "Série" : "Filme",
        categoria,
        slug,
        recomendados: (ted.recomendados || []).map((r) => ({
          ...r,
          imagem: (r.imagem || "").startsWith("//") ? `https:${r.imagem}` : r.imagem,
          link_assistir: r.link_assistir || `#/titulo/filme/destaque/${r.slug || ""}`,
        })),
      };
    } else {
      throw contentResult.e || new Error("título indisponível");
    }
    // Enriquece capa/sinopse com TEDTOP quando CONTENT veio sem
    if (ted) {
      if (!dados.imagem && ted.imagem) {
        dados.imagem = String(ted.imagem).startsWith("//") ? `https:${ted.imagem}` : ted.imagem;
      }
      if (!dados.descricao && (ted.sinopse || ted.descricao)) {
        dados.descricao = ted.sinopse || ted.descricao;
      }
    }
  } catch (e) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Não foi possível carregar este título."));
    return page;
  }

  limpar(page);

  const voltar = el("button", {
    class: "back",
    "aria-label": "Voltar",
    html: `<svg viewBox="0 0 24 24">${{ back: "" }.back || ""}</svg>`,
    onclick: () => history.back(),
  });
  voltar.innerHTML = svgIcone("back");

  // Banner: começa em resolução média (mais rápido) e sobe se a rede aguentar
  const capaSrc = dados.imagem || dados.thumb || dados.poster || "";
  const capaImg = capaSrc
    ? el("img", {
        src: backdrop(capaSrc, 500) || poster(capaSrc, "lg"),
        alt: dados.titulo || "",
        fetchpriority: "high",
        decoding: "async",
        class: "detail-hero-img",
      })
    : null;
  if (capaImg && capaSrc) {
    // Se o banner falhar, usa a capa/pôster no lugar (não deixa hero vazio)
    let usouCapa = false;
    capaImg.addEventListener("error", () => {
      if (usouCapa) return;
      usouCapa = true;
      const fallback = poster(capaSrc, "lg") || poster(capaSrc, "md") || capaSrc;
      if (fallback && fallback !== capaImg.src) capaImg.src = fallback;
    }, { once: true });
    // Upgrade suave para 780 só em conexão boa (não bloqueia a UI)
    const upgrade = () => {
      try {
        const hi = backdrop(capaSrc, 780);
        if (hi && hi !== capaImg.src && !usouCapa) {
          const pre = new Image();
          pre.onload = () => { if (!usouCapa) capaImg.src = hi; };
          pre.onerror = () => {};
          pre.src = hi;
        }
      } catch (_) {}
    };
    if (capaImg.complete && capaImg.naturalWidth) upgrade();
    else capaImg.addEventListener("load", upgrade, { once: true });
  }
  const capa = el("div", { class: "detail-hero" }, [
    capaImg,
    el("div", { class: "veil" }),
    voltar,
  ]);

  const fatos = [
    dados.nota ? `★ ${Number(dados.nota).toFixed(1)}` : null,
    anoCurto(dados.ano),
    dados.tipo,
    dados.duracao ? `${dados.duracao} min` : null,
    ...(dados.generos || []).slice(0, 3),
  ].filter(Boolean);

  const filmeId = String(dados.filmeId || dados.id || dados._id || dados.tmdb_id || slug);
  const thumb = String(dados.imagem || dados.thumb || "");
  let favorito = lerFavorito(filmeId, slug, categoria);
  const favoritoBtn = el("button", { class: `btn ghost favorito-btn${favorito ? " ativo" : ""}`, type: "button" }, favorito ? "♥ Favorito" : "♡ Favoritar");
  favoritoBtn.addEventListener("click", () => {
    try {
      const contentType = tipo === "serie" ? "series" : (tipo === "episodio" ? "episode" : "movie");
      const resposta = JSON.parse(window.AndroidPlayer?.toggleFavorite?.(filmeId, dados.titulo || "Tedflix", thumb, contentType) || "{}");
      if (!resposta.success) throw new Error(resposta.error || "Não foi possível atualizar o favorito.");
      favorito = typeof resposta.favorito === "boolean" ? resposta.favorito : !favorito;
      favoritoBtn.textContent = favorito ? "♥ Favorito" : "♡ Favoritar";
      favoritoBtn.classList.toggle("ativo", favorito);
    } catch (e) {
      favoritoBtn.textContent = e.message || "Erro ao salvar";
      setTimeout(() => { favoritoBtn.textContent = favorito ? "♥ Favorito" : "♡ Favoritar"; }, 1800);
    }
  });

  const acao = el("div", { style: "display:flex;gap:10px;margin-top:14px;flex-wrap:wrap" }, [favoritoBtn]);
  if (tipo !== "serie") {
    const params = new URLSearchParams({ filmeId, thumb, tipo: dados.tipo || tipo || "filme" });
    const recomendados = (dados.recomendados || []).map(dadosParaPlayer).filter(Boolean);
    if (recomendados.length) params.set("recomendados", JSON.stringify(recomendados));
    acao.prepend(
      el("a", {
        class: "btn primary",
        href: `#/assistir/${categoria}/${slug}?${params.toString()}`,
        html: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>Assistir',
      }),
    );
  }

  const corpo = el("div", { class: "detail-body" }, [
    el("h1", {}, dados.titulo || ""),
    el("div", { class: "facts" }, fatos.map((f) => el("span", {}, f))),
    acao,
    dados.descricao ? el("p", { class: "desc" }, dados.descricao) : null,
  ]);

  page.append(capa, corpo);

  // Trailer TEDTOP (não quebra a tela se falhar ou estiver ausente)
  const trailerUrl = (tedtop && tedtop.trailer) || dados.trailer || null;
  const trailerEl = blocoTrailer(trailerUrl);
  if (trailerEl) page.append(trailerEl);

  if (tipo === "serie") page.append(await blocoTemporadas(categoria, slug, thumb));

  if ((dados.recomendados || []).length) {
    const rail = el("div", { class: "rail" });
    dados.recomendados.slice(0, 20).forEach((r) => rail.append(cardTitulo(r)));
    page.append(
      el("section", { class: "section" }, [
        el("div", { class: "section-head" }, [el("h2", {}, "Recomendados")]),
        rail,
      ]),
    );
  }

  return page;
}

async function blocoTemporadas(categoria, slug, serieThumb = "") {
  // O mapa é por episódio (categoria:slug), não por série inteira.
  // A ponte Android retorna os registros locais já mesclados com o histórico remoto.
  const progresso = lerProgressoLocal();
  const bloco = el("section", { class: "section" });
  const chips = el("div", { class: "chips" });
  const lista = el("div", {});
  bloco.append(
    el("div", { class: "section-head" }, [el("h2", {}, "Episódios")]),
    chips,
    lista,
  );

  let temporadas = [];
  try {
    temporadas = await getTemporadas(categoria, slug);
  } catch (e) {
    bloco.append(el("p", { class: "center" }, "Temporadas indisponíveis."));
    return bloco;
  }
  if (!temporadas.length) {
    lista.append(el("p", { class: "center" }, "Nenhuma temporada encontrada."));
    return bloco;
  }

  const dadosEpisodio = (ep, temporada = "") => {
    const p = parseLink(ep.link || ep.link_assistir);
    const cat = ep.categoria || p.categoria || categoria;
    const sl = ep.slug || p.slug;
    if (!sl) return null;
    return {
      categoria: cat,
      slug: sl,
      filmeId: String(ep.filmeId || ep.id || ep._id || sl),
      thumb: ep.imagem || serieThumb,
      titulo: `${ep.numero ? `${ep.numero}. ` : ""}${ep.titulo || "Episódio"}`,
      duracao: ep.duracao || "",
      temporada: String(temporada || ""),
      tipo: "episodio",
      serieCategoria: categoria,
      serieSlug: slug,
    };
  };

  let todosEpisodiosPromise = null;
  const obterTodosEpisodios = () => {
    if (!todosEpisodiosPromise) {
      todosEpisodiosPromise = Promise.all(temporadas.map(async (temporada) => {
        const episodios = await getEpisodios(categoria, slug, temporada.numero);
        return episodios.map((ep) => dadosEpisodio(ep, temporada.numero)).filter(Boolean);
      })).then((grupos) => grupos.flat());
    }
    return todosEpisodiosPromise;
  };

  const rotaAssistir = (info, fila = [], todos = []) => {
    const queryParams = new URLSearchParams({
      filmeId: info.filmeId || info.slug,
      thumb: info.thumb || serieThumb,
      tipo: "episodio",
      serieCategoria: categoria,
      serieSlug: slug,
    });
    if (fila.length) queryParams.set("fila", JSON.stringify(fila));
    if (todos.length) queryParams.set("episodios", JSON.stringify(todos));
    return `#/assistir/${info.categoria}/${info.slug}?${queryParams.toString()}`;
  };

  async function carregar(num) {
    limpar(lista);
    lista.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));
    try {
      const eps = await getEpisodios(categoria, slug, num);
      limpar(lista);
      if (!eps.length) {
        lista.append(el("p", { class: "center" }, "Sem episódios nesta temporada."));
        return;
      }
      const frag = document.createDocumentFragment();
      const episodiosDaTemporada = eps.map((ep) => dadosEpisodio(ep, num)).filter(Boolean);
      eps.forEach((ep, index) => {
        const info = episodiosDaTemporada[index];
        const filaDaTemporada = episodiosDaTemporada.slice(index + 1);
        const link = el("a", { class: "ep", href: info ? rotaAssistir(info, filaDaTemporada) : "#" }, [
            el("div", { class: "cap" }, [
              ep.imagem
                ? el("img", {
                    src: poster(ep.imagem, "sm"),
                    alt: ep.titulo || "",
                    loading: "lazy",
                    decoding: "async",
                  })
                : null,
            ]),
            el("div", { style: "min-width:0" }, [
              el("p", { class: "t" }, `${ep.numero ? `${ep.numero}. ` : ""}${ep.titulo || "Episódio"}`),
              el("p", { class: "d" }, ep.duracao || ""),
              info && progresso.get(`${info.categoria}:${info.slug}`) ? el("div", { class: "ep-progress" }, [
                el("span", { style: `width:${progresso.get(`${info.categoria}:${info.slug}`)}%` }),
              ]) : null,
            ]),
          ]);
        if (info) {
          link.addEventListener("click", async (evento) => {
            evento.preventDefault();
            let todos = episodiosDaTemporada;
            try { todos = await obterTodosEpisodios(); } catch (_) {}
            const atual = todos.findIndex((item) => item.categoria === info.categoria && item.slug === info.slug);
            const fila = atual >= 0 ? todos.slice(atual + 1) : filaDaTemporada;
            location.hash = rotaAssistir(info, fila, todos);
          });
        }
        frag.append(link);
      });
      lista.append(frag);
    } catch (e) {
      limpar(lista);
      lista.append(el("p", { class: "center" }, "Não foi possível carregar os episódios."));
    }
  }

  temporadas.forEach((t, i) => {
    const b = el("button", { class: `chip${i === 0 ? " on" : ""}` }, t.titulo || `T${t.numero}`);
    b.addEventListener("click", () => {
      [...chips.children].forEach((c) => c.classList.remove("on"));
      b.classList.add("on");
      carregar(t.numero);
    });
    chips.append(b);
  });

  carregar(temporadas[0].numero);
  return bloco;
}

function dadosParaPlayer(item) {
  const rota = parseLink(item?.link || item?.link_assistir);
  const categoria = String(item?.categoria || rota.categoria || "").trim();
  const slug = String(item?.slug || rota.slug || "").trim();
  if (!categoria || !slug) return null;
  return {
    categoria,
    slug,
    filmeId: String(item?.filmeId || item?.id || item?._id || slug),
    thumb: String(item?.imagem || item?.thumb || ""),
    titulo: String(item?.titulo || "Recomendado"),
    tipo: String(item?.tipo || "filme"),
  };
}

function lerFavorito(filmeId, slug = "", categoria = "") {
  try {
    const resposta = JSON.parse(window.AndroidPlayer?.getFavorites?.() || "{}");
    const lista = resposta.favoritos || resposta.favorites || [];
    if (!Array.isArray(lista)) return false;
    const id = String(filmeId || "").trim();
    const s = String(slug || "").trim().toLowerCase();
    const c = String(categoria || "").trim().toLowerCase();
    return lista.some((item) => {
      const iid = String(item.filmeId || item.contentId || item.id || "").trim();
      const is = String(item.slug || "").trim().toLowerCase();
      const ic = String(item.categoria || "").trim().toLowerCase();
      if (id && iid && id === iid) return true;
      if (s && is && s === is && (!c || !ic || c === ic)) return true;
      return false;
    });
  } catch (_) {
    return false;
  }
}

function lerProgressoLocal() {
  const mapa = new Map();
  try {
    const itens = JSON.parse(window.AndroidPlayer?.getContinueWatching?.() || "[]");
    (Array.isArray(itens) ? itens : []).forEach((item) => {
      if (item?.categoria && item?.slug) mapa.set(`${item.categoria}:${item.slug}`, Number(item.percent || 0));
    });
  } catch (_) {}
  return mapa;
}
