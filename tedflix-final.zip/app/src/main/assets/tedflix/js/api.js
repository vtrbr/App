import { API_BASE, TEDTOP_API_BASE, LIVE_API_BASE } from "./config.js";

/* Cache em memória + deduplicação de requisições.
   Os endpoints "/stream" devolvem o catálogo inteiro (megabytes), então
   nunca são baixados duas vezes na mesma sessão. */
const cache = new Map();
const emVoo = new Map();

const TTL_CURTO = 5 * 60 * 1000;
const TTL_LONGO = 30 * 60 * 1000;
const CACHE_PREFIX = "tedflix:catalog-cache:v2:";

/** Limpa cache de catálogo (memória + localStorage) para forçar dados frescos. */
export function limparCacheCatalogo() {
  cache.clear();
  try {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(CACHE_PREFIX)) keys.push(k);
    }
    keys.forEach((k) => localStorage.removeItem(k));
  } catch (_) {}
}

const CACHE_MAX_BYTES = 1_800_000;

function lerCachePersistente(chave) {
  try {
    const item = JSON.parse(localStorage.getItem(CACHE_PREFIX + chave) || "null");
    return item && item.t && item.v !== undefined ? item : null;
  } catch (_) { return null; }
}

function salvarCachePersistente(chave, valor) {
  try {
    const texto = JSON.stringify({ t: Date.now(), v: valor });
    if (texto.length <= CACHE_MAX_BYTES) localStorage.setItem(CACHE_PREFIX + chave, texto);
  } catch (_) { /* quota cheia: o cache em memória continua válido */ }
}

async function getJSON(caminho, ttl = TTL_CURTO, base = API_BASE) {
  const chave = `${base}${caminho}`;
  const agora = Date.now();
  const guardado = cache.get(chave);
  if (guardado && agora - guardado.t < ttl) return guardado.v;
  const persistido = lerCachePersistente(chave);
  if (persistido && agora - persistido.t < ttl) {
    cache.set(chave, persistido);
    return persistido.v;
  }
  if (emVoo.has(chave)) return emVoo.get(chave);

  const p = fetch(`${base}${caminho}`)
    .then((r) => {
      if (!r.ok) throw new Error(`Falha ao carregar (${r.status})`);
      return r.json();
    })
    .then((v) => {
      cache.set(chave, { t: Date.now(), v });
      salvarCachePersistente(chave, v);
      emVoo.delete(chave);
      return v;
    })
    .catch((e) => {
      emVoo.delete(chave);
      if (persistido?.v !== undefined) return persistido.v;
      throw e;
    });

  emVoo.set(chave, p);
  return p;
}

/** O scraper às vezes duplica o título ("XyzXyz") — limpa isso. */
export function limparTitulo(t) {
  const s = (t || "").trim();
  if (!s) return "";
  const meio = s.length / 2;
  if (s.length % 2 === 0 && s.slice(0, meio) === s.slice(meio)) return s.slice(0, meio);
  return s.replace(/^Assistir\s+/i, "").replace(/\s+Online Grátis$/i, "");
}

export function normalizar(item, tipoPadrao) {
  const tipo = item.tipo || tipoPadrao;
  return { ...item, titulo: limparTitulo(item.titulo), ...(tipo ? { tipo } : {}) };
}

export function parseLink(link) {
  if (!link) return { categoria: "", slug: "" };
  const partes = link.replace(/^https?:\/\/[^/]+/, "").split("/").filter(Boolean);
  return { categoria: partes[partes.length - 2] || "", slug: partes[partes.length - 1] || "" };
}

export function ehSerie(item) {
  const t = (item.tipo || "").toLowerCase();
  return t.includes("séri") || t.includes("serie");
}

/** Rota de detalhes de um item da API. */
export function rotaDetalhe(item) {
  // Alguns itens reconstruídos do histórico usam uma rota hash de fallback.
  // Respeite-a diretamente em vez de tentar interpretá-la como link de CDN.
  if (typeof item.link_assistir === "string" && item.link_assistir.startsWith("#/")) {
    return item.link_assistir;
  }
  const p = parseLink(item.link_assistir);
  const episodioDeSerie = Boolean(item.serieSlug || item.serieCategoria);
  const tipo = ehSerie(item) || episodioDeSerie ? "serie" : "filme";
  const categoria = episodioDeSerie ? item.serieCategoria : (item.categoria || p.categoria);
  const slug = episodioDeSerie ? item.serieSlug : (item.slug || p.slug);
  return `#/titulo/${tipo}/${categoria}/${slug}`;
}

/* ---------------- HOME ---------------- */

export const getCarousel = () =>
  getJSON("/home/carousel", TTL_LONGO).then((d) => (d.itens || []).map((i) => normalizar(i)));

export const getUltimosFilmes = async () => {
  try {
    const d = await getJSON("/home/ultimos-filmes", TTL_CURTO);
    const filmes = Array.isArray(d.filmes) ? d.filmes : Array.isArray(d.resultados) ? d.resultados : [];
    if (filmes.length) return filmes.map((i) => normalizar(i, "Filme"));
  } catch (_) {
    // Não baixar o catálogo inteiro (/filmes/stream) como fallback — é lento e pesado.
  }
  try {
    const d = await getJSON("/home/lancamentos", TTL_CURTO);
    const itens = d.lancamentos || d.filmes || d.resultados || d.itens || [];
    return (Array.isArray(itens) ? itens : []).slice(0, 30).map((i) => normalizar(i, "Filme"));
  } catch (_) {
    return [];
  }
};

export const getAgenda = () => getJSON("/home/agenda").then((d) => d.dias || []);

/* ---------------- CATÁLOGOS ---------------- */

export const getFilmes = () =>
  getJSON("/filmes/stream", TTL_LONGO).then((d) => (d.filmes || []).map((i) => normalizar(i, "Filme")));

export const getSeries = () =>
  getJSON("/series/stream", TTL_LONGO).then((d) => (d.series || []).map((i) => normalizar(i, "Série")));

export const getAnimacoes = () =>
  getJSON("/animacoes/stream", TTL_LONGO).then((d) =>
    (d.animacoes || d.resultados || []).map((i) => normalizar(i, "Filme")),
  );

export const getGenero = (slug) => {
  if (slug === "animacao") return getAnimacoes();
  return getJSON(`/genero/${slug}/stream`, TTL_LONGO).then((d) =>
    (d.resultados || []).map((i) => normalizar(i, "Filme")),
  );
};

/** Lançamentos oficiais da Home, retornados pelo endpoint dedicado. */
export const getLancamentos = () =>
  getJSON("/home/lancamentos", TTL_LONGO).then((d) => {
    const itens = d.lancamentos || d.filmes || d.resultados || d.itens || [];
    return (Array.isArray(itens) ? itens : []).map((item) => normalizar(item));
  });

/* ---------------- BUSCA ---------------- */

export const buscar = (q, pagina = 1) =>
  getJSON(`/buscar/${encodeURIComponent(q)}?pagina=${pagina}`).then((d) => ({
    resultados: (d.resultados || []).map((i) => normalizar(i)),
    totalPaginas: d.total_paginas || 1,
  }));

/* ---------------- DETALHES ---------------- */

export const getTitulo = async (categoria, slug, tipo = "filme") => {
  if (String(tipo).toLowerCase().includes("séri") || String(tipo).toLowerCase().includes("serie")) {
    // CONTENT é a autoridade de séries/temporadas. Busca é complementar.
    const [temporadas, busca] = await Promise.all([
      getJSON(`/series/serie/${categoria}/${slug}/temporadas`, TTL_LONGO),
      buscar(slug).catch(() => ({ resultados: [] })),
    ]);
    const item =
      (busca.resultados || []).find((i) => String(i.link_assistir || "").includes(`/${slug}`)) ||
      (busca.resultados || []).find((i) => String(i.slug || "") === String(slug)) ||
      busca.resultados?.[0] ||
      {};
    return {
      ...item,
      titulo: limparTitulo(item.titulo || temporadas.serie || slug),
      categoria: temporadas.categoria || categoria,
      slug: temporadas.slug || slug,
      tipo: "Série",
      imagem: item.imagem || item.thumb || "",
      temporadas: temporadas.temporadas || [],
      total_temporadas: temporadas.total_temporadas || (temporadas.temporadas || []).length,
      recomendados: (item.recomendados || []).map((i) => normalizar(i)),
    };
  }
  return getJSON(`/filmes/filme/${categoria}/${slug}`, TTL_LONGO).then((d) => ({
    ...d,
    titulo: limparTitulo(d.titulo),
    categoria: d.categoria || categoria,
    slug: d.slug || slug,
    recomendados: (d.recomendados || []).map((i) => normalizar(i)),
  }));
};

export const getTemporadas = (categoria, slug) =>
  getJSON(`/series/serie/${categoria}/${slug}/temporadas`, TTL_LONGO).then((d) => d.temporadas || []);

export const getEpisodios = (categoria, slug, numero) =>
  getJSON(`/series/serie/${categoria}/${slug}/temporada/${numero}/episodios`, TTL_LONGO).then(
    (d) => d.episodios || [],
  );

/* ---------------- PLAYER (CONTENT API) ---------------- */

/** Texto puro do manifest .m3u8 (reprodução direta pelo CDN). */
export async function getManifesto(categoria, slug) {
  const r = await fetch(`${API_BASE}/filmes/filme-player/${categoria}/${slug}`);
  if (!r.ok) throw new Error("Este título está indisponível no momento.");
  const texto = await r.text();
  if (!texto.includes("#EXTM3U")) throw new Error("Fonte de vídeo inválida.");
  return texto;
}

/* ============================================================
   TEDTOP API — conteúdo complementar, trailers, ingresso
   Todas as rotas são públicas (sem autenticação).
   ============================================================ */

/** Extrai o videoId de uma URL de YouTube (vários formatos). */
export function extrairYoutubeId(url) {
  if (!url || typeof url !== "string") return null;
  const s = url.trim();
  // //www.youtube.com/watch?v=ID  |  https://www.youtube.com/watch?v=ID&t=10s
  // https://youtu.be/ID  |  https://www.youtube.com/embed/ID
  const m =
    s.match(/[?&]v=([^&#]+)/) ||
    s.match(/youtu\.be\/([^?&#]+)/) ||
    s.match(/youtube\.com\/embed\/([^?&#]+)/) ||
    s.match(/youtube\.com\/shorts\/([^?&#]+)/);
  return m ? m[1] : null;
}


/* ---------------- TEDTOP API (pública, sem auth) ---------------- */

/** Normaliza item TEDTOP para o card/detalhe interno. */
export function normalizarTedtopItem(item = {}) {
  let imagem = String(item.imagem || item.thumb || item.poster || "").trim();
  if (imagem.startsWith("//")) imagem = "https:" + imagem;
  const slug = String(item.slug || "").trim();
  const categoria = String(item.categoria || "destaque").trim() || "destaque";
  return {
    ...item,
    titulo: item.titulo || slug,
    slug,
    categoria,
    imagem,
    ano: item.ano || "",
    nota: item.nota != null ? Number(item.nota) : undefined,
    tipo: item.tipo || "Filme",
    genero: item.genero || item.genero_nome || "",
    link_assistir: item.link_assistir || `#/titulo/filme/${categoria}/${slug}`,
    origem: "tedtop",
  };
}

function listaTedtop(d) {
  const arr = d?.filmes || d?.destaques || d?.resultados || d?.itens || d?.data || [];
  return (Array.isArray(arr) ? arr : []).map(normalizarTedtopItem);
}

/** Telão / destaques */
export const getTedtopTelao = (pagina = 1) =>
  getJSON(`/telao?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Bilheteria */
export const getTedtopBilheteria = () =>
  getJSON(`/bilheteria`, TTL_LONGO, TEDTOP_API_BASE).then((d) => listaTedtop(d));

/** Por ano — GET /sessao/ano/:ano (não filtrar localmente) */
export const getTedtopPorAno = (ano, pagina = 1) =>
  getJSON(`/sessao/ano/${encodeURIComponent(ano)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    ano: d.ano || ano,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Por letra — GET /alfabeto/:letra (não usar /buscar) */
export const getTedtopPorLetra = (letra, pagina = 1) => {
  const L = String(letra || "A").toUpperCase().slice(0, 1);
  return getJSON(`/alfabeto/${encodeURIComponent(L)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    letra: d.letra || L,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));
};

/** Por gênero TEDTOP — GET /generos/:genero */
export const getTedtopPorGenero = (genero, pagina = 1) =>
  getJSON(`/generos/${encodeURIComponent(genero)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    genero: d.genero || genero,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Radar ao vivo — GET /radar/live/:termo */
export const getTedtopRadar = (termo) =>
  getJSON(`/radar/live/${encodeURIComponent(termo)}`, TTL_CURTO, TEDTOP_API_BASE).then((d) => {
    // API pode devolver string anti-leecher ou lista
    if (typeof d.resultados === "string") {
      return { termo: d.termo || termo, itens: [], aviso: d.resultados };
    }
    return { termo: d.termo || termo, itens: listaTedtop(d) };
  });

/** Detalhes TEDTOP — GET /filme/:slug */
export async function getTedtopFilme(slug) {
  if (!slug) return null;
  try {
    const d = await getJSON(`/filme/${encodeURIComponent(slug)}`, TTL_LONGO, TEDTOP_API_BASE);
    if (!d) return null;
    return normalizarTedtopItem({
      ...d,
      descricao: d.sinopse || d.descricao || "",
      trailer: d.trailer || "",
      recomendados: (d.recomendados || []).map(normalizarTedtopItem),
    });
  } catch (_) {
    return null;
  }
}

/**
 * Link direto TEDTOP (pode expirar). Não persistir.
 * GET /ingresso/:slug
 */
export async function getTedtopIngresso(slug) {
  if (!slug) return null;
  try {
    return await getJSON(`/ingresso/${encodeURIComponent(slug)}`, 5 * 60 * 1000, TEDTOP_API_BASE);
  } catch (_) {
    return null;
  }
}


export function normalizarCanal(item = {}) {
  const embeds = (Array.isArray(item.embeds) ? item.embeds : [])
    .map((embed) => ({
      provider: String(embed?.provider || "Servidor"),
      quality: String(embed?.quality || "Automático"),
      embed_url: String(embed?.embed_url || ""),
    }))
    .filter((embed) => urlHttpValida(embed.embed_url));
  return {
    id: String(item.id || ""),
    titulo: String(item.name || item.title || "Canal ao vivo"),
    descricao: String(item.description || ""),
    logo: String(item.logo_url || item.logo || ""),
    categoria: String(item.category || "Outros"),
    embeds,
    epg: item.epg || {},
    aoVivo: true,
  };
}

export const getCanais = (categoria = "") => {
  const caminho = categoria ? `/channels?category=${encodeURIComponent(categoria)}` : "/channels";
  return getJSON(caminho, TTL_CURTO, LIVE_API_BASE).then((d) =>
    (Array.isArray(d.data) ? d.data : []).map(normalizarCanal),
  );
};

export const getCanalCategorias = () =>
  getJSON("/channels/categories", TTL_LONGO, LIVE_API_BASE).then((d) =>
    (Array.isArray(d.data) ? d.data : []).map((item) => ({
      id: String(item.id || ""),
      nome: String(item.name || "Outros"),
    })),
  );

export const getCanal = (id) =>
  getJSON(`/channels/${encodeURIComponent(id)}`, TTL_CURTO, LIVE_API_BASE).then((d) =>
    normalizarCanal(d.data && !Array.isArray(d.data) ? d.data : d.channel || d),
  );

export const getEventosAoVivo = () =>
  getJSON("/sports?status=live", TTL_CURTO, LIVE_API_BASE).then((d) =>
    (Array.isArray(d.data) ? d.data : []).map((item) => ({
      ...item,
      id: String(item.id || ""),
      titulo: String(item.title || "Evento ao vivo"),
      descricao: String(item.description || ""),
      logo: String(item.poster || ""),
      categoria: String(item.category || "Esportes"),
      embeds: (Array.isArray(item.embeds) ? item.embeds : [])
        .map((embed) => ({
          provider: String(embed?.provider || "Servidor"),
          quality: String(embed?.quality || "Automático"),
          embed_url: String(embed?.embed_url || ""),
        }))
        .filter((embed) => urlHttpValida(embed.embed_url)),
      aoVivo: true,
    })),
  );

export const buscarCanais = (q) =>
  getJSON(`/channels?search=${encodeURIComponent(q)}`, TTL_CURTO, LIVE_API_BASE).then((d) =>
    (Array.isArray(d.data) ? d.data : []).map(normalizarCanal),
  );
