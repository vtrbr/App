import { API_BASE, TEDTOP_API_BASE, LIVE_API_BASE } from "./config.js";

/* Cache em memória + deduplicação de requisições.
   Os endpoints "/stream" devolvem o catálogo inteiro (megabytes), então
   nunca são baixados duas vezes na mesma sessão. */
const cache = new Map();
const emVoo = new Map();

const TTL_CURTO = 5 * 60 * 1000;
const TTL_LONGO = 30 * 60 * 1000;
const CACHE_PREFIX = "tedflix:catalog-cache:v2:";

/** Limpa cache de catálogo (memória + localStorage) para forçar dados frescos. */
export function limparCacheCatalogo() {
  cache.clear();
  try {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(CACHE_PREFIX)) keys.push(k);
    }
    keys.forEach((k) => localStorage.removeItem(k));
  } catch (_) {}
}

const CACHE_MAX_BYTES = 1_800_000;

function lerCachePersistente(chave) {
  try {
    const item = JSON.parse(localStorage.getItem(CACHE_PREFIX + chave) || "null");
    return item && item.t && item.v !== undefined ? item : null;
  } catch (_) { return null; }
}

function salvarCachePersistente(chave, valor) {
  try {
    const texto = JSON.stringify({ t: Date.now(), v: valor });
    if (texto.length <= CACHE_MAX_BYTES) localStorage.setItem(CACHE_PREFIX + chave, texto);
  } catch (_) { /* quota cheia: o cache em memória continua válido */ }
}

async function getJSON(caminho, ttl = TTL_CURTO, base = API_BASE) {
  const chave = `${base}${caminho}`;
  const agora = Date.now();
  const guardado = cache.get(chave);
  if (guardado && agora - guardado.t < ttl) return guardado.v;
  const persistido = lerCachePersistente(chave);
  if (persistido && agora - persistido.t < ttl) {
    cache.set(chave, persistido);
    return persistido.v;
  }
  if (emVoo.has(chave)) return emVoo.get(chave);

  const isLive = base === LIVE_API_BASE || String(base || "").includes("reidoscanais");

  const p = (async () => {
    try {
      let v;
      if (isLive && window.AndroidPlayer?.fetchLive) {
        // Proxy nativo: Cloudflare/CORS não bloqueia o OkHttp do app
        const raw = window.AndroidPlayer.fetchLive(caminho);
        v = typeof raw === "string" ? JSON.parse(raw) : raw;
        if (v && v.success === false && v.error && !v.data) {
          throw new Error(v.error || "Falha na API de canais");
        }
      } else {
        const r = await fetch(`${base}${caminho}`);
        if (!r.ok) throw new Error(`Falha ao carregar (${r.status})`);
        v = await r.json();
      }
      cache.set(chave, { t: Date.now(), v });
      salvarCachePersistente(chave, v);
      return v;
    } catch (e) {
      if (persistido?.v !== undefined) return persistido.v;
      throw e;
    } finally {
      emVoo.delete(chave);
    }
  })();

  emVoo.set(chave, p);
  return p;
}

/** O scraper às vezes duplica o título ("XyzXyz") — limpa isso. */
export function limparTitulo(t) {
  const s = (t || "").trim();
  if (!s) return "";
  const meio = s.length / 2;
  if (s.length % 2 === 0 && s.slice(0, meio) === s.slice(meio)) return s.slice(0, meio);
  return s.replace(/^Assistir\s+/i, "").replace(/\s+Online Grátis$/i, "");
}

export function normalizar(item, tipoPadrao) {
  const tipo = item.tipo || tipoPadrao;
  return { ...item, titulo: limparTitulo(item.titulo), ...(tipo ? { tipo } : {}) };
}

export function parseLink(link) {
  if (!link) return { categoria: "", slug: "" };
  const partes = link.replace(/^https?:\/\/[^/]+/, "").split("/").filter(Boolean);
  return { categoria: partes[partes.length - 2] || "", slug: partes[partes.length - 1] || "" };
}

export function ehSerie(item) {
  const t = (item.tipo || "").toLowerCase();
  return t.includes("séri") || t.includes("serie");
}

/** Rota de detalhes de um item da API. */
export function rotaDetalhe(item) {
  // Alguns itens reconstruídos do histórico usam uma rota hash de fallback.
  // Respeite-a diretamente em vez de tentar interpretá-la como link de CDN.
  if (typeof item.link_assistir === "string" && item.link_assistir.startsWith("#/")) {
    return item.link_assistir;
  }
  const p = parseLink(item.link_assistir);
  const episodioDeSerie = Boolean(item.serieSlug || item.serieCategoria);
  const tipo = ehSerie(item) || episodioDeSerie ? "serie" : "filme";
  const categoria = episodioDeSerie ? item.serieCategoria : (item.categoria || p.categoria);
  const slug = episodioDeSerie ? item.serieSlug : (item.slug || p.slug);
  return `#/titulo/${tipo}/${categoria}/${slug}`;
}

/* ---------------- HOME ---------------- */

export const getCarousel = () =>
  getJSON("/home/carousel", TTL_LONGO).then((d) => (d.itens || []).map((i) => normalizar(i)));

export const getUltimosFilmes = async () => {
  try {
    const d = await getJSON("/home/ultimos-filmes", TTL_CURTO);
    const filmes = Array.isArray(d.filmes) ? d.filmes : Array.isArray(d.resultados) ? d.resultados : [];
    if (filmes.length) return filmes.map((i) => normalizar(i, "Filme"));
  } catch (_) {
    // Não baixar o catálogo inteiro (/filmes/stream) como fallback — é lento e pesado.
  }
  try {
    const d = await getJSON("/home/lancamentos", TTL_CURTO);
    const itens = d.lancamentos || d.filmes || d.resultados || d.itens || [];
    return (Array.isArray(itens) ? itens : []).slice(0, 30).map((i) => normalizar(i, "Filme"));
  } catch (_) {
    return [];
  }
};

export const getAgenda = () => getJSON("/home/agenda").then((d) => d.dias || []);

/* ---------------- CATÁLOGOS ---------------- */

export const getFilmes = () =>
  getJSON("/filmes/stream", TTL_LONGO).then((d) => (d.filmes || []).map((i) => normalizar(i, "Filme")));

export const getSeries = () =>
  getJSON("/series/stream", TTL_LONGO).then((d) => (d.series || []).map((i) => normalizar(i, "Série")));

export const getAnimacoes = () =>
  getJSON("/animacoes/stream", TTL_LONGO).then((d) =>
    (d.animacoes || d.resultados || []).map((i) => normalizar(i, "Filme")),
  );

export const getGenero = (slug) => {
  if (slug === "animacao") return getAnimacoes();
  return getJSON(`/genero/${slug}/stream`, TTL_LONGO).then((d) =>
    (d.resultados || []).map((i) => normalizar(i, "Filme")),
  );
};

/** Lançamentos oficiais da Home, retornados pelo endpoint dedicado. */
export const getLancamentos = () =>
  getJSON("/home/lancamentos", TTL_LONGO).then((d) => {
    const itens = d.lancamentos || d.filmes || d.resultados || d.itens || [];
    return (Array.isArray(itens) ? itens : []).map((item) => normalizar(item));
  });

/* ---------------- BUSCA ---------------- */

export const buscar = (q, pagina = 1) =>
  getJSON(`/buscar/${encodeURIComponent(q)}?pagina=${pagina}`).then((d) => ({
    resultados: (d.resultados || []).map((i) => normalizar(i)),
    totalPaginas: d.total_paginas || 1,
  }));

/* ---------------- DETALHES ---------------- */

export const getTitulo = async (categoria, slug, tipo = "filme") => {
  if (String(tipo).toLowerCase().includes("séri") || String(tipo).toLowerCase().includes("serie")) {
    // CONTENT é a autoridade de séries/temporadas. Busca é complementar.
    const [temporadas, busca] = await Promise.all([
      getJSON(`/series/serie/${categoria}/${slug}/temporadas`, TTL_LONGO),
      buscar(slug).catch(() => ({ resultados: [] })),
    ]);
    const item =
      (busca.resultados || []).find((i) => String(i.link_assistir || "").includes(`/${slug}`)) ||
      (busca.resultados || []).find((i) => String(i.slug || "") === String(slug)) ||
      busca.resultados?.[0] ||
      {};
    return {
      ...item,
      titulo: limparTitulo(item.titulo || temporadas.serie || slug),
      categoria: temporadas.categoria || categoria,
      slug: temporadas.slug || slug,
      tipo: "Série",
      imagem: item.imagem || item.thumb || "",
      temporadas: temporadas.temporadas || [],
      total_temporadas: temporadas.total_temporadas || (temporadas.temporadas || []).length,
      recomendados: (item.recomendados || []).map((i) => normalizar(i)),
    };
  }
  return getJSON(`/filmes/filme/${categoria}/${slug}`, TTL_LONGO).then((d) => ({
    ...d,
    titulo: limparTitulo(d.titulo),
    categoria: d.categoria || categoria,
    slug: d.slug || slug,
    recomendados: (d.recomendados || []).map((i) => normalizar(i)),
  }));
};

export const getTemporadas = (categoria, slug) =>
  getJSON(`/series/serie/${categoria}/${slug}/temporadas`, TTL_LONGO).then((d) => d.temporadas || []);

export const getEpisodios = (categoria, slug, numero) =>
  getJSON(`/series/serie/${categoria}/${slug}/temporada/${numero}/episodios`, TTL_LONGO).then(
    (d) => d.episodios || [],
  );

/* ---------------- PLAYER (CONTENT API) ---------------- */

/** Texto puro do manifest .m3u8 (reprodução direta pelo CDN). */
export async function getManifesto(categoria, slug) {
  const r = await fetch(`${API_BASE}/filmes/filme-player/${categoria}/${slug}`);
  if (!r.ok) throw new Error("Este título está indisponível no momento.");
  const texto = await r.text();
  if (!texto.includes("#EXTM3U")) throw new Error("Fonte de vídeo inválida.");
  return texto;
}

/* ============================================================
   TEDTOP API — conteúdo complementar, trailers, ingresso
   Todas as rotas são públicas (sem autenticação).
   ============================================================ */

/** Extrai o videoId de uma URL de YouTube (vários formatos). */
export function extrairYoutubeId(url) {
  if (!url || typeof url !== "string") return null;
  const s = url.trim();
  // //www.youtube.com/watch?v=ID  |  https://www.youtube.com/watch?v=ID&t=10s
  // https://youtu.be/ID  |  https://www.youtube.com/embed/ID
  const m =
    s.match(/[?&]v=([^&#]+)/) ||
    s.match(/youtu\.be\/([^?&#]+)/) ||
    s.match(/youtube\.com\/embed\/([^?&#]+)/) ||
    s.match(/youtube\.com\/shorts\/([^?&#]+)/);
  return m ? m[1] : null;
}


/* ---------------- TEDTOP API (pública, sem auth) ---------------- */

/** Normaliza item TEDTOP para o card/detalhe interno. */
export function normalizarTedtopItem(item = {}) {
  let imagem = String(item.imagem || item.thumb || item.poster || "").trim();
  if (imagem.startsWith("//")) imagem = "https:" + imagem;
  const slug = String(item.slug || "").trim();
  const categoria = String(item.categoria || "destaque").trim() || "destaque";
  return {
    ...item,
    titulo: item.titulo || slug,
    slug,
    categoria,
    imagem,
    ano: item.ano || "",
    nota: item.nota != null ? Number(item.nota) : undefined,
    tipo: item.tipo || "Filme",
    genero: item.genero || item.genero_nome || "",
    link_assistir: item.link_assistir || `#/titulo/filme/${categoria}/${slug}`,
    origem: "tedtop",
  };
}

function listaTedtop(d) {
  const arr = d?.filmes || d?.destaques || d?.resultados || d?.itens || d?.data || [];
  return (Array.isArray(arr) ? arr : []).map(normalizarTedtopItem);
}

/** Telão / destaques */
export const getTedtopTelao = (pagina = 1) =>
  getJSON(`/telao?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Bilheteria */
export const getTedtopBilheteria = () =>
  getJSON(`/bilheteria`, TTL_LONGO, TEDTOP_API_BASE).then((d) => listaTedtop(d));

/** Por ano — GET /sessao/ano/:ano (não filtrar localmente) */
export const getTedtopPorAno = (ano, pagina = 1) =>
  getJSON(`/sessao/ano/${encodeURIComponent(ano)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    ano: d.ano || ano,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Por letra — GET /alfabeto/:letra (não usar /buscar) */
export const getTedtopPorLetra = (letra, pagina = 1) => {
  const L = String(letra || "A").toUpperCase().slice(0, 1);
  return getJSON(`/alfabeto/${encodeURIComponent(L)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    letra: d.letra || L,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));
};

/** Por gênero TEDTOP — GET /generos/:genero */
export const getTedtopPorGenero = (genero, pagina = 1) =>
  getJSON(`/generos/${encodeURIComponent(genero)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    genero: d.genero || genero,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Radar ao vivo — GET /radar/live/:termo */
export const getTedtopRadar = (termo) =>
  getJSON(`/radar/live/${encodeURIComponent(termo)}`, TTL_CURTO, TEDTOP_API_BASE).then((d) => {
    // API pode devolver string anti-leecher ou lista
    if (typeof d.resultados === "string") {
      return { termo: d.termo || termo, itens: [], aviso: d.resultados };
    }
    return { termo: d.termo || termo, itens: listaTedtop(d) };
  });

/** Detalhes TEDTOP — GET /filme/:slug */
export async function getTedtopFilme(slug) {
  if (!slug) return null;
  try {
    const d = await getJSON(`/filme/${encodeURIComponent(slug)}`, TTL_LONGO, TEDTOP_API_BASE);
    if (!d) return null;
    return normalizarTedtopItem({
      ...d,
      descricao: d.sinopse || d.descricao || "",
      trailer: d.trailer || "",
      recomendados: (d.recomendados || []).map(normalizarTedtopItem),
    });
  } catch (_) {
    return null;
  }
}

/**
 * Link direto TEDTOP (pode expirar). Não persistir.
 * GET /ingresso/:slug
 */
export async function getTedtopIngresso(slug) {
  if (!slug) return null;
  try {
    return await getJSON(`/ingresso/${encodeURIComponent(slug)}`, 5 * 60 * 1000, TEDTOP_API_BASE);
  } catch (_) {
    return null;
  }
}



/* ---------------- CANAIS AO VIVO — Rei dos Canais API v2 ----------------
 * Base: https://api.reidoscanais.st
 * Docs: GET /  → endpoints
 *   GET /channels
 *   GET /channels/{id}
 *   GET /channels/categories
 *   GET /channels?category={nome}
 *   GET /sports
 *   GET /sports/{id}
 *   GET /sports?status={upcoming|live|finished}
 *   GET /sports?category={nome}
 *   GET /search?q={termo}
 * Público, sem auth.
 * --------------------------------------------------------------------- */

function urlHttpValida(url) {
  try {
    const parsed = new URL(String(url || ""));
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch (_) {
    return false;
  }
}

function normalizarEmbeds(lista) {
  return (Array.isArray(lista) ? lista : [])
    .map((embed) => ({
      provider: String(embed?.provider || "Servidor"),
      quality: String(embed?.quality || "Automático"),
      embed_url: String(embed?.embed_url || "").trim(),
    }))
    .filter((embed) => urlHttpValida(embed.embed_url));
}

export function normalizarCanal(item = {}) {
  let logo = String(item.logo_url || item.logo || item.poster || "").trim();
  if (logo.startsWith("//")) logo = "https:" + logo;
  return {
    id: String(item.id || ""),
    titulo: String(item.name || item.title || "Canal ao vivo"),
    descricao: String(item.description || ""),
    logo,
    categoria: String(item.category || "Outros"),
    embeds: normalizarEmbeds(item.embeds),
    epg: item.epg || {},
    aoVivo: true,
    tipo: "canal",
  };
}

export function normalizarEvento(item = {}) {
  let logo = String(item.poster || item.logo || item.logo_url || "").trim();
  if (logo.startsWith("//")) logo = "https:" + logo;
  const status = String(item.status || "").toLowerCase();
  return {
    id: String(item.id || ""),
    titulo: String(item.title || "Evento"),
    descricao: String(item.description || ""),
    logo,
    categoria: String(item.category || item.competition || "Esportes"),
    embeds: normalizarEmbeds(item.embeds),
    epg: { current: { title: item.competition || item.title || "Evento" } },
    aoVivo: status === "live",
    status,
    teams: item.teams || null,
    start_time: item.start_time || "",
    tipo: "evento",
  };
}

/** Lista canais (opcionalmente por categoria nome exata da API). */
export const getCanais = (categoria = "") => {
  const caminho = categoria
    ? `/channels?category=${encodeURIComponent(categoria)}`
    : "/channels";
  // TTL curto: lista muda (canais novos)
  return getJSON(caminho, 2 * 60 * 1000, LIVE_API_BASE).then((d) =>
    (Array.isArray(d?.data) ? d.data : []).map(normalizarCanal),
  );
};

export const getCanalCategorias = () =>
  getJSON("/channels/categories", 10 * 60 * 1000, LIVE_API_BASE).then((d) =>
    (Array.isArray(d?.data) ? d.data : []).map((item) => ({
      id: String(item.id || item.name || ""),
      nome: String(item.name || "Outros"),
    })),
  );

export const getCanal = (id) =>
  getJSON(`/channels/${encodeURIComponent(id)}`, 2 * 60 * 1000, LIVE_API_BASE).then((d) => {
    const raw = d?.data && !Array.isArray(d.data) ? d.data : d?.channel || d;
    return normalizarCanal(raw || {});
  });

/** Eventos: live prioritário; se vazio, traz upcoming+todos. */
export const getEventosAoVivo = async () => {
  try {
    const live = await getJSON("/sports?status=live", 60 * 1000, LIVE_API_BASE);
    const listaLive = (Array.isArray(live?.data) ? live.data : []).map(normalizarEvento);
    if (listaLive.length) return listaLive;
  } catch (_) {}
  try {
    const all = await getJSON("/sports", 60 * 1000, LIVE_API_BASE);
    return (Array.isArray(all?.data) ? all.data : [])
      .map(normalizarEvento)
      .filter((e) => e.status === "live" || e.status === "upcoming" || e.embeds.length > 0);
  } catch (_) {
    return [];
  }
};

export const getEventos = (status = "") => {
  const caminho = status ? `/sports?status=${encodeURIComponent(status)}` : "/sports";
  return getJSON(caminho, 60 * 1000, LIVE_API_BASE).then((d) =>
    (Array.isArray(d?.data) ? d.data : []).map(normalizarEvento),
  );
};

/** Pesquisa global — GET /search?q= */
export const buscarCanais = (q) => {
  const termo = String(q || "").trim();
  if (!termo) return Promise.resolve([]);
  return getJSON(`/search?q=${encodeURIComponent(termo)}`, 60 * 1000, LIVE_API_BASE).then((d) => {
    const payload = d?.data;
    if (Array.isArray(payload)) return payload.map(normalizarCanal);
    const canais = Array.isArray(payload?.channels) ? payload.channels.map(normalizarCanal) : [];
    const eventos = Array.isArray(payload?.events)
      ? payload.events.map(normalizarEvento)
      : Array.isArray(payload?.sports)
        ? payload.sports.map(normalizarEvento)
        : [];
    return [...canais, ...eventos];
  });
};
