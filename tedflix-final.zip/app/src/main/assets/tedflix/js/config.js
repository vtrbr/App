/** CONTENT API — catálogo principal (filmes, séries, home, busca, player HLS) */
export const CONTENT_API_BASE = "https://servidores-ted-auth-1.onrender.com/api";
/** Alias legado usado em vários módulos */
export const API_BASE = CONTENT_API_BASE;

/** USER / ADMIN API — auth, perfis, favoritos, progresso, histórico */
export const USER_API_BASE = "https://servidores-ted-auth.onrender.com";

/** TEDTOP API — conteúdo complementar, trailers, ingresso/player direto, radar */
export const TEDTOP_API_BASE = "https://servidores-ted-apply2.onrender.com";

/** LIVE API — canais e eventos ao vivo (Rei dos Canais) */
export const LIVE_API_BASE = "https://api.reidoscanais.st";

export const CATEGORIAS = [
  { slug: "acao", label: "Ação" },
  { slug: "animacao", label: "Animação" },
  { slug: "aventura", label: "Aventura" },
  { slug: "comedia", label: "Comédia" },
  { slug: "drama", label: "Drama" },
  { slug: "ficcao", label: "Ficção" },
  { slug: "ficcao-cientifica", label: "Ficção Científica" },
  { slug: "romance", label: "Romance" },
  { slug: "suspense", label: "Suspense" },
  { slug: "terror", label: "Terror" },
];

export const NAV = [
  { href: "#/", label: "Início", icon: "home" },
  { href: "#/series", label: "Séries", icon: "tv" },
  { href: "#/filmes", label: "Filmes", icon: "film" },
  { href: "#/canais", label: "Canais", icon: "broadcast" },
  { href: "#/categorias", label: "Categorias", icon: "grid" },
  { href: "#/agenda", label: "Agenda", icon: "calendar" },
];
