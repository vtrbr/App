
import { el } from "../dom.js";
import { CATEGORIAS } from "../config.js";

export default function paginaCategorias(raiz) {
  const page = el("div", { class: "page" });

  const secoes = [
    {
      titulo: "Explorar TEDTOP",
      itens: [
        { label: "Telão", href: "#/tedtop/telao", tom: "#e50914" },
        { label: "Bilheteria", href: "#/tedtop/bilheteria", tom: "#b8860b" },
        { label: "Por ano", href: "#/tedtop/ano/2026", tom: "#4a90d9" },
        { label: "Por letra", href: "#/tedtop/letra/A", tom: "#9b59b6" },
        { label: "Por gênero", href: "#/tedtop/genero/acao", tom: "#e67e22" },
        { label: "Radar", href: "#/tedtop/radar", tom: "#1abc9c" },
      ],
    },
    {
      titulo: "Em destaque",
      itens: [
        { label: "Lançamentos", href: "#/categoria/lancamentos", tom: "#e50914" },
        { label: "Filmes", href: "#/filmes", tom: null },
        { label: "Séries", href: "#/series", tom: null },
      ],
    },
    {
      titulo: "Gêneros do catálogo",
      itens: CATEGORIAS.map((c) => ({
        label: c.label,
        href: `#/categoria/${c.slug}`,
        tom: null,
      })),
    },
  ];

  page.append(el("h1", { class: "page-title" }, "Categorias"));

  secoes.forEach((sec) => {
    page.append(
      el(
        "h2",
        {
          class: "section-head",
          style: "padding:16px 16px 8px;margin:0;font-size:0.95rem;color:var(--muted-foreground)",
        },
        sec.titulo,
      ),
    );
    const grid = el("div", {
      class: "pad cat-grid",
      style: "display:grid;grid-template-columns:repeat(2,1fr);gap:12px;padding-top:0",
    });
    sec.itens.forEach((c) => {
      const style = [
        "display:grid;place-items:center;min-height:84px;border-radius:14px",
        "background:var(--surface);font-family:var(--font-display);font-size:15px",
        "text-transform:uppercase;text-align:center;padding:10px;border:1px solid transparent",
        c.tom ? `border-color:${c.tom}55` : "",
      ].join(";");
      grid.append(el("a", { href: c.href, style, class: "cat-tile" }, c.label));
    });
    page.append(grid);
  });

  raiz.append(page);
  return page;
}
