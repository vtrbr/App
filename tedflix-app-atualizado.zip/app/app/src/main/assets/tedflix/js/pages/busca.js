import { el, debounce, limpar } from "../dom.js";
import { buscar } from "../api.js";
import { cardTitulo, skeletonCard } from "../components/card.js";

/**
 * Histórico de busca otimizado:
 * - UI sempre local (instantâneo)
 * - API só salva o termo FINAL (quando a digitação para por ~1.2s)
 * - Não grava prefixos intermediários (Ori, Orige…) se o termo final os cobre
 * - save na API é fire-and-forget (bridge assíncrono no Android)
 */

function bridge(nome, ...args) {
  try {
    const b = window.AndroidPlayer;
    if (!b || typeof b[nome] !== "function") return null;
    const raw = b[nome](...args);
    if (typeof raw === "object") return raw;
    return JSON.parse(raw || "null");
  } catch (_) {
    return null;
  }
}

function chaveHistoricoLocal() {
  try {
    const dados = JSON.parse(window.AndroidPlayer?.getProfiles?.() || "{}");
    return `tedflix:search-history:${dados.activeId || "guest"}`;
  } catch (_) {
    return "tedflix:search-history:guest";
  }
}

function lerLocal() {
  try {
    const itens = JSON.parse(localStorage.getItem(chaveHistoricoLocal()) || "[]");
    return Array.isArray(itens)
      ? itens
          .map((x) =>
            typeof x === "string"
              ? { id: encodeURIComponent(x.toLowerCase()), query: x }
              : {
                  id: String(x.id || encodeURIComponent(String(x.query || "").toLowerCase())),
                  query: String(x.query || ""),
                },
          )
          .filter((x) => x.query && x.query.length >= 2)
          .slice(0, 12)
      : [];
  } catch (_) {
    return [];
  }
}

function salvarLocal(lista) {
  try {
    localStorage.setItem(chaveHistoricoLocal(), JSON.stringify(lista.slice(0, 12)));
  } catch (_) {}
}

/** Remove prefixos do mesmo termo (Ori + Orige quando grava Origem). */
function dedupePrefixos(lista, termoFinal) {
  const t = termoFinal.toLowerCase();
  return lista.filter((item) => {
    const q = item.query.toLowerCase();
    if (q === t) return true;
    // remove se for prefixo próprio do termo final
    if (t.startsWith(q) && q.length < t.length) return false;
    return true;
  });
}

let historicoCache = null;
let historicoCarregando = null;

async function carregarHistorico(forcar = false) {
  if (!forcar && historicoCache) return historicoCache;
  if (historicoCarregando) return historicoCarregando;

  historicoCarregando = (async () => {
    // local primeiro — UI nunca espera rede
    const local = lerLocal();
    historicoCache = local;

    // remoto em background (não trava render)
    try {
      const remoto = bridge("getSearchHistory");
      if (remoto && remoto.success && Array.isArray(remoto.history) && remoto.history.length) {
        const lista = remoto.history
          .map((x) => ({
            id: String(x.id || encodeURIComponent(String(x.query || "").toLowerCase())),
            query: String(x.query || "").trim(),
          }))
          .filter((x) => x.query && x.query.length >= 2)
          .slice(0, 12);
        if (lista.length) {
          salvarLocal(lista);
          historicoCache = lista;
        }
      }
    } catch (_) {}
    return historicoCache || [];
  })();

  try {
    return await historicoCarregando;
  } finally {
    historicoCarregando = null;
  }
}

/** Só grava termo "final" — chamado com debounce longo. */
function gravarTermoFinal(valor) {
  const termo = String(valor || "").trim();
  if (termo.length < 2) return;

  let atuais = dedupePrefixos(lerLocal(), termo);
  atuais = atuais.filter((item) => item.query.toLowerCase() !== termo.toLowerCase());
  const novo = [{ id: encodeURIComponent(termo.toLowerCase()), query: termo }, ...atuais].slice(0, 12);
  salvarLocal(novo);
  historicoCache = novo;

  // API em background (bridge já é Thread no Android)
  try {
    bridge("saveSearchHistory", termo);
  } catch (_) {}
}

async function apagarUma(item) {
  const id = item?.id || encodeURIComponent(String(item?.query || "").toLowerCase());
  const query = String(item?.query || "");
  const resto = lerLocal().filter(
    (x) => x.id !== id && x.query.toLowerCase() !== query.toLowerCase(),
  );
  salvarLocal(resto);
  historicoCache = resto;
  try {
    bridge("deleteSearchHistoryItem", id);
  } catch (_) {}
}

export default function paginaBusca(raiz) {
  const page = el("div", { class: "page" });
  const campo = el("input", {
    class: "input",
    type: "search",
    placeholder: "Buscar filmes e séries...",
    "aria-label": "Buscar",
  });
  const grid = el("div", { class: "grid", style: "margin-top:16px" });
  const aviso = el("p", { class: "sub", style: "padding:16px" }, "Digite para buscar.");
  const recentes = el("div", { class: "pad search-recent" });

  page.append(
    el("h1", { class: "page-title" }, "Busca"),
    el("div", { class: "pad", style: "margin-top:8px" }, [campo]),
    aviso,
    recentes,
    grid,
  );
  raiz.append(page);
  setTimeout(() => campo.focus(), 50);

  function renderRecentesFrom(itens) {
    recentes.innerHTML = "";
    if (!itens || !itens.length) return;
    recentes.append(
      el("div", { class: "search-recent-head" }, [
        el("p", { class: "sub", style: "margin:0" }, "Pesquisas recentes"),
      ]),
    );
    itens.forEach((item) => {
      const row = el("div", { class: "search-recent-row" });
      const botao = el("button", { class: "btn ghost search-recent-term", type: "button" }, item.query);
      botao.addEventListener("click", () => {
        campo.value = item.query;
        buscarAgora(item.query);
      });
      const del = el(
        "button",
        {
          class: "btn ghost search-recent-del",
          type: "button",
          "aria-label": `Apagar ${item.query}`,
          title: "Apagar",
        },
        "×",
      );
      del.addEventListener("click", async (e) => {
        e.stopPropagation();
        await apagarUma(item);
        renderRecentesFrom(historicoCache || lerLocal());
      });
      row.append(botao, del);
      recentes.append(row);
    });
  }

  // Local imediato + remoto em background
  renderRecentesFrom(lerLocal());
  carregarHistorico().then((itens) => renderRecentesFrom(itens));

  // Debounce curto = busca de catálogo; debounce longo = só histórico final
  const salvarHistoricoFinal = debounce((q) => {
    gravarTermoFinal(q);
    renderRecentesFrom(historicoCache || lerLocal());
  }, 1200);

  let buscaSeq = 0;
  const buscarAgora = debounce(async (q) => {
    const termo = String(q || "").trim();
    if (termo.length < 2) {
      limpar(grid);
      aviso.textContent = "Digite ao menos 2 letras.";
      return;
    }
    aviso.textContent = "";
    limpar(grid);
    for (let i = 0; i < 6; i++) grid.append(skeletonCard());
    const seq = ++buscaSeq;
    try {
      const { resultados } = await buscar(termo);
      if (seq !== buscaSeq) return; // resposta antiga, ignora
      limpar(grid);
      if (!resultados.length) {
        aviso.textContent = "Nenhum resultado encontrado.";
        return;
      }
      const frag = document.createDocumentFragment();
      resultados.forEach((r) => frag.append(cardTitulo(r, { size: "md" })));
      grid.append(frag);
    } catch (e) {
      if (seq !== buscaSeq) return;
      limpar(grid);
      aviso.textContent = "Falha na busca. Tente novamente.";
    }
  }, 350);

  campo.addEventListener("input", () => {
    const v = campo.value;
    buscarAgora(v);
    // histórico só depois de parar de digitar
    if (String(v || "").trim().length >= 2) salvarHistoricoFinal(v);
  });

  // Enter grava imediatamente
  campo.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      const v = campo.value;
      gravarTermoFinal(v);
      renderRecentesFrom(historicoCache || lerLocal());
      buscarAgora(v);
    }
  });

  return page;
}
