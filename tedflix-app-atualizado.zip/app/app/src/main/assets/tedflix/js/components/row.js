import { el, limpar, aoAparecer } from "../dom.js";
import { cardTitulo, skeletonCard } from "./card.js";
import { prefetchImagens } from "../img.js";

/**
 * Fileira horizontal preguiçosa estilo Netflix.
 * variante: "continuar" | "tedtop" | default
 */
export function fileira({ titulo, verTudo, carregar, limite = 20, variante = "" }) {
  const rail = el("div", {
    class: `rail${variante ? ` rail--${variante}` : ""}`,
    role: "region",
    "aria-label": titulo,
  });
  for (let i = 0; i < 6; i++) rail.append(skeletonCard());

  const secao = el("section", {
    class: `section${variante ? ` section--${variante}` : ""}`,
  }, [
    el("div", { class: "section-head" }, [
      el("h2", {}, titulo),
      verTudo ? el("a", { href: verTudo }, "Ver tudo ›") : null,
    ]),
    rail,
  ]);

  let carregada = false;
  const carregarRail = async () => {
    if (carregada) return;
    carregada = true;
    try {
      const itens = (await carregar()) || [];
      limpar(rail);
      if (!itens.length) {
        // Fileiras TEDTOP/continuar vazias: remove a seção inteira
        if (variante === "continuar" || variante === "tedtop") {
          secao.remove();
          return;
        }
        rail.append(el("p", { class: "sub" }, "Nada por aqui agora."));
        return;
      }
      const lista = itens.slice(0, limite);
      const primeiros = document.createDocumentFragment();
      lista.slice(0, 10).forEach((item) =>
        primeiros.append(cardTitulo(item, { eager: true, size: variante === "continuar" ? "md" : "sm" })),
      );
      rail.append(primeiros);

      const agenda = window.requestIdleCallback || ((f) => setTimeout(f, 60));
      agenda(() => {
        const frag = document.createDocumentFragment();
        lista.slice(6).forEach((item) =>
          frag.append(cardTitulo(item, { size: variante === "continuar" ? "md" : "sm" })),
        );
        rail.append(frag);
        prefetchImagens(
          itens.slice(0, limite + 10).map((i) => i.imagem || i.capa || i.thumb || i.poster).filter(Boolean),
        );
      });
    } catch (e) {
      limpar(rail);
      if (variante === "tedtop" || variante === "continuar") {
        secao.remove();
        return;
      }
      rail.append(
        el("div", { class: "rail-error" }, [
          el("p", { class: "sub" }, "Não foi possível carregar esta fileira."),
          el("button", {
            class: "btn ghost",
            type: "button",
            onclick: () => {
              carregada = false;
              limpar(rail);
              for (let i = 0; i < 6; i++) rail.append(skeletonCard());
              carregarRail();
            },
          }, "Tentar de novo"),
        ]),
      );
    }
  };
  aoAparecer(secao, carregarRail, "1800px");
  // Continuar e TEDTOP: carregar mais cedo (destaque na home)
  setTimeout(carregarRail, variante === "continuar" || variante === "tedtop" ? 200 : 1200);

  return secao;
}
