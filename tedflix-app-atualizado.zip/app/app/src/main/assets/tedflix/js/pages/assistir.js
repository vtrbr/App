import { el } from "../dom.js";
import { getManifesto, noflixFilmeStreamUrl, noflixEpStreamUrl } from "../api.js";
import { montarPlayer, limparPlayer } from "../components/player.js";

/** Entra em tela cheia horizontal (cinema) — precisa de gesto do usuário. */
async function modoCinema(alvo) {
  try {
    if (!document.fullscreenElement) {
      await (alvo.requestFullscreen?.() || alvo.webkitRequestFullscreen?.());
    } else {
      await document.exitFullscreen();
      return;
    }
  } catch (e) {
    /* navegador pode recusar */
  }
  try {
    await screen.orientation?.lock?.("landscape");
  } catch (e) {
    /* desktop / iOS não permitem */
  }
}

export default async function paginaAssistir(raiz, { categoria, slug, fila = [], filmeId = "", thumb = "", tipo = "", serieCategoria = "", serieSlug = "", episodios = [], recomendados = [] }) {
  document.body.classList.add("imersivo");

  const page = el("div", { class: "page assistir" });
  const palco = el("div", { class: "cinema" });
  const caixa = el("div", { class: "player-wrap" });

  palco.append(caixa);
  page.append(palco);
  raiz.append(page);

  const carregando = el("div", { class: "center" }, [
    el("div", { class: "spinner" }),
    el("p", {}, "Preparando transmissão..."),
  ]);
  caixa.append(carregando);

  const voltar = () => history.back();
  let instancia = null;

  // Registra a limpeza antes do handoff nativo. Sem isso, o retorno do
  // PlayerActivity deixava a página Android sem o hook de destruição.
  page.destruir = () => {
    document.body.classList.remove("imersivo");
    try {
      screen.orientation?.unlock?.();
    } catch (err) {}
    instancia?.destruir?.();
    limparPlayer();
  };

  try {
    const nome = decodeURIComponent(slug).replace(/^\d+-/, "").replace(/-/g, " ");

    // No Android, a interface permanece igual, mas a reprodução é delegada
    // ao player nativo para suportar HLS e tela cheia horizontal.
    if (window.AndroidPlayer && typeof window.AndroidPlayer.openPlayer === "function") {
      window.AndroidPlayer.openPlayer(
        categoria,
        slug,
        nome,
        JSON.stringify(Array.isArray(fila) ? fila : []),
        filmeId || slug,
        thumb,
        tipo,
        serieCategoria,
        serieSlug,
        JSON.stringify(Array.isArray(episodios) ? episodios : []),
        JSON.stringify(Array.isArray(recomendados) ? recomendados : []),
      );
      return page;
    }

    let m3u8;
    if (String(categoria).toLowerCase() === "noflix") {
      // slug: filme-{id}-{audio} | serie-{id}-{t}-{e}-{audio}
      const parts = String(slug).split("-");
      if (parts[0] === "filme" && parts.length >= 3) {
        const audio = parts[parts.length - 1];
        const id = parts.slice(1, -1).join("-");
        const url = noflixFilmeStreamUrl(id, audio);
        const r = await fetch(url);
        if (!r.ok) throw new Error("Player NoFlix indisponível.");
        m3u8 = await r.text();
      } else if (parts[0] === "serie" && parts.length >= 5) {
        const audio = parts[parts.length - 1];
        const ep = parts[parts.length - 2];
        const temp = parts[parts.length - 3];
        const id = parts.slice(1, -3).join("-");
        const url = noflixEpStreamUrl(id, temp, ep, audio);
        const r = await fetch(url);
        if (!r.ok) throw new Error("Episódio NoFlix indisponível.");
        m3u8 = await r.text();
      } else {
        throw new Error("Rota NoFlix inválida.");
      }
      if (!String(m3u8).includes("#EXTM3U")) throw new Error("Fonte de vídeo inválida.");
    } else {
      m3u8 = await getManifesto(categoria, slug);
    }
    caixa.innerHTML = "";
    instancia = montarPlayer(caixa, {
      m3u8,
      titulo: nome,
      aoStatus: () => {}, // o player agora mostra seu próprio overlay de status/erro
      aoVoltar: voltar,
      aoGirar: () => modoCinema(palco),
    });
    // primeiro toque na tela já joga em tela cheia horizontal (mobile)
    caixa.addEventListener("click", function once(ev) {
      if (ev.target.closest(".tp-back, .tp-btn, .tp-progresso, .tp-menu-btn")) return;
      caixa.removeEventListener("click", once);
      if (window.matchMedia("(max-width: 900px)").matches) modoCinema(palco);
    });
  } catch (e) {
    caixa.innerHTML = "";
    const retry = el("button", { class: "btn primary" }, "Tentar novamente");
    retry.addEventListener("click", () => {
      raiz.innerHTML = "";
      paginaAssistir(raiz, { categoria, slug, fila, filmeId, thumb, tipo, serieCategoria, serieSlug, episodios, recomendados });
    });
    caixa.append(
      el("div", { class: "center" }, [
        el("p", {}, e.message || "Não foi possível carregar o vídeo."),
        retry,
      ]),
    );
  }

  return page;
}
