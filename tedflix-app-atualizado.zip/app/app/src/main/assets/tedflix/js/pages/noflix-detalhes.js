import { el, limpar, svgIcone } from "../dom.js";
import {
  getNoflixFilmeMeta,
  getNoflixSerieMeta,
  getNoflixTemporadas,
  getNoflixEpisodios,
  noflixFilmeStreamUrl,
  noflixEpStreamUrl,
  corrigirTexto,
  lerNoflixItem,
} from "../api.js";
import { backdrop, poster } from "../img.js";

function abrirPlayerNativo({ categoria, slug, titulo, thumb, tipo, filmeId }) {
  if (window.AndroidPlayer && typeof window.AndroidPlayer.openPlayer === "function") {
    window.AndroidPlayer.openPlayer(
      categoria,
      slug,
      titulo || "",
      "[]",
      filmeId || slug,
      thumb || "",
      tipo || "noflix",
      "",
      "",
      "[]",
      "[]",
    );
    return true;
  }
  return false;
}

function metaLinha(item) {
  const bits = [];
  if (item.nota != null && !Number.isNaN(Number(item.nota))) bits.push(`★ ${Number(item.nota).toFixed(1)}`);
  if (item.ano) bits.push(String(item.ano));
  if (item.runtime) {
    const m = Number(item.runtime);
    if (m >= 60) bits.push(`${Math.floor(m / 60)}h ${m % 60}min`);
    else if (m > 0) bits.push(`${m}min`);
  }
  if (item.idioma) bits.push(item.idioma);
  if (item.audioLabel) bits.push(item.audioLabel);
  return bits.join(" · ");
}

function botoesFilme(item) {
  const wrap = el("div", { class: "noflix-actions" });
  const titulo = item.titulo || "Filme";
  const thumb = item.imagem || item.banner || "";
  const id = item.idtmdb;

  const play = (audio, label) => {
    const slug = `filme-${id}-${audio}`;
    if (
      abrirPlayerNativo({
        categoria: "noflix",
        slug,
        titulo: `${titulo} (${label})`,
        thumb,
        tipo: "noflix",
        filmeId: id,
      })
    ) {
      return;
    }
    location.hash = `#/assistir/noflix/${encodeURIComponent(slug)}`;
  };

  if (item.temDub && item.temLeg) {
    wrap.append(
      el("button", { class: "btn primary", type: "button", onclick: () => play("dub", "Dublado") }, "▶ Assistir dublado"),
      el("button", { class: "btn ghost", type: "button", onclick: () => play("leg", "Legendado") }, "▶ Assistir legendado"),
    );
  } else if (item.temDub) {
    wrap.append(el("button", { class: "btn primary", type: "button", onclick: () => play("dub", "Dublado") }, "▶ Assistir"));
  } else if (item.temLeg) {
    wrap.append(el("button", { class: "btn primary", type: "button", onclick: () => play("leg", "Legendado") }, "▶ Assistir legendado"));
  } else {
    wrap.append(el("p", { class: "sub" }, "Player indisponível para este título."));
  }
  return wrap;
}

export async function paginaNoflixFilme(raiz, { idtmdb }) {
  const page = el("div", { class: "page" });
  // Cache primeiro (vindo da lista) — evita tela vazia
  let item = lerNoflixItem(idtmdb);
  if (!item) {
    page.append(el("div", { class: "center" }, [el("div", { class: "spinner" }), el("p", {}, "Carregando…")]));
  }
  raiz.append(page);

  try {
    const fresh = await getNoflixFilmeMeta(idtmdb);
    if (fresh) item = fresh;
  } catch (_) {}

  limpar(page);
  if (!item) {
    page.append(
      el("div", { class: "pad" }, [
        el("p", { class: "sub" }, "Título não encontrado na fonte NoFlix."),
        el("p", { class: "sub" }, "Volte à lista e abra de novo (a API não busca por ID)."),
        el("button", { class: "btn ghost", type: "button", onclick: () => history.back() }, "Voltar"),
      ]),
    );
    return page;
  }

  const hero = el("div", {
    class: "hero",
    style: "margin:0;border-radius:0;aspect-ratio:16/10;max-height:42vh",
  });
  if (item.banner || item.imagem) {
    hero.append(
      el("img", {
        src: backdrop(item.banner || item.imagem, 780) || item.banner || item.imagem,
        alt: "",
        loading: "eager",
      }),
    );
  }
  hero.append(el("div", { class: "veil" }));
  hero.append(
    el("div", { class: "info" }, [
      el("h1", {}, item.titulo || "Filme"),
      el("p", { class: "tags" }, metaLinha(item)),
    ]),
  );
  page.append(hero);
  page.append(botoesFilme(item));
  if (item.sinopse) page.append(el("p", { class: "sub pad", style: "line-height:1.45" }, item.sinopse));
  if (item.categoria) {
    const cats = String(item.categoria)
      .split(",")
      .map((c) => c.trim())
      .filter(Boolean);
    const row = el("div", { class: "pad", style: "display:flex;flex-wrap:wrap;gap:8px" });
    cats.forEach((c) => row.append(el("span", { class: "noflix-chip" }, c)));
    page.append(row);
  }
  if (item.produtora) {
    page.append(el("p", { class: "sub pad", style: "padding-top:0" }, `Produção: ${item.produtora}`));
  }
  return page;
}

export async function paginaNoflixSerie(raiz, { idtmdb }) {
  const page = el("div", { class: "page" });
  let item = lerNoflixItem(idtmdb);
  if (!item) {
    page.append(el("div", { class: "center" }, [el("div", { class: "spinner" }), el("p", {}, "Carregando…")]));
  }
  raiz.append(page);

  let temporadas = [];
  try {
    const [fresh, temps] = await Promise.all([
      getNoflixSerieMeta(idtmdb),
      getNoflixTemporadas(idtmdb).catch(() => []),
    ]);
    if (fresh) item = fresh;
    temporadas = temps || [];
  } catch (_) {}

  limpar(page);
  if (!item) {
    page.append(
      el("div", { class: "pad" }, [
        el("p", { class: "sub" }, "Série não encontrada na fonte NoFlix."),
        el("p", { class: "sub" }, "Volte à lista e abra de novo."),
        el("button", { class: "btn ghost", type: "button", onclick: () => history.back() }, "Voltar"),
      ]),
    );
    return page;
  }

  const hero = el("div", {
    class: "hero",
    style: "margin:0;border-radius:0;aspect-ratio:16/10;max-height:42vh",
  });
  if (item.banner || item.imagem) {
    hero.append(
      el("img", {
        src: backdrop(item.banner || item.imagem, 780) || item.banner || item.imagem,
        alt: "",
        loading: "eager",
      }),
    );
  }
  hero.append(el("div", { class: "veil" }));
  hero.append(
    el("div", { class: "info" }, [
      el("h1", {}, item.titulo || "Série"),
      el("p", { class: "tags" }, metaLinha(item)),
    ]),
  );
  page.append(hero);
  if (item.sinopse) page.append(el("p", { class: "sub pad", style: "line-height:1.45" }, item.sinopse));

  const listaTemps = temporadas.length ? temporadas : [{ numero: 1, titulo: "Temporada 1" }];
  let tempAtual = listaTemps[0].numero;
  const chips = el("div", { class: "pad tedtop-chips tedtop-chips--wide" });
  const epsBox = el("div", { class: "pad" });

  async function carregarEps(num) {
    tempAtual = num;
    [...chips.children].forEach((b) => b.classList.toggle("active", Number(b.dataset.t) === Number(num)));
    limpar(epsBox);
    epsBox.append(el("p", { class: "sub" }, "Carregando episódios…"));
    try {
      const eps = await getNoflixEpisodios(idtmdb, num);
      limpar(epsBox);
      if (!eps.length) {
        epsBox.append(el("p", { class: "sub" }, "Nenhum episódio nesta temporada."));
        return;
      }
      eps.forEach((ep) => {
        const play = (audio, label) => {
          const slug = `serie-${idtmdb}-${num}-${ep.numero}-${audio || "dub"}`;
          if (
            abrirPlayerNativo({
              categoria: "noflix",
              slug,
              titulo: `${item.titulo} T${num}E${ep.numero}${label ? " " + label : ""}`,
              thumb: ep.imagem || item.imagem || "",
              tipo: "noflix",
              filmeId: `${idtmdb}-t${num}e${ep.numero}`,
            })
          ) {
            return;
          }
          location.hash = `#/assistir/noflix/${encodeURIComponent(slug)}`;
        };
        const actions = el("div", { class: "ep-actions" });
        if (ep.temDub && ep.temLeg) {
          actions.append(
            el("button", { class: "btn primary", type: "button", onclick: () => play("dub", "DUB") }, "DUB"),
            el("button", { class: "btn ghost", type: "button", onclick: () => play("leg", "LEG") }, "LEG"),
          );
        } else if (ep.temDub) {
          actions.append(el("button", { class: "btn primary", type: "button", onclick: () => play("dub") }, "▶"));
        } else if (ep.temLeg) {
          actions.append(el("button", { class: "btn primary", type: "button", onclick: () => play("leg", "LEG") }, "LEG"));
        } else {
          actions.append(el("span", { class: "sub" }, "—"));
        }
        const row = el("div", { class: "noflix-ep" }, [
          ep.imagem
            ? el("img", { src: poster(ep.imagem, "sm") || ep.imagem, alt: "", loading: "lazy" })
            : el("div", { style: "width:120px;height:68px;background:#222;border-radius:8px;flex:0 0 auto" }),
          el("div", { class: "info" }, [
            el("strong", {}, `${ep.numero}. ${ep.titulo || "Episódio"}`),
            el(
              "span",
              {},
              [ep.runtime ? `${ep.runtime}min` : "", ep.audioLabel || ""].filter(Boolean).join(" · ") || " ",
            ),
          ]),
          actions,
        ]);
        epsBox.append(row);
      });
    } catch (_) {
      limpar(epsBox);
      epsBox.append(el("p", { class: "sub" }, "Falha ao carregar episódios."));
    }
  }

  listaTemps.forEach((t) => {
    const btn = el(
      "button",
      {
        class: `chip${Number(t.numero) === Number(tempAtual) ? " active" : ""}`,
        type: "button",
        "data-t": String(t.numero),
      },
      t.titulo || `Temporada ${t.numero}`,
    );
    btn.addEventListener("click", () => carregarEps(t.numero));
    chips.append(btn);
  });

  page.append(chips, epsBox);
  carregarEps(tempAtual);
  return page;
}
