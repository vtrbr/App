import { el, limpar, debounce } from "../dom.js";
import { cardTitulo, skeletonCard } from "../components/card.js";
import {
  getNoflixFilmes,
  getNoflixSeries,
  getNoflixFilmesTed,
  getNoflixSeriesTed,
  getNoflixSeriesEstreias,
  getNoflixFilmesAno,
  getNoflixSeriesAno,
  getNoflixFilmesGenero,
  getNoflixSeriesGenero,
  getNoflixUltimosEps,
  getFilmes,
  getSeries,
  getTedtopTelao,
  getTedtopBilheteria,
  normalizar,
} from "../api.js";

const GENEROS = [
  "Ação", "Aventura", "Animação", "Comédia", "Crime", "Drama",
  "Fantasia", "Ficção", "Romance", "Suspense", "Terror", "Thriller",
];

const ANOS = (() => {
  const y = new Date().getFullYear();
  const list = [];
  for (let i = 0; i < 12; i++) list.push(String(y - i));
  return list;
})();

/**
 * Catálogo NoFlix completo — listagem + top + ano + gênero (+ estreias/eps em séries)
 * Mantém filtros DUB/LEG na listagem principal.
 */

function chaveItem(i) {
  const t = String(i.titulo || "").toLowerCase().replace(/\s+/g, " ").trim();
  const a = String(i.ano || "");
  const id = String(i.idtmdb || i.slug || i.filmeId || "");
  return id ? `id:${id}` : `t:${t}|${a}`;
}

/** Junta listas de fontes diferentes sem duplicar título/ano (ou id). */
function mesclarCatalogo(listas) {
  const vistos = new Set();
  const out = [];
  for (const item of listas) {
    if (!item) continue;
    const k = chaveItem(item);
    if (vistos.has(k)) continue;
    vistos.add(k);
    out.push(item);
  }
  return out;
}

export function paginaNoflixCatalogo(raiz, { tipo = "filme", titulo, modoInicial = "lista" } = {}) {
  const isSerie = String(tipo).toLowerCase().includes("serie");
  const page = el("div", { class: "page" });
  page.append(el("h1", { class: "page-title" }, titulo || (isSerie ? "Séries" : "Filmes")));

  // Modos de navegação (rotas da API)
  const modos = isSerie
    ? [
        { id: "lista", label: "Lista" },
        { id: "top", label: "Top" },
        { id: "estreias", label: "Estreias" },
        { id: "eps", label: "Últimos eps" },
        { id: "ano", label: "Por ano" },
        { id: "genero", label: "Gênero" },
      ]
    : [
        { id: "lista", label: "Lista" },
        { id: "top", label: "Top" },
        { id: "ano", label: "Por ano" },
        { id: "genero", label: "Gênero" },
      ];

  const chipsModo = el("div", { class: "pad tedtop-chips tedtop-chips--wide" });
  const chipsSec = el("div", { class: "pad tedtop-chips tedtop-chips--wide" });
  const busca = el("input", {
    class: "input",
    type: "search",
    placeholder: "Filtrar nesta lista…",
    style: "margin:8px 16px 0;width:calc(100% - 32px)",
  });
  const info = el("p", { class: "sub pad" }, "Carregando…");
  const grid = el("div", { class: "grid pad" });

  page.append(chipsModo, chipsSec, busca, info, grid);
  raiz.append(page);

  let modo = modos.some((m) => m.id === modoInicial) ? modoInicial : "lista";
  let audio = "";
  let ano = ANOS[0];
  let genero = GENEROS[0];
  let reqId = 0;
  let todos = [];

  function setActive(container, key, val) {
    [...container.children].forEach((b) => b.classList.toggle("active", b.dataset[key] === String(val)));
  }

  function render(lista) {
    limpar(grid);
    if (!lista.length) {
      grid.append(el("p", { class: "sub pad" }, "Nenhum título neste filtro."));
      info.textContent = "0 títulos";
      return;
    }
    info.textContent = `${lista.length} título${lista.length === 1 ? "" : "s"}`;
    const frag = document.createDocumentFragment();
    lista.forEach((item, i) => frag.append(cardTitulo(item, { size: "sm", eager: i < 12 })));
    grid.append(frag);
  }

  function montarSecundarios() {
    limpar(chipsSec);
    if (modo === "lista") {
      [
        { id: "", label: "Todos" },
        { id: "dub", label: "Dublado" },
        { id: "leg", label: "Legendado" },
      ].forEach((f) => {
        const b = el("button", { class: `chip${f.id === audio ? " active" : ""}`, type: "button", "data-a": f.id }, f.label);
        b.addEventListener("click", () => {
          audio = f.id;
          carregar();
        });
        chipsSec.append(b);
      });
    } else if (modo === "ano") {
      ANOS.forEach((a) => {
        const b = el("button", { class: `chip${a === ano ? " active" : ""}`, type: "button", "data-y": a }, a);
        b.addEventListener("click", () => {
          ano = a;
          carregar();
        });
        chipsSec.append(b);
      });
    } else if (modo === "genero") {
      GENEROS.forEach((g) => {
        const b = el("button", { class: `chip${g === genero ? " active" : ""}`, type: "button", "data-g": g }, g);
        b.addEventListener("click", () => {
          genero = g;
          carregar();
        });
        chipsSec.append(b);
      });
    }
    // top / estreias / eps: sem chips secundários
  }

  async function carregar() {
    const my = ++reqId;
    setActive(chipsModo, "m", modo);
    montarSecundarios();
    limpar(grid);
    for (let i = 0; i < 9; i++) grid.append(skeletonCard());
    info.textContent = "Carregando…";
    busca.value = "";
    try {
      let itens = [];
      if (modo === "lista") {
        // Séries: Tedflix + NoFlix | Filmes: Tedflix + NoFlix + TEDTOP
        if (isSerie) {
          const [nox, ted] = await Promise.all([
            getNoflixSeries({ audio, limite: 120 }).catch(() => []),
            // filtro de áudio só existe no NoFlix; Tedflix vem completo
            audio ? Promise.resolve([]) : getSeries().catch(() => []),
          ]);
          itens = mesclarCatalogo([...(ted || []), ...(nox || [])]);
        } else {
          const [nox, ted, top1, top2] = await Promise.all([
            getNoflixFilmes({ audio, limite: 120 }).catch(() => []),
            audio ? Promise.resolve([]) : getFilmes().catch(() => []),
            audio
              ? Promise.resolve([])
              : getTedtopTelao(1).then((d) => d.itens || []).catch(() => []),
            audio
              ? Promise.resolve([])
              : getTedtopBilheteria().catch(() => []),
          ]);
          itens = mesclarCatalogo([...(ted || []), ...(nox || []), ...(top1 || []), ...(top2 || [])]);
        }
      } else if (modo === "top") {
        itens = isSerie ? await getNoflixSeriesTed(40) : await getNoflixFilmesTed(30);
      } else if (modo === "estreias") {
        itens = await getNoflixSeriesEstreias(40);
      } else if (modo === "eps") {
        itens = await getNoflixUltimosEps(40);
      } else if (modo === "ano") {
        itens = isSerie ? await getNoflixSeriesAno(ano, 40) : await getNoflixFilmesAno(ano, 40);
      } else if (modo === "genero") {
        itens = isSerie
          ? await getNoflixSeriesGenero(genero, 48)
          : await getNoflixFilmesGenero(genero, 48);
      }
      if (my !== reqId) return;
      todos = itens || [];
      render(todos);
    } catch (e) {
      if (my !== reqId) return;
      limpar(grid);
      info.textContent = "Falha ao carregar. Tente de novo.";
      grid.append(
        el(
          "button",
          { class: "btn ghost", type: "button", style: "margin:8px 16px", onclick: () => carregar() },
          "Tentar de novo",
        ),
      );
    }
  }

  modos.forEach((m) => {
    const b = el("button", { class: `chip${m.id === modo ? " active" : ""}`, type: "button", "data-m": m.id }, m.label);
    b.addEventListener("click", () => {
      modo = m.id;
      carregar();
    });
    chipsModo.append(b);
  });

  const filtrarLocal = debounce((q) => {
    const t = String(q || "").trim().toLowerCase();
    if (!t) {
      render(todos);
      return;
    }
    render(
      todos.filter(
        (i) =>
          String(i.titulo || "").toLowerCase().includes(t) ||
          String(i.tituloSerie || "").toLowerCase().includes(t),
      ),
    );
  }, 220);

  busca.addEventListener("input", () => filtrarLocal(busca.value));
  carregar();
  return page;
}

export default paginaNoflixCatalogo;
