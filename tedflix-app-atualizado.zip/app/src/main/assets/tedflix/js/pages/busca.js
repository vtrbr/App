import { el, debounce, limpar } from "../dom.js";
import { buscar } from "../api.js";
import { cardTitulo, skeletonCard } from "../components/card.js";

function bridge(nome, ...args) {
  try {
    const b = window.AndroidPlayer;
    if (!b || typeof b[nome] !== "function") return null;
    const raw = b[nome](...args);
    if (typeof raw === "object") return raw;
    return JSON.parse(raw || "null");
  } catch (_) {
    return null;
  }
}

function chaveHistoricoLocal() {
  try {
    const dados = JSON.parse(window.AndroidPlayer?.getProfiles?.() || "{}");
    return `tedflix:search-history:${dados.activeId || "guest"}`;
  } catch (_) {
    return "tedflix:search-history:guest";
  }
}

function lerLocal() {
  try {
    const itens = JSON.parse(localStorage.getItem(chaveHistoricoLocal()) || "[]");
    return Array.isArray(itens)
      ? itens
          .map((x) =>
            typeof x === "string"
              ? { id: encodeURIComponent(x.toLowerCase()), query: x }
              : { id: String(x.id || encodeURIComponent(String(x.query || "").toLowerCase())), query: String(x.query || "") },
          )
          .filter((x) => x.query)
          .slice(0, 15)
      : [];
  } catch (_) {
    return [];
  }
}

function salvarLocal(lista) {
  try {
    localStorage.setItem(chaveHistoricoLocal(), JSON.stringify(lista.slice(0, 15)));
  } catch (_) {}
}

async function carregarHistorico() {
  const remoto = bridge("getSearchHistory");
  if (remoto && remoto.success && Array.isArray(remoto.history)) {
    const lista = remoto.history
      .map((x) => ({
        id: String(x.id || encodeURIComponent(String(x.query || "").toLowerCase())),
        query: String(x.query || "").trim(),
      }))
      .filter((x) => x.query);
    if (lista.length) {
      salvarLocal(lista);
      return lista;
    }
  }
  return lerLocal();
}

function salvarPesquisa(valor) {
  const termo = String(valor || "").trim();
  if (termo.length < 2) return;
  const atuais = lerLocal().filter((item) => item.query.toLowerCase() !== termo.toLowerCase());
  const novo = [{ id: encodeURIComponent(termo.toLowerCase()), query: termo }, ...atuais].slice(0, 15);
  salvarLocal(novo);
  // API em background (não bloqueia UI)
  try {
    bridge("saveSearchHistory", termo);
  } catch (_) {}
}

async function apagarUma(item) {
  const id = item?.id || encodeURIComponent(String(item?.query || "").toLowerCase());
  const query = String(item?.query || "");
  const resto = lerLocal().filter(
    (x) => x.id !== id && x.query.toLowerCase() !== query.toLowerCase(),
  );
  salvarLocal(resto);
  try {
    bridge("deleteSearchHistoryItem", id);
  } catch (_) {}
}

export default function paginaBusca(raiz) {
  const page = el("div", { class: "page" });
  const campo = el("input", {
    class: "input",
    type: "search",
    placeholder: "Buscar filmes e séries...",
    "aria-label": "Buscar",
  });
  const grid = el("div", { class: "grid", style: "margin-top:16px" });
  const aviso = el("p", { class: "sub", style: "padding:16px" }, "Digite para buscar.");
  const recentes = el("div", { class: "pad search-recent" });

  page.append(
    el("h1", { class: "page-title" }, "Busca"),
    el("div", { class: "pad", style: "margin-top:8px" }, [campo]),
    aviso,
    recentes,
    grid,
  );
  raiz.append(page);
  setTimeout(() => campo.focus(), 50);

  async function renderRecentes() {
    recentes.innerHTML = "";
    const itens = await carregarHistorico();
    if (!itens.length) return;
    const head = el("div", { class: "search-recent-head" }, [
      el("p", { class: "sub", style: "margin:0" }, "Pesquisas recentes"),
    ]);
    recentes.append(head);
    itens.forEach((item) => {
      const row = el("div", { class: "search-recent-row" });
      const botao = el("button", { class: "btn ghost search-recent-term", type: "button" }, item.query);
      botao.addEventListener("click", () => {
        campo.value = item.query;
        rodar(item.query);
      });
      const del = el("button", {
        class: "btn ghost search-recent-del",
        type: "button",
        "aria-label": `Apagar ${item.query}`,
        title: "Apagar",
      }, "×");
      del.addEventListener("click", async (e) => {
        e.stopPropagation();
        await apagarUma(item);
        renderRecentes();
      });
      row.append(botao, del);
      recentes.append(row);
    });
  }
  renderRecentes();

  const rodar = debounce(async (q) => {
    if (q.trim().length < 2) {
      limpar(grid);
      aviso.textContent = "Digite ao menos 2 letras.";
      renderRecentes();
      return;
    }
    salvarPesquisa(q);
    renderRecentes();
    aviso.textContent = "";
    limpar(grid);
    for (let i = 0; i < 6; i++) grid.append(skeletonCard());
    try {
      const { resultados } = await buscar(q.trim());
      limpar(grid);
      if (!resultados.length) {
        aviso.textContent = "Nenhum resultado encontrado.";
        return;
      }
      const frag = document.createDocumentFragment();
      resultados.forEach((r) => frag.append(cardTitulo(r, { size: "md" })));
      grid.append(frag);
    } catch (e) {
      limpar(grid);
      aviso.textContent = "Falha na busca. Tente novamente.";
    }
  }, 400);

  campo.addEventListener("input", () => rodar(campo.value));
  return page;
}
